//! Modebar — the top-left mode dropdown of a host's header. Blender ref:
//! `VIEW3D_HT_header` mode picker (`layout.template_header()` +
//! `object.mode` enum). Anchor shows the active mode's icon + label;
//! click opens a popover listing every mode from `set::modes_for(host)`.
//!
//! For the Outliner, Blender places the search field (`filter_text`) and a
//! Filter popover button inline in the header immediately after the display-
//! mode dropdown. We replicate this by returning a `BView::Row` wrapping
//! `[mode_popover, search_field, filter_popover]` when `host == Outliner`.

pub mod list;
pub mod set;
pub mod shading;

use crate::v2::state::{BKey as _, OutlinerKey};
use super::modebar::set::{default_mode, mode_key, modes_for};

/// The mode a host is currently in — the one place that resolves the key and
/// its fallback, so a part that varies by mode (the asset shelf) reads the
/// same answer the mode bar shows.
pub fn active_mode(s: &BState, host: BHostType) -> &'static str {
    s.get(&mode_key(host))
        .and_then(|m| modes_for(host).iter().find(|spec| spec.label == m))
        .map(|spec| spec.label)
        .unwrap_or_else(|| default_mode(host))
}
use crate::v2::host::{BHostType, host_slug};
use crate::v2::part::custom::outliner::{set::TOGGLES, tree as otree};
use crate::v2::state::{
    BState, MenuKey,
    val::{V_EMPTY, V_FALSE, V_TRUE},
};
use crate::v2::view::prim::{BAction, BControl, BPopoverSide};
use crate::v2::view::{BView, BViewItem, BViewList};

pub use list::BModebarList;
pub use set::BModeSpec;

#[derive(Clone, Copy, Debug)]
pub struct BModebar {
    pub host: BHostType,
}

impl BModebar {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

fn active_icon(host: BHostType, active: &str) -> &'static str {
    modes_for(host)
        .iter()
        .find(|m| m.label == active)
        .map(|m| m.icon)
        .unwrap_or("object")
}

/// Build the Outliner filter popover body: sort-alpha toggle, separator,
/// then one toggle per restriction column (OUTLINER_PT_filter).
/// The outliner's filter popover, for `part::filter` to place at the right
/// end of the header.
pub fn outliner_filter(s: &BState) -> BView {
    let fkey = OutlinerKey::FilterOpen.path();
    let open = s.get(&fkey) == Some(V_TRUE);
    let toggle = BAction::Set(
        fkey.clone(),
        if open { V_FALSE.to_string() } else { V_TRUE.to_string() },
    );
    let close = BAction::Set(fkey, V_FALSE.to_string());
    let anchor = BView::Button(BControl::new().with_icon("filter").with_action(toggle));
    BView::popover(
        anchor,
        outliner_filter_body(s),
        open,
        close,
        BPopoverSide::Below,
    )
}

fn outliner_filter_body(s: &BState) -> Vec<BView> {
    let sort_on = otree::sort_alpha(s);
    let mut body = vec![
        BView::Button(
            BControl::new()
                .with_icon(if sort_on { "check" } else { "" })
                .with_label("Sort Alphabetically")
                .with_action(BAction::Set(
                    OutlinerKey::SortAlpha.path(),
                    if sort_on { V_FALSE.to_string() } else { V_TRUE.to_string() },
                )),
        ),
        BView::menu_sep(),
    ];
    for t in TOGGLES {
        let col_key = OutlinerKey::Column(t.state_key).path();
        let active = match s.get(&col_key) {
            Some(V_TRUE) => true,
            Some(V_FALSE) => false,
            _ => t.default_on,
        };
        body.push(BView::Button(
            BControl::new()
                .with_icon(if active { t.icon } else { "" })
                .with_label(t.tooltip)
                .with_action(BAction::Set(
                    col_key,
                    if active { V_FALSE.to_string() } else { V_TRUE.to_string() },
                )),
        ));
    }
    body
}

impl BViewItem for BModebar {
    fn build(&self, s: &BState) -> BView {
        // Host-scoped like every other menubar popover, so opening the mode
        // dropdown in one editor does not open it in the rest.
        let key = MenuKey::Top(host_slug(self.host), "mode").path();
        let open = s.get(&key) == Some(V_TRUE);
        let toggle = BAction::Toggle(key.clone());
        let close = BAction::Set(key, V_EMPTY.to_string());
        let active = s
            .get(&mode_key(self.host))
            .unwrap_or_else(|| default_mode(self.host));
        // Same header-height anchor as the menubar labels, so the mode
        // dropdown lines up with the menus beside it.
        let anchor = BView::MenuAnchor(
            BControl::new()
                .with_icon(active_icon(self.host, active))
                .with_label(active)
                .with_active(open)
                .with_action(toggle),
        );
        let body = BModebarList::new(self.host).items(s);
        let mode_popover = BView::popover(anchor, body, open, close, BPopoverSide::Below);

        // The header's shape is owned by `region::item::complete_header`:
        // the switcher and menus on the left, the host's search in the
        // middle (`part::search`), its filters on the right
        // (`part::filter`). The mode picker is the only thing the mode bar
        // contributes — building a search here as well is what put two
        // search fields in the outliner's header.
        // The shading radio moved to the header's right end
        // (`part::filter`), so the mode bar contributes only the mode picker
        // — the same shape in every host.
        mode_popover
    }
}
