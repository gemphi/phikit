//! Menu Search rows (Blender F3 `wm.search_menu`): every leaf of the Topbar
//! menus, found by recursing the declarative menu set, shown as
//! "File ▸ Import ▸ glTF 2.0" with its shortcut and firing the same action as
//! the menu item. Filtered by `command.query` (case-insensitive).

use crate::v2::state::{BKey as _, ModalKey};
use crate::v2::host::{BHostType, host_slug};
use crate::v2::part::menubar::item::tree::leaf_action;
use crate::v2::part::menubar::set::{BMenuItem, BMenuKind, menus_for};
use crate::v2::state::val::V_EMPTY;
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BRowShade, BTableCell};

pub struct BCommandHit {
    pub path: String,
    pub shortcut: &'static str,
    pub action: BAction,
}

fn walk(trail: &mut Vec<&'static str>, items: &'static [BMenuItem], out: &mut Vec<BCommandHit>) {
    for it in items {
        match it.kind {
            BMenuKind::Sep => {}
            BMenuKind::Sub(subs) => {
                trail.push(it.label);
                walk(trail, subs, out);
                trail.pop();
            }
            BMenuKind::Op | BMenuKind::Toggle => {
                let mut action = leaf_action(host_slug(BHostType::Topbar), trail, it);
                // Plain operators just close the palette.
                if it.modal.is_empty() && it.purpose.is_empty() && it.url.is_empty() {
                    action = BAction::Set(ModalKey::Open.path(), V_EMPTY.to_string());
                }
                let mut path = trail.join(" ▸ ");
                path.push_str(" ▸ ");
                path.push_str(it.label);
                out.push(BCommandHit { path, shortcut: it.shortcut, action });
            }
        }
    }
}

/// All searchable menu leaves matching `query`.
pub fn hits(query: &str) -> Vec<BCommandHit> {
    let mut out = Vec::new();
    for menu in menus_for(BHostType::Topbar) {
        walk(&mut vec![menu.label], menu.items, &mut out);
    }
    let q = query.trim().to_lowercase();
    out.retain(|h| q.is_empty() || h.path.to_lowercase().contains(&q));
    out
}

pub fn rows(query: &str) -> Vec<BView> {
    hits(query)
        .into_iter()
        .enumerate()
        .map(|(i, h)| {
            let shade = if i % 2 == 1 { BRowShade::Alt } else { BRowShade::Flat };
            let cells = vec![
                BTableCell::flex(BView::label(h.path)),
                BTableCell::fixed_end(BView::label(h.shortcut), 96.0),
            ];
            BView::table_row(cells, shade, Some(h.action))
        })
        .collect()
}
