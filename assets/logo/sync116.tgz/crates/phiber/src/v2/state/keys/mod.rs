//! Keys — every path the state is addressed by, spelt once, as an enum.
//!
//! A key is `ctx.{domain}.{owner}.{field}`. The domain is a file here; each
//! variant of its enum is one field, and `BKey::path` is the only place the
//! segments are written. A caller writes `s.get(FileKey::Path)`, never a
//! string with a dot in it, so a reader looking for what the file browser
//! stores opens `keys/file.rs` and sees all of it; a search for a key's uses
//! is a search for a variant.
//!
//! The older `K_…` constants in `state/key.rs` and the `k_…()` functions
//! scattered through the parts are the domains not yet moved here; they
//! implement `BKey` through `BPath`, so both spellings meet at the store.

pub mod activity;
pub mod app;
pub mod area;
pub mod buts;
pub mod ctx;
pub mod file;
pub mod menu;
pub mod modal;
pub mod outliner;
pub mod scene;
pub mod view3d;
pub mod zone;

pub use activity::ActivityKey;
pub use app::AppKey;
pub use area::AreaKey;
pub use buts::ButsKey;
pub use ctx::CtxKey;
pub use file::FileKey;
pub use menu::MenuKey;
pub use modal::ModalKey;
pub use outliner::OutlinerKey;
pub use scene::SceneKey;
pub use view3d::View3dKey;
pub use zone::ZoneKey;

use super::BPath;

/// Anything that names a state path.
pub trait BKey {
    fn path(&self) -> BPath;
}

impl BKey for BPath {
    fn path(&self) -> BPath {
        self.clone()
    }
}

impl<K: BKey> BKey for &K {
    fn path(&self) -> BPath {
        (**self).path()
    }
}
