//! Zone — a grid slot inside a space.

pub mod item;
pub mod list;
pub mod set;
pub mod size;
pub mod spec;
pub mod r#type;
pub mod visibility;

pub use item::BZoneItem;
pub use list::BZoneList;
pub use set::SET;
pub use size::{
    apply_zone_drag, is_resizable as is_zone_resizable, reset_zone_size, zone_size, zone_size_key,
};
pub use spec::BZoneSpec;
pub use r#type::BZoneType;
