//! Splash / Welcome window — the Phiber welcome screen.
//!
//! Blender ref: `WM_OT_splash` + `WM_MT_splash` (`bl_operators/wm.py:3431`).
//! Every block is one rounded `Card`, laid out exactly like Blender's splash:
//!
//! ```text
//! ┌─ banner ──────────────────────────────── Phiber  v0.1.0 ─┐
//! ├─ New File ─────────────┬─ Recent Files ─────────────────┤
//! │  General               │  scene.blend      ~/Projects   │
//! │  Shading …             │  … (5 rows)          More…     │
//! ├─ Open… ────────────────┼─ What's New ───────────────────┤
//! │  Recover Last Session  │  Support Phiber                │
//! └────────────────────────┴────────────────────────────────┘
//! ```
//! With no recent files the right card becomes "Getting Started" links, as
//! Blender does.
//!
//! Opened by `Phiber ▸ Splash Screen`, and shown once at startup (the seed
//! writes `ctx.modal = "splash"`). Dismissed like any modal: backdrop click,
//! the title-bar close button, or picking anything that commits a `Set`.

pub mod recent;
pub mod set;

use crate::v2::part::custom::file::keys as file_keys;
use crate::v2::state::{
    BPath, BState,
    key::{K_MODAL, K_SPACE},
    val::{V_EMPTY, V_MODAL_FILE_BROWSER},
};
use crate::v2::view::prim::{BAction, BControl, BPanelRole, BRowShade};
use crate::v2::view::{BView, BViewItem};

pub use set::{
    APP_NAME, BSplashEntry, EMPTY_RECENT, FOOT_LINKS, GETTING_STARTED, LINKS, RECENT_MAX,
    RECENT_ROWS, TEMPLATES,
};

#[derive(Clone, Copy, Debug, Default)]
pub struct BSplashModal;

fn heading(text: &'static str) -> BView {
    BView::panel(BPanelRole::CardHeader, vec![BView::label(text)])
}

fn card(title: &'static str, mut rows: Vec<BView>) -> BView {
    rows.insert(0, heading(title));
    BView::panel(BPanelRole::Card, rows)
}

fn link_button(l: &BSplashEntry) -> BView {
    BView::Button(
        BControl::new()
            .with_icon(l.icon)
            .with_label(l.label)
            .with_action(BAction::Set(BPath::owned(vec!["link"]), l.target.to_string())),
    )
}

/// Banner — mark, wordmark and version (Blender paints these on the splash
/// image). The name is the wordmark, not a label: the brand is drawn, not set.
fn banner() -> BView {
    BView::panel(
        BPanelRole::Header,
        vec![
            BView::icon("phiber_splash"),
            BView::icon("phiber_wordmark"),
            BView::spacer(),
            BView::label(format!("v{}", env!("CARGO_PKG_VERSION"))),
        ],
    )
}

/// "New File" — one row per workspace template.
fn new_file() -> BView {
    card(
        "New File",
        TEMPLATES
            .iter()
            .map(|t| {
                BView::Button(
                    BControl::new()
                        .with_icon(t.icon)
                        .with_label(t.label)
                        .with_action(BAction::Set(K_SPACE, t.target.to_string())),
                )
            })
            .collect(),
    )
}

/// "Recent Files" (5 rows + More…), or "Getting Started" when there are none.
fn recent_or_getting_started(s: &BState) -> BView {
    let paths = recent::recent_paths(s);
    if paths.is_empty() {
        return card("Getting Started", GETTING_STARTED.iter().map(link_button).collect());
    }
    let mut rows: Vec<BView> = paths
        .iter()
        .take(RECENT_ROWS)
        .enumerate()
        .map(|(i, path)| {
            let shade = if i % 2 == 1 { BRowShade::Alt } else { BRowShade::Flat };
            BView::list_row(
                vec![
                    BView::Button(
                        BControl::new()
                            .with_icon("file_blend")
                            .with_label(recent::display_name(path).to_string())
                            .with_action(BAction::Set(file_keys::k_selected(), path.clone())),
                    ),
                    BView::label(recent::parent_dir(path).to_string()),
                ],
                shade,
            )
        })
        .collect();
    if paths.len() > RECENT_ROWS {
        rows.push(BView::Button(
            BControl::new()
                .with_icon("viewzoom")
                .with_label("More\u{2026}")
                .with_action(BAction::Set(K_MODAL, V_MODAL_FILE_BROWSER.to_string())),
        ));
    }
    card("Recent Files", rows)
}

/// Second split, left: Open… and Recover Last Session.
fn open_card() -> BView {
    BView::panel(
        BPanelRole::Card,
        vec![
            BView::Button(
                BControl::new()
                    .with_icon("file_folder")
                    .with_label("Open\u{2026}")
                    .with_action(BAction::Set(K_MODAL, V_MODAL_FILE_BROWSER.to_string())),
            ),
            BView::Button(
                BControl::new()
                    .with_icon("history")
                    .with_label("Recover Last Session")
                    .with_action(BAction::Set(
                        BPath::owned(vec!["file", "recover_last_session"]),
                        "true".to_string(),
                    )),
            ),
        ],
    )
}

/// Second split, right: What's New and the support link.
fn links_card() -> BView {
    BView::panel(BPanelRole::Card, FOOT_LINKS.iter().map(link_button).collect())
}

impl BViewItem for BSplashModal {
    fn build(&self, s: &BState) -> BView {
        BView::column(vec![
            banner(),
            BView::row(vec![new_file(), recent_or_getting_started(s)]),
            BView::row(vec![open_card(), links_card()]),
        ])
    }
}

/// Action that dismisses the welcome window without changing anything else.
pub fn dismiss() -> BAction {
    BAction::Set(K_MODAL, V_EMPTY.to_string())
}
