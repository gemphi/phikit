//! Tab atom — strip button that blends with the surrounding pane on
//! active/hover, producing Blender's "paper tab" continuation effect on the
//! Properties navbar, the view3d sidebar and the top space bar.
//!
//! Geometry: a tab is a cap cut into the strip, so only its *leading* corners
//! are rounded and the trailing edge runs flush into the pane —
//!   • horizontal (labeled) tabs round the TOP corners (`rounded_t`),
//!   • vertical icon-only navbar tabs round the LEFT corners (`rounded_l`).
//! Active tabs always receive the stronger cap. Inactive editor tabs remain
//! transparent until hover; inactive Topbar workspace tabs rest on the light
//! host-matching fill and promote to the stronger active background on hover.

use super::super::{
    color::{resolved_gradient, to_hsla},
    ctx::BRenderCtx,
};
use super::{chrome, icon_path};

pub mod cap;
use cap::{BCapSide, BTabTooltip};
use crate::v2::host::BHostType;
use crate::v2::theme::{BControlState, BStyleRole};
use crate::v2::view::prim::{BControl, BRailSide};
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, div, px, svg};
use std::rc::Rc;

/// One tab renderer over the shared control record: `tooltip` (when set)
/// rides the strip as a hover tooltip — used by icon-only rail tabs and the
/// activity bar where the inline label is hidden.
/// A horizontal tab, whose pane continues below it.
pub fn view(ctl: &BControl, c: &BRenderCtx) -> AnyElement {
    cap_view(ctl, BCapSide::Below, c)
}

/// A rail tab, whose pane continues to the side the rail is pinned opposite.
pub fn rail(ctl: &BControl, side: BRailSide, c: &BRenderCtx) -> AnyElement {
    // A floating strip caps into nothing, so its entries are buttons.
    let side = if c.floating {
        BCapSide::Free
    } else {
        BCapSide::from(side)
    };
    cap_view(ctl, side, c)
}

/// A rail entry that is a free button — the activity bar's: it caps into no
/// pane, rounds fully and centres in its rail, but it is docked chrome, so it
/// rests on nothing and takes the accent only on hover and when active.
pub fn rail_button(ctl: &BControl, c: &BRenderCtx) -> AnyElement {
    cap_view(ctl, BCapSide::Free, c)
}

fn cap_view(ctl: &BControl, side: BCapSide, c: &BRenderCtx) -> AnyElement {
    let ic = ctl.icon.as_deref().unwrap_or("");
    let lbl = ctl.label.as_deref();
    let active = ctl.active;
    let action = ctl.action.as_ref();
    let tooltip = ctl.tooltip.as_deref();
    // Icon-only tabs (no label) are vertical navbar tabs. Properties gives
    // their paint a separate absolute layer so state never moves the icon.
    let icon_only = lbl.is_none();
    let properties_rail_tab = c.host == BHostType::Buts && icon_only;
    // No per-host tab treatment: a labelled tab in a strip is a menu, and
    // `atom::chrome` is where that one treatment lives.
    let strip_tab = chrome::in_strip(c) && !icon_only;
    let text = if active {
        to_hsla(c.style.colors.text)
    } else {
        to_hsla(c.style.colors.text_dim)
    };
    let hover_fill = if icon_only && c.host != BHostType::Buts {
        // Activity bar and non-Properties icon rails: lift from the soft strip.
        to_hsla(c.style.rail_tab_hover(c.host))
    } else {
        to_hsla(c.style.tab_hover(c.host))
    };
    let r = px(c.style.radius_for(BStyleRole::Tab));

    // A labeled tab is a cap cut into its strip: full strip height less the
    // gap above it, so its bottom edge is the strip's bottom edge and the pane
    // below continues the same surface. Icon-only rail tabs stay square.
    let strip_h = c.style.dimensions.header_height - c.style.dimensions.menu_top_gap;
    // A rail entry keeps one height whether or not it shows its label, so
    // expanding a toolbar widens it without making every button taller. The
    // activity bar is the exception: its entries are the menu caps of a
    // vertical top bar, so they take the cap height — and its secondary strip
    // lines up with them row for row, instead of running thinner beside them.
    let activity = side == BCapSide::Free || (side.in_rail() && c.host == BHostType::Activity);
    let tall = (!icon_only && !side.in_rail()) || activity;
    let mut row = div()
        .flex()
        .flex_row()
        .items_center()
        .gap(px(c.style.spacing.gap_sm))
        .h(px(if tall { strip_h } else { c.style.dimensions.button_height }))
        .text_color(text)
        .text_size(px(c.style.typography.body));
    // An icon-only cap in a horizontal strip is square: it is as wide as it
    // is tall, so its fill reads as a button rather than a vertical pill. In
    // a docked rail the cap spans the strip's width instead. A free cap in a
    // rail (the activity bar) is a button too — one button wide, centred —
    // so it reads like the toolbar's beside it rather than filling the rail.
    let square = icon_only && side == BCapSide::Below;
    let free_button = icon_only && side == BCapSide::Free;
    // A free cap (the activity bar's primary icon) is as tall as a menu cap
    // and as wide as it is tall.
    let button = if free_button { strip_h } else { c.style.dimensions.button_height };
    row = if square {
        row.w(px(strip_h)).h(px(strip_h)).justify_center()
    } else if free_button {
        row.w(px(button)).h(px(button)).justify_center()
    } else if icon_only {
        row.w_full().justify_center()
    } else if side.in_rail() {
        // Expanded rail entry: the button is the rail's full width and its
        // icon leads its label, so the column reads as a list of commands
        // rather than a stack of centred pills.
        row.w_full().justify_start().px(px(c.style.spacing.pad_sm))
    } else {
        row.px(px(c.style.spacing.pad_md))
    };

    // Non-Properties tabs retain their existing state styling. Properties
    // rail tabs paint on a stable sibling layer assembled below.
    if active && !properties_rail_tab {
        // An icon-only rail entry (the activity bar, the toolbar, a navbar)
        // marks its active state the way every control does: the accent at
        // the active opacity, one hue for the whole family of controls
        // (`style.control_fill`). A labelled tab keeps its filled cap, which
        // is what joins it to the pane beneath.
        if icon_only {
            let on = c
                .style
                .control_fill(BControlState::Active, c.floating)
                .unwrap_or(c.style.colors.accent);
            row = row.bg(to_hsla(on));
        } else {
            let active_fill = c.style.tab_active_gradient(c.host).along(side.gradient_axis());
            row = row.bg(resolved_gradient(active_fill));
        }
        // Every tab uses fill-only selection — no accent border strip.
        // The active cap and the surface beneath (popover / pane body)
        // form one continuous filled surface, so a hard line at the seam
        // would break the paper-tab illusion.
        row = side.round(row, r);
    } else if strip_tab {
        // Resting fill and hover lift are applied to the cap below, so the
        // paint stops at the rounded corners instead of over-painting them.
        row = side.round(row, r);
    }

    if !ic.is_empty() {
        let icon_id_text = format!("tab-icon-{}-{}", ic, lbl.unwrap_or(ic));
        row = row.child(
            div()
                .id(SharedString::from(icon_id_text.clone()))
                .debug_selector(move || icon_id_text.clone())
                .size(px(c.style.dimensions.icon_size))
                .flex_shrink_0()
                .child(
                    svg()
                        .path(icon_path(ic))
                        .size(px(c.style.dimensions.icon_size))
                        .text_color(text),
                ),
        );
    }
    if let Some(t) = lbl {
        row = row.child(SharedString::from(t.to_string()));
    }

    let id_text = format!("tab-{}-{}", ic, lbl.unwrap_or(ic));
    let content: AnyElement = if properties_rail_tab {
        let group = SharedString::from(format!("{id_text}-paint-hover"));
        let paint_id_text = format!("{id_text}-background");
        let mut paint = div()
            .id(SharedString::from(paint_id_text.clone()))
            .debug_selector(move || paint_id_text.clone())
            .absolute()
            .top_0()
            .bottom_0()
            ;
        // The far edge is inset and rounded; the pane-facing edge bleeds into
        // the content region, so it stays flush.
        paint = side.paint(
            paint,
            c.style.properties_tab_background_inset(),
            c.style.properties_tab_overlap(),
        );
        paint = side.round(paint, r);
        paint = if active {
            // The selected Properties tab sweeps into the panel beside it, so
            // the rail and the content read as one area.
            paint.bg(resolved_gradient(
                c.style.tab_active_gradient(c.host).along(side.gradient_axis()),
            ))
        } else {
            paint.group_hover(group.clone(), move |style| style.bg(hover_fill))
        };
        div()
            .group(group)
            .relative()
            .w_full()
            .h(px(c.style.dimensions.button_height))
            .child(paint)
            .child(row)
            .into_any_element()
    } else {
        row.into_any_element()
    };

    let Some(a) = action else {
        return content;
    };
    let handler = c.h.clone();
    let action = a.clone();
    let id = SharedString::from(id_text.clone());
    // The outer clickable owns the round-cap shape and hard-clips its
    // children so a hover fill can never bleed past the corners. Without
    // overflow_hidden the hover paint drew a full rectangle on top of the
    // rounded cap ("squarish on hover" bug).
    let cap_round = r;
    let mut el = div()
        .id(id)
        .debug_selector(|| id_text)
        .cursor_pointer()
        .overflow_hidden()
        .child(content);
    // The gap sits on the cap's far edge, so its pane-facing edge is the
    // strip's and the pane beyond continues the same surface. Properties
    // rail tabs are the exception: they keep a full-width allocation and
    // carry the same inset in their paint layer instead, so selection never
    // moves the icon (`tests/layout_gutters.rs`).
    if !properties_rail_tab {
        el = side.gap(el, c.style.dimensions.menu_top_gap);
    }
    el = side.round(el, cap_round);
    if icon_only || side.in_rail() {
        // A cap keeps its full height: a rail with more entries than room
        // must scroll or overflow, never squash its icons to fit.
        el = el.flex_shrink_0();
        el = if square {
            el.w(px(strip_h)).self_end()
        } else if free_button {
            el.w(px(button)).self_center()
        } else if properties_rail_tab {
            el.w_full()
        } else {
            // Cross-axis stretch, not `w_full`: a rail cap that carries a gap
            // on its far edge must fill what is left of the rail, not 100% of
            // it plus the margin.
            el.self_stretch()
        };
    }
    if !properties_rail_tab && !active {
        // Every control's rest / hover fill comes from one mapping
        // (`chrome::paint`): the accent at an opacity. Docked rails paint
        // nothing until hovered; floating chrome rests on the faint step so
        // it stays legible over the canvas.
        el = if strip_tab || c.floating || icon_only {
            chrome::paint(el, false, c)
        } else {
            el.hover(move |s| s.bg(hover_fill))
        };
    }
    // Tooltip must be attached before on_click (which consumes el by value).
    if let Some(tip) = tooltip {
        let tip = tip.to_string();
        let style = *c.style;
        el = el.tooltip(move |_, cx| {
            cx.new(|_| BTabTooltip::of(&tip, &style)).into()
        });
    }
    el.on_click(
        move |_e: &ClickEvent, w: &mut gpui::Window, cx: &mut gpui::App| {
            (Rc::clone(&handler))(&action, w, cx);
        },
    )
    .into_any_element()
}
