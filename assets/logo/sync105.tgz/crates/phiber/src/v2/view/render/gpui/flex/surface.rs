//! The half of `BFlex`'s builder that says what a container paints and where
//! it sits; `element.rs` has how it takes space and arranges its children.

use super::element::BFlex;
use super::token::{BEdge, BFill, BInk, BOverflow, BPlace, BRadius, BType};

impl BFlex {
    // ── What it paints ──────────────────────────────────────────────────

    pub const fn fill(mut self, fill: BFill) -> Self {
        self.fill = Some(fill);
        self
    }

    pub const fn border(mut self, edge: BEdge) -> Self {
        self.border = Some(edge);
        self
    }

    pub const fn radius(mut self, radius: BRadius) -> Self {
        self.radius = Some(radius);
        self
    }

    pub const fn lifted(mut self) -> Self {
        self.lifted = true;
        self
    }

    /// Sets the text colour inside to the theme's text.
    pub const fn ink(mut self) -> Self {
        self.ink = Some(BInk::Text);
        self
    }

    /// Sets the text colour inside to one of the theme's text tones.
    pub const fn ink_tone(mut self, ink: BInk) -> Self {
        self.ink = Some(ink);
        self
    }

    pub const fn type_size(mut self, size: BType) -> Self {
        self.type_size = Some(size);
        self
    }

    // ── Where it sits ───────────────────────────────────────────────────

    pub const fn place(mut self, place: BPlace) -> Self {
        self.place = place;
        self
    }

    pub const fn overflow(mut self, overflow: BOverflow) -> Self {
        self.overflow = overflow;
        self
    }

    pub const fn occludes(mut self) -> Self {
        self.occludes = true;
        self
    }
}
