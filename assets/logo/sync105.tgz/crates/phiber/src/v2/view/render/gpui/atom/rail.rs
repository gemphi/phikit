//! Rail atom — THE vertical strip renderer.
//!
//! One element for the Activity bar, the Toolbar, the Properties NavBar and
//! the Sidebar: a single column that fills the region slot it is placed in
//! (the region owns width and strip background) and lays its entries out by
//! group — Top entries stack from the top, Bottom entries pin to the bottom,
//! Center entries float between — with one flexible spacer between each
//! pair of consecutive non-empty groups.
//!
//! Entries render through the tab atom, which already owns the paper-tab
//! geometry, the per-host rail active/hover fills and the hover tooltip, so
//! every debug id (`tab-…`, `tab-…-background`, `tab-icon-…`) and every
//! pixel of the existing rail geometry is preserved.
//!
//! The strip kinds' fixed bottom cluster (expand chevron collapsed;
//! prev/collapse/next expanded) is just more entries in the Bottom group —
//! the part list builds them from state, so this renderer stays declarative:
//! it owns layout only, never behaviour.

use super::super::ctx::BRenderCtx;
use super::super::prim::strip;
use super::tab;
use crate::v2::view::prim::{BRailEntry, BRailGroup, BRailKind, BRailSide, BRailView};
use gpui::{AnyElement, div, px};
use gpui::prelude::*;

pub fn view(rail: &BRailView, c: &BRenderCtx) -> AnyElement {
    // The activity bar is a docked rail: its entries paint nothing at rest
    // and take the accent on hover and when active, like every other docked
    // control. It used to borrow the floating treatment for a resting fill,
    // which put a dark block behind every icon in the bar.
    // A rail is a strip along the vertical axis — the same element as a header
    // row, with Top / Center / Bottom in place of start / centre / end
    // (`prim::strip`). Its groups divide the height, which is what pins the
    // Bottom cluster to the foot of the strip.
    //
    // The rail is a hover group so its expand / paging cluster can appear only
    // while the pointer is over the strip.
    let group_name = gpui::SharedString::from(format!("rail-{:?}-{:?}", rail.kind, c.host));
    let groups: Vec<Vec<AnyElement>> = [BRailGroup::Top, BRailGroup::Center, BRailGroup::Bottom]
        .into_iter()
        .map(|group| {
            let entries: Vec<&BRailEntry> =
                rail.entries.iter().filter(|e| e.group == group).collect();
            if entries.is_empty() {
                return Vec::new();
            }
            // Strip kinds put their expand / paging cluster in the Bottom
            // group; the Activity bar uses all three for its own entries.
            let cluster = rail.kind.has_strip_cluster() && group == BRailGroup::Bottom;
            if cluster && rail.expanded {
                // Expanded, the cluster is the strip's footer: prev and next
                // at the two ends with the collapse control between them.
                let row = strip::place(
                    strip::BStripAxis::Row,
                    strip::BStripFit::Divide,
                    entries
                        .iter()
                        .map(|e| vec![entry(e, false, rail.side, rail.kind, c)])
                        .collect(),
                    c,
                )
                .w_full();
                return vec![row.into_any_element()];
            }
            if cluster {
                // Collapsed, the cluster is one expand arrow. It is an
                // affordance, not content, so the strip only offers it while
                // the pointer is over the rail, as Blender's region toggles do.
                let mut arrows = div()
                    .flex()
                    .flex_col()
                    .w_full()
                    .invisible()
                    .group_hover(group_name.clone(), |style| style.visible());
                for e in entries {
                    arrows = arrows.child(entry(e, rail.expanded, rail.side, rail.kind, c));
                }
                return vec![arrows.into_any_element()];
            }
            entries
                .into_iter()
                .map(|e| entry(e, rail.expanded, rail.side, rail.kind, c))
                .collect()
        })
        .collect();

    let mut el = strip::place(
        strip::BStripAxis::Column,
        strip::BStripFit::Divide,
        groups,
        c,
    )
    .group(group_name)
    .h_full()
    .min_h_0();
    el = if rail.kind == BRailKind::Activity {
        // The activity rail fills its area's card and centres its buttons in
        // it. Its pane hugs, so without a width of its own the rail would be
        // exactly one button wide and the buttons would sit on the card's
        // left edge instead of down its centre line.
        let inner = c.style.dimensions.activity_width - 2.0 * c.style.strokes.border;
        el.w(px(inner)).items_center()
    } else {
        el.w_full().items_stretch()
    };
    el
    // The leading inset belongs to the region, which knows what the content
    // beside the rail is inset by (`style.rail_lead`).
    .gap(px(c.style.dimensions.menu_top_gap))
    .into_any_element()
}

/// One entry cell. The entry's label renders inline when the strip is
/// expanded and as the hover tooltip beside the strip when collapsed.
fn entry(e: &BRailEntry, expanded: bool, side: BRailSide, kind: BRailKind, c: &BRenderCtx) -> AnyElement {
    let mut ctl = e.control.clone();
    ctl.tooltip = ctl.label.clone();
    if !expanded {
        ctl.label = None;
    }
    // The rail's side decides which edge of the cap runs into the pane, so a
    // right-hand rail mirrors rather than repeating the left-hand shape. The
    // activity bar's entries cap into nothing: they are free buttons.
    if kind == BRailKind::Activity {
        return tab::rail_button(&ctl, c);
    }
    tab::rail(&ctl, side, c)
}
