//! Zone-level layout: `BZoneType` decodes into orientation.
//!
//! - `Top` / `Bottom` — horizontal strips whose areas stack vertically.
//! - `Left` / `Center` / `Right` — full-height columns of stacked editors.
//! - `Full` — horizontal row of side-by-side areas.
//!
//! Heights and widths are `BFlex` decisions (`gpui/zone.rs`), read from the
//! resolved theme.

use super::{BAxis, BZoneLayout};
use crate::v2::zone::BZoneType;

impl BZoneLayout for BZoneType {
    fn axis(&self) -> BAxis {
        match self {
            BZoneType::Top | BZoneType::Bottom => BAxis::Column,
            BZoneType::Left | BZoneType::Center | BZoneType::Right | BZoneType::Rail => {
                BAxis::Column
            }
            BZoneType::Full => BAxis::Row,
        }
    }
}
