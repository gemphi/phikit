//! `BZoneType` — grid position tag.

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BZoneType {
    Top,
    Left,
    Center,
    Right,
    Bottom,
    Full,
    /// The activity rail: a fixed strip down the window's far left, in every
    /// space, never toggled and never dragged.
    Rail,
}

impl BZoneType {
    pub const ALL: &'static [BZoneType] = &[
        BZoneType::Top,
        BZoneType::Left,
        BZoneType::Center,
        BZoneType::Right,
        BZoneType::Bottom,
        BZoneType::Full,
        BZoneType::Rail,
    ];

    /// Zones in the order they are laid out: the top strip, then the middle
    /// band left to right, then the bottom strip.
    pub const IN_ORDER: &'static [BZoneType] = &[
        BZoneType::Top,
        BZoneType::Rail,
        BZoneType::Left,
        BZoneType::Center,
        BZoneType::Right,
        BZoneType::Full,
        BZoneType::Bottom,
    ];

    pub fn spec(self) -> &'static super::BZoneSpec {
        &super::SET[self as usize]
    }
    pub fn label(self) -> &'static str {
        self.spec().label
    }
    pub fn icon(self) -> &'static str {
        self.spec().icon
    }
    pub fn tooltip(self) -> &'static str {
        self.spec().tooltip
    }
    pub fn is_toggleable(self) -> bool {
        self.spec().toggleable
    }

    /// Stable lowercase slug used in state-key paths (Requirement 54.5).
    pub fn slug(self) -> &'static str {
        match self {
            BZoneType::Top => "top",
            BZoneType::Left => "left",
            BZoneType::Center => "center",
            BZoneType::Right => "right",
            BZoneType::Bottom => "bottom",
            BZoneType::Full => "full",
            BZoneType::Rail => "rail",
        }
    }

    /// Exact inverse of [`BZoneType::slug`]. Returns `None` for unknown input.
    pub fn from_slug(s: &str) -> Option<BZoneType> {
        match s {
            "top" => Some(BZoneType::Top),
            "left" => Some(BZoneType::Left),
            "center" => Some(BZoneType::Center),
            "right" => Some(BZoneType::Right),
            "bottom" => Some(BZoneType::Bottom),
            "full" => Some(BZoneType::Full),
            "rail" => Some(BZoneType::Rail),
            _ => None,
        }
    }
}
