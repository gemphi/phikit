//! GPUI action dispatch. State transitions are pure and shared with tests;
//! this layer is responsible only for notifying GPUI after a transition.

use super::BPhiberApp;
use super::import::should_import;
use crate::v2::scene::{loaded_path_key, selected_key};
use crate::v2::space::BSpaceType;
use crate::v2::state::{
    action::apply_action,
    area_resize::{apply_delta, apply_drag_with_min_extent, normalize},
    zone_size::apply_zone_drag_with_min_extent,
};
use crate::v2::view::prim::BAction;
use crate::v2::zone::BZoneType;
use gpui::Context;

impl BPhiberApp {
    /// One key press while a field holds the caret. Returns true when the
    /// window should re-render.
    pub fn handle_key(&mut self, key: &str, typed: Option<&str>, cx: &mut Context<Self>) -> bool {
        use crate::v2::state::edit::{BEdit, editing};
        let Some(target) = editing(&self.state) else {
            return false;
        };
        let outcome = crate::v2::state::edit::key(&mut self.state, key, typed);
        if outcome == BEdit::Ignored {
            return false;
        }
        // Return commits: run the value back through the normal action path so
        // everything that watches the key still fires (a typed folder path
        // navigates, a picked file imports).
        if outcome == BEdit::Confirmed {
            if let Some(path) = crate::v2::state::edit::field_path(&target) {
                let value = self.state.get_encoded(&target).unwrap_or("").to_string();
                self.handle_action(&BAction::Set(path, value), cx);
            }
        }
        cx.notify();
        true
    }

    pub fn handle_action(&mut self, action: &BAction, cx: &mut Context<Self>) {
        // 0. `ctx.link = <url>` is Blender's `wm.url_open`: hand the URL to
        //    the system browser. Side effect only — nothing is stored.
        if let BAction::Set(path, url) = action {
            if path.encode() == "ctx.link" && !url.is_empty() {
                cx.open_url(url);
                cx.notify();
                return;
            }
        }

        // 1. Apply the pure state transition (unchanged behavior), and log
        //    what it changed for the status bar's action log.
        let before = self.state.clone();
        apply_action(&mut self.state, action);
        crate::v2::state::log::record(action, &before, &self.state);

        // 2. Import spawn/settle shell around the pure core. If the just-applied
        //    action moved `file.selected` to a `.blend` path differing from the
        //    path the Scene_Source currently reflects (`scene.loaded_path`), we
        //    kick off exactly one import off the UI thread.
        if let Some(path) = should_import(
            self.state.get(&loaded_path_key()),
            self.state.get(&selected_key()),
        )
        .then(|| self.state.get(&selected_key()).map(str::to_string))
        .flatten()
        {
            self.start_import(path, cx);
        }

        // 3. Playback starts its ticker when Play turns on.
        self.ensure_playback(cx);

        // 4. Always notify after the synchronous part so the loading flag (and
        //    any other state change) shows on this render pass (as before).
        cx.notify();
    }

    /// Apply an incremental area-resize delta (legacy seam kept for the
    /// `BResizeHandler` callback) and notify only after a valid change.
    pub fn handle_resize(
        &mut self,
        space: BSpaceType,
        zone: BZoneType,
        index: usize,
        dpx: f32,
        extent: f32,
        cx: &mut Context<Self>,
    ) {
        if apply_delta(&mut self.state, space, zone, index, dpx, extent).is_ok() {
            normalize(&mut self.state, space, zone);
            cx.notify();
        }
    }

    /// Apply an *absolute* area-resize drag from a fixed anchor. The
    /// interactive divider uses this so the resize is idempotent in the total
    /// pixel delta — re-dispatching the same move converges to the same
    /// fractions regardless of how many move events gpui emits.
    #[allow(clippy::too_many_arguments)]
    pub fn handle_resize_drag(
        &mut self,
        space: BSpaceType,
        zone: BZoneType,
        index: usize,
        anchor_i: f32,
        anchor_j: f32,
        total_dpx: f32,
        extent: f32,
        min_extent: f32,
        cx: &mut Context<Self>,
    ) {
        if apply_drag_with_min_extent(
            &mut self.state,
            space,
            zone,
            index,
            anchor_i,
            anchor_j,
            total_dpx,
            extent,
            min_extent,
        )
        .is_ok()
        {
            normalize(&mut self.state, space, zone);
            cx.notify();
        }
    }

    /// Apply an absolute zone-seam drag (whole Left/Right column width or
    /// Bottom strip height). `anchor` is the zone size at drag start,
    /// `total` the cursor travel since then, `sign` the direction mapping.
    pub fn handle_zone_drag(
        &mut self,
        space: BSpaceType,
        zone: BZoneType,
        anchor: f32,
        total: f32,
        sign: f32,
        extent: f32,
        min_extent: f32,
        cx: &mut Context<Self>,
    ) {
        if apply_zone_drag_with_min_extent(
            &mut self.state,
            space,
            zone,
            anchor,
            total,
            sign,
            extent,
            min_extent,
        ) {
            cx.notify();
        }
    }
}
