fn hash(x: u32) -> u32 {
    var h = x * 747796405u + 2891336453u;
    h = ((h >> ((h >> 28u) + 4u)) ^ h) * 277803737u;
    return (h >> 22u) ^ h;
}

fn rnd(seed: ptr<function, u32>) -> f32 {
    *seed = hash(*seed);
    return f32(*seed) / 4294967295.0;
}

// Display value → scene-linear (inverse of `pow(aces(x), 1/2.2)`), so samples
// average in linear light and bright noise does not bias the result.
fn to_scene(disp: vec3<f32>) -> vec3<f32> {
    let y = clamp(pow(max(disp, vec3<f32>(0.0)), vec3<f32>(2.2)), vec3<f32>(0.0), vec3<f32>(0.995));
    let a = 2.43 * y - 2.51;
    let b = 0.59 * y - 0.03;
    let c = 0.14 * y;
    return max((-b - sqrt(max(b * b - 4.0 * a * c, vec3<f32>(0.0)))) / (2.0 * a), vec3<f32>(0.0));
}

fn to_display(x: vec3<f32>) -> vec3<f32> {
    let t = clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), vec3<f32>(0.0), vec3<f32>(1.0));
    return pow(t, vec3<f32>(1.0 / 2.2));
}

// Blend this sample (display value) into the linear running average and
// write the display pixel. The average's words hold scene-linear radiance.
fn emit(i: u32, disp: vec3<f32>) {
    let a = p.n + 3u * i;
    let old = vec3<f32>(bitcast<f32>(px[a]), bitcast<f32>(px[a + 1u]), bitcast<f32>(px[a + 2u]));
    let sum = select(vec3<f32>(0.0), old, p.frame > 0u) + to_scene(disp);
    px[a] = bitcast<u32>(sum.x);
    px[a + 1u] = bitcast<u32>(sum.y);
    px[a + 2u] = bitcast<u32>(sum.z);
    px[i] = pack(to_display(sum / f32(p.frame + 1u)));
}

// Blender's floor grid on z = 0 (`overlay_grid.cc`): lines every power of
// ten, the level chosen by how large a cell is on screen, with the finer
// level fading out as it shrinks below a few pixels and the coarser one taking
// over — so zooming in subdivides and zooming out merges, continuously. Lines
// are one pixel wide with an analytic anti-aliased edge (`foot` is the size of
// one pixel on the floor at that point), and fade with distance so the plane
// reads as a plane rather than a wall of lines at the horizon. X axis red,
// Y axis green, at the same width.
fn floor_grid(o: vec3<f32>, d: vec3<f32>, t_hit: f32, px: f32, base: vec3<f32>) -> vec3<f32> {
    if (p.grid <= 0.0 || abs(d.z) < 1e-6) { return base; }
    let t = -o.z / d.z;
    if (t <= 0.0 || t >= t_hit) { return base; }
    let q = o + d * t;
    // One pixel's footprint on the floor, in scene units.
    var foot = px;
    if (p.persp != 0u) { foot = px * t * p.units / p.dist; }
    // Level: the fine spacing is the power of ten whose cell is at least
    // ~24 px; `f` is how far the eye has zoomed out within that decade.
    let want = foot * 24.0;
    let lg = log2(max(want, 1e-9)) / log2(10.0);
    let lvl = floor(lg);
    let f = lg - lvl;
    let g0 = pow(10.0, lvl);
    let g1 = g0 * 10.0;
    // Half a pixel each side, anti-aliased over one pixel.
    let half_w = foot * 0.5;
    let aa = foot;
    let c0 = q.xy / g0;
    let c1 = q.xy / g1;
    let d0 = abs(c0 - round(c0)) * g0;
    let d1 = abs(c1 - round(c1)) * g1;
    let l0 = max(1.0 - smoothstep(half_w, half_w + aa, d0.x), 1.0 - smoothstep(half_w, half_w + aa, d0.y));
    let l1 = max(1.0 - smoothstep(half_w, half_w + aa, d1.x), 1.0 - smoothstep(half_w, half_w + aa, d1.y));
    // The fine level fades as its cells shrink toward the pixel; the coarse
    // level is always full. Across one decade the coarse lines of this level
    // become the fine lines of the next, so the hand-over is seamless.
    let fine = (1.0 - f) * (1.0 - f);
    let line = max(l0 * fine * 0.6, l1);
    // Distance fade: the floor dims toward the horizon, and at grazing angles
    // (line density high, one line per pixel) it fades to the sky instead of
    // aliasing.
    let horizon = clamp(abs(d.z) * 4.0, 0.0, 1.0);
    var depth = 1.0;
    if (p.persp != 0u) { depth = 1.0 / (1.0 + (t * p.units / (p.dist * 6.0)) * (t * p.units / (p.dist * 6.0))); }
    let fade = horizon * depth;
    var c = mix(base, p.grid_color.rgb, line * p.grid_color.a * fade);
    // The axes: red along X (y = 0), green along Y (x = 0).
    let ax = 1.0 - smoothstep(half_w, half_w + aa, abs(q.y));
    let ay = 1.0 - smoothstep(half_w, half_w + aa, abs(q.x));
    c = mix(c, vec3<f32>(0.85, 0.3, 0.33), ax * 0.85 * fade);
    c = mix(c, vec3<f32>(0.47, 0.72, 0.2), ay * 0.85 * fade);
    return c;
}

// Blender's "Standard" view transform: scene-linear to sRGB display.
fn srgb(c: vec3<f32>) -> vec3<f32> {
    let x = clamp(c, vec3<f32>(0.0), vec3<f32>(1.0));
    let lo = x * 12.92;
    let hi = 1.055 * pow(x, vec3<f32>(1.0 / 2.4)) - 0.055;
    return select(hi, lo, x <= vec3<f32>(0.0031308));
}

// A finished pixel: Solid mode is deterministic, so its value is written
// straight out rather than averaged into the sample buffer.
fn once(i: u32, disp: vec3<f32>) {
    px[i] = pack(disp);
}

fn pack(c: vec3<f32>) -> u32 {
    let q = vec3<u32>(clamp(c, vec3<f32>(0.0), vec3<f32>(1.0)) * 255.0 + 0.5);
    return q.r | (q.g << 8u) | (q.b << 16u) | (255u << 24u);
}

