//! `BRegionItem` — one region.

use super::{BRegionSpec, BRegionType};
use crate::v2::host::BHostType;
use crate::v2::pane::{BPaneList, BPaneType};
use crate::v2::part::modebar::set::modes_for;
use crate::v2::part::{BPartItem, BPartType};
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BRegionItem {
    pub host: BHostType,
    pub region: BRegionSpec,
}

impl BRegionItem {
    pub fn new(host: BHostType, region: BRegionSpec) -> Self {
        Self { host, region }
    }

    fn has_part(panes: &[BView], part: BPartType) -> bool {
        panes.iter().any(|pane| match pane {
            BView::Pane { children, .. } => children
                .iter()
                .any(|child| matches!(child, BView::Part { kind, .. } if *kind == part)),
            _ => false,
        })
    }

    fn ensure_part(
        panes: &mut Vec<BView>,
        pane_kind: BPaneType,
        part: BPartType,
        host: BHostType,
        state: &BState,
    ) {
        if Self::has_part(panes, part) {
            return;
        }
        let part = BPartItem::new(host, part).build(state);
        if let Some(BView::Pane { children, .. }) = panes
            .iter_mut()
            .find(|pane| matches!(pane, BView::Pane { kind, .. } if *kind == pane_kind))
        {
            children.push(part);
            return;
        }
        panes.push(BView::Pane {
            kind: pane_kind,
            children: vec![part],
        });
    }

    /// Like [`Self::ensure_part`], but the part leads its pane.
    fn ensure_first_part(
        panes: &mut Vec<BView>,
        pane_kind: BPaneType,
        part: BPartType,
        host: BHostType,
        state: &BState,
    ) {
        let view = BPartItem::new(host, part).build(state);
        if let Some(BView::Pane { children, .. }) = panes
            .iter_mut()
            .find(|pane| matches!(pane, BView::Pane { kind, .. } if *kind == pane_kind))
        {
            children.insert(0, view);
            return;
        }
        panes.insert(
            0,
            BView::Pane {
                kind: pane_kind,
                children: vec![view],
            },
        );
    }

    /// Drop every declared copy of `part` so it can be placed exactly once.
    fn strip(panes: &mut [BView], part: BPartType) {
        for pane in panes.iter_mut() {
            if let BView::Pane { children, .. } = pane {
                children.retain(|child| !matches!(child, BView::Part { kind, .. } if *kind == part));
            }
        }
    }

    /// One header shape for every host, whichever area it sits in:
    ///   left   — what this editor is (icon + name, the switch trigger), then
    ///            its mode bar and menus,
    ///   centre — what you are looking for (the host's search, if it has one),
    ///   right  — how it is filtered, and the rest of its controls.
    fn complete_header(&self, panes: &mut Vec<BView>, state: &BState) {
        for part in [
            BPartType::Switcher,
            BPartType::Modebar,
            BPartType::Search,
            BPartType::Filter,
        ] {
            Self::strip(panes, part);
        }
        if crate::v2::part::search::search_key(self.host).is_some()
            && !self.host.searches_in_tool_header()
        {
            Self::ensure_part(panes, BPaneType::Center, BPartType::Search, self.host, state);
        }
        if crate::v2::part::filter::has_filter(self.host) {
            Self::ensure_part(panes, BPaneType::Right, BPartType::Filter, self.host, state);
        }
        if !modes_for(self.host).is_empty() {
            Self::ensure_first_part(panes, BPaneType::Left, BPartType::Modebar, self.host, state);
        }
        Self::ensure_first_part(panes, BPaneType::Left, BPartType::Switcher, self.host, state);
    }
}

/// A pane with no parts, or only parts whose body is empty.
fn pane_is_blank(pane: &BView) -> bool {
    match pane {
        BView::Empty => true,
        BView::Pane { children, .. } => children
            .iter()
            .all(|part| match part {
                BView::Empty => true,
                BView::Part { body, .. } => body.is_empty(),
                _ => false,
            }),
        _ => false,
    }
}

impl BViewItem for BRegionItem {
    fn build(&self, state: &BState) -> BView {
        if self.region.panes.is_empty() {
            return BView::empty();
        }
        let mut children = BPaneList::new(self.host, self.region.panes).items(state);
        if self.region.kind == BRegionType::Header {
            self.complete_header(&mut children, state);
        }
        // An execute bar with nothing to execute — the file browser's, with
        // no purpose set — is not there at all, rather than an empty strip
        // of its height (Blender's `FILEBROWSER_PT_execute` polls the same
        // way). Other regions keep their place empty: the asset shelf is a
        // drawer whether or not it has assets to show.
        if self.region.kind == BRegionType::Execute && children.iter().all(pane_is_blank) {
            return BView::empty();
        }
        BView::Region {
            kind: self.region.kind,
            children,
        }
    }
}
