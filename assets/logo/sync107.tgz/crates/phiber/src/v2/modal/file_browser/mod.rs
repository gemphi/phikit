//! File Browser modal — the Open / Save As / Import / Export overlay.
//! Content is shared with the `file` host: sidebar categories, columns,
//! filters, and nav actions all live in `part::custom::file`.
//!
//! The dialog raises the `File` host (`host::file::REGIONS`) in a card, so
//! its header, path strip, source list, file list and execute bar are the
//! regions the editor has in a workspace — one declaration, one layout.

pub use crate::v2::part::custom::file::set::{
    BFileCategory, BFileColumn, BFileDisplayType, BFileEntry, CATEGORIES, COLUMNS, DISPLAY_MODES,
    FILTERS, NAV, SYSTEM,
};
use crate::v2::host::{BHostItem, BHostType};
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem};

#[derive(Clone, Copy, Debug, Default)]
pub struct BFileBrowserModal;

impl BViewItem for BFileBrowserModal {
    /// The dialog is the File host raised in a card: the same regions, in
    /// the same order, laid out by the same walkers as the editor in a
    /// workspace. Nothing here is built a second time.
    fn build(&self, s: &BState) -> BView {
        BHostItem::new(BHostType::File).build(s)
    }
}
