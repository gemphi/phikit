//! File Browser host. Blender ref: `space_file/space_file.cc:1043-`.
//!
//! Blender's regions, declared as ours, in Blender's order:
//! ```text
//! ┌─ header      View / Select menus ──────────────────────────────────┐
//! ├─ ui          [← → ↑ ⟳] /directory/ [search] [≡][⊞][⊠] [👁][⛛▾]   ┤
//! ├─ tools ────────────┬─ window ─────────────────────────┬─ ui (N) ───┤
//! │ ▾ Volumes          │  Name        Modified      Size  │ options    │
//! │ ▾ System           │  … file rows …                   │            │
//! │ ▾ Bookmarks        │                                  │            │
//! ├─ execute     [file name]               [Cancel] [Open Phiber] ────┤
//! └────────────────────────────────────────────────────────────────────┘
//! ```
//! The same declaration serves the editor in a workspace and the Open /
//! Save As dialog (`modal::file_browser`), which raises this host in a card.

use crate::v2::host::header;
use crate::v2::pane::{BPaneSpec, BPaneType};
use crate::v2::part::BPartType;
use crate::v2::region::{BRegionSpec, BRegionType};

/// Blender's `ui` region at the top: the directory strip.
static PATH_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::PathBar],
}];
/// Blender's `tools` region: the source list.
static TOOLS_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::SourceList],
}];
static CENTER_PANES: &[BPaneSpec] = &[
    BPaneSpec {
        kind: BPaneType::Center,
        parts: &[BPartType::Custom],
    },
    BPaneSpec {
        kind: BPaneType::Right,
        parts: &[BPartType::Sidebar],
    },
];
static EXECUTE_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::Execute],
}];

pub static REGIONS: &[BRegionSpec] = &[
    BRegionSpec {
        kind: BRegionType::Header,
        panes: header::EDITOR,
    },
    BRegionSpec {
        kind: BRegionType::ToolHeader,
        panes: PATH_PANES,
    },
    BRegionSpec {
        kind: BRegionType::Tools,
        panes: TOOLS_PANES,
    },
    BRegionSpec {
        kind: BRegionType::Center,
        panes: CENTER_PANES,
    },
    BRegionSpec {
        kind: BRegionType::Execute,
        panes: EXECUTE_PANES,
    },
];
