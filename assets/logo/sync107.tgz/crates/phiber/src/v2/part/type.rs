//! `BPartType` — leaf variants.
//!
//! `Activity` is Phiber-native (not in Blender): a full-height leftmost bar
//! with global navigation (home / chat / spaces / stream / settings / profile).
//! Everything else mirrors a Blender part.

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BPartType {
    Menubar,
    Modebar,
    Switcher,
    Search,
    Filter,
    Spacebar,
    Toolbar,
    Sidebar,
    Panel,
    Channels,
    Statusbar,
    /// The action log at the foot of the window.
    StatusLog,
    Zonebar,
    NavBar,
    HUD,
    Execute,
    /// The file browser's directory strip — Blender's `FILEBROWSER_PT_directory_path`
    /// in its `ui` region: nav, directory, search, display mode, filter.
    PathBar,
    /// The file browser's source list — Blender's `tools` region: volumes,
    /// system folders, bookmarks, recent (the asset browser's libraries and
    /// catalogs).
    SourceList,
    AssetShelf,
    AssetShelfHeader,
    ToolProps,
    AdjustLastOp,
    Scrubbing,
    Activity,
    CaptionLead,
    CaptionTrail,
    Custom,
}

impl BPartType {
    pub fn label(self) -> &'static str {
        match self {
            BPartType::Menubar => "Menu Bar",
            BPartType::Modebar => "Mode Bar",
            BPartType::Switcher => "Switcher",
            BPartType::Search => "Search",
            BPartType::Filter => "Filter",
            BPartType::Spacebar => "Space Bar",
            BPartType::Toolbar => "Toolbar",
            BPartType::Sidebar => "Sidebar",
            BPartType::Panel => "Panel",
            BPartType::Channels => "Channels",
            BPartType::Statusbar => "Status Bar",
            BPartType::Zonebar => "Zone Visibility",
            BPartType::NavBar => "Nav Bar",
            BPartType::HUD => "HUD",
            BPartType::Execute => "Execute",
            BPartType::PathBar => "File Path",
            BPartType::SourceList => "Source List",
            BPartType::AssetShelf => "Asset Shelf",
            BPartType::AssetShelfHeader => "Asset Shelf Header",
            BPartType::ToolProps => "Tool Properties",
            BPartType::AdjustLastOp => "Adjust Last Op",
            BPartType::Scrubbing => "Scrubbing",
            BPartType::Activity => "Activity",
            BPartType::CaptionLead | BPartType::CaptionTrail => "Window Controls",
            BPartType::StatusLog => "Action Log",
            BPartType::Custom => "Custom",
        }
    }
}
