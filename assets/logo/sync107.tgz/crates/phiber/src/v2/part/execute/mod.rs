//! Execute bar — footer action buttons (Cancel / Open / Save …).
//! Blender ref: `RGN_TYPE_EXECUTE`.

pub mod list;
pub mod set;

use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem, BViewList};

pub use list::BExecuteList;
pub use set::BExecuteAction;

#[derive(Clone, Copy, Debug)]
pub struct BExecute {
    pub host: BHostType,
}

impl BExecute {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewItem for BExecute {
    fn build(&self, s: &BState) -> BView {
        // The file browser's bar is the real one: the file name field and the
        // Cancel / <purpose> pair, up only while there is a purpose.
        if matches!(self.host, BHostType::File | BHostType::Asset) {
            return crate::v2::part::custom::file::execute::view(s);
        }
        BView::row(BExecuteList::new(self.host).items(s))
    }
}
