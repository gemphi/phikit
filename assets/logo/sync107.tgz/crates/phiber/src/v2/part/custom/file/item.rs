//! `BFileItem` — the File / Asset host's window region: the file table (or
//! the thumbnail grid), and in the Asset host the asset grid.
//!
//! Everything else the browser shows is a region of the host, declared in
//! `host::file` / `host::asset` the way Blender's `space_file` declares
//! them: the header's menus (`part::menubar`), the path strip
//! (`BPartType::PathBar`), the source list (`BPartType::SourceList`), the
//! options sidebar and the execute bar (`BPartType::Execute`). One
//! declaration serves the editor in a workspace and the Open / Save As
//! dialog, which raises the same host in a card.

use super::table;
use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem};

#[derive(Clone, Copy, Debug)]
pub struct BFileItem {
    pub host: BHostType,
}

impl BFileItem {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewItem for BFileItem {
    fn build(&self, s: &BState) -> BView {
        table::view(s)
    }
}
