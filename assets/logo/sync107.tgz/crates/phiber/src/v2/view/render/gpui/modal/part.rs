//! The modal level's layout: every container a modal is built from, and the
//! one `BFlexed` impl that answers how each is laid out.

use super::super::ctx::BRenderCtx;
use super::super::flex::{
    BAlign, BDim, BEdge, BFill, BFlex, BFlexed, BJustify, BLen, BOverflow, BPlace, BRadius, BSpace,
    BType,
};
use crate::v2::theme::{BStyleRole, BSurfaceTone};

/// Every container a modal is built from. One impl answers how each is laid
/// out, so the modal level is described in one place, the way every other
/// level is.
#[derive(Clone, Copy)]
pub enum BModalPart {
    /// Covers the window; the backdrop and the card are layered inside it.
    Layer,
    /// The dim over the workspace; clicking it closes the modal.
    Backdrop,
    /// Centres the card in the window, inset by the large pad.
    Centerer,
    /// A card modal. `fills` when it is maximised or elevates a whole host (an
    /// editor in a dialog takes the room an editor takes); otherwise it keeps
    /// the size its spec declares.
    Card { fills: bool, width: f32, height: f32 },
    /// A reading sheet: `share` of the window's width, the whole height.
    Sheet { share: f32 },
    /// The card's content. `flush` for bodies that compose their own
    /// edge-to-edge regions (file browser, render) — every other modal keeps
    /// the large inner gutter so form content doesn't butt against the border.
    /// `bounded` for a sheet: a column that gives its page a bounded height
    /// to scroll in, rather than a box that grows to the page's length.
    CardBody { flush: bool, bounded: bool },
    /// A viewport-filling modal (Welcome, About).
    Fullscreen,
    /// A fullscreen modal's content.
    FullscreenBody,
    /// The title bar — a header strip across the top of the modal.
    TitleBar { top_radius: Option<f32> },
    /// The icon and label at the head of the title bar.
    TitleGroup,
    /// The window controls at the end of the title bar.
    TitleControls,
    /// The Welcome form: its content column, centred in the modal.
    WelcomeLayout,
    WelcomeColumn { max_width: f32 },
    /// A row of equal cards in the Welcome form, and one of its cells.
    WelcomeRow,
    WelcomeCell,
}

impl BFlexed for BModalPart {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        match *self {
            Self::Layer => BFlex::cell().place(BPlace::Overlay),
            Self::Backdrop => BFlex::cell().place(BPlace::Overlay).full().fill(BFill::ModalDim),
            Self::Centerer => BFlex::row()
                .place(BPlace::Overlay)
                .align(BAlign::Center)
                .justify(BJustify::Center)
                .pad(BSpace::PadLg),
            Self::Card { fills, width, height } => card(fills, width, height),
            Self::Sheet { share } => card(false, 0.0, 0.0).width(BLen::Share(share)).height(BLen::Full),
            Self::CardBody { flush, bounded } => card_body(flush, bounded),
            Self::Fullscreen => BFlex::column()
                .place(BPlace::Overlay)
                .full()
                .fill(BFill::Tone(BSurfaceTone::Modal))
                .ink()
                .occludes(),
            Self::FullscreenBody => BFlex::cell()
                .fills()
                .full()
                .min_height(BLen::Zero)
                .overflow(BOverflow::Clip)
                .pad(BSpace::PadLg),
            Self::TitleBar { top_radius } => title_bar(top_radius),
            Self::TitleGroup => BFlex::row().align(BAlign::Center).gap(BSpace::GapSm),
            Self::TitleControls => BFlex::row().align(BAlign::Center).gap(BSpace::GapXs),
            Self::WelcomeLayout => BFlex::row()
                .fills()
                .full()
                .min_height(BLen::Zero)
                .align(BAlign::Center)
                .justify(BJustify::Center)
                .pad(BSpace::PadLg),
            Self::WelcomeColumn { max_width } => BFlex::column()
                .width(BLen::Full)
                .max_width(BLen::Measured(max_width))
                .gap(BSpace::GapLg),
            Self::WelcomeRow => BFlex::row()
                .align(BAlign::Stretch)
                .width(BLen::Full)
                .min_width(BLen::Zero)
                .gap(BSpace::GapLg),
            Self::WelcomeCell => BFlex::row().fills().min_width(BLen::Zero),
        }
    }
}


fn card(fills: bool, width: f32, height: f32) -> BFlex {
    let card = BFlex::column()
        .fill(BFill::Tone(BSurfaceTone::Modal))
        .ink()
        .border(BEdge::All)
        .radius(BRadius::Role(BStyleRole::Modal))
        .occludes()
        .lifted();
    if fills {
        card.fills().full()
    } else {
        card.width(BLen::Measured(width)).height(BLen::Measured(height))
    }
}

fn card_body(flush: bool, bounded: bool) -> BFlex {
    let body = if bounded { BFlex::column() } else { BFlex::cell() };
    let body = body.fills().min_height(BLen::Zero).overflow(BOverflow::Clip);
    if flush { body } else { body.pad(BSpace::PadLg) }
}

/// The title bar is a header strip: a header's height and side padding, the
/// header surface, and a rule under it.
fn title_bar(top_radius: Option<f32>) -> BFlex {
    let bar = BFlex::row()
        .align(BAlign::Center)
        .justify(BJustify::Between)
        .height(BLen::Dim(BDim::HeaderHeight))
        .pad_x(BSpace::PadMd)
        .fill(BFill::Tone(BSurfaceTone::Header))
        .border(BEdge::Bottom)
        .type_size(BType::Header);
    match top_radius {
        Some(r) => bar.radius(BRadius::Top(r)),
        None => bar,
    }
}
