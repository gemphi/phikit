//! Focused renderer for `BPanelRole::Header` — the heading strip of the file
//! and asset browsers, rounded on top like every host header so a modal's
//! heading meets its card's corners.

use super::super::super::{ctx::BRenderCtx, walk};
use super::style::{panel_bg, surface_gutter};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::BPanelRole;
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

pub struct BHeader<'a>(pub &'a [BView]);

impl BHeader<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        self.strip(c.style.dimensions.header_height, c)
    }

    /// The Welcome banner: the same strip at the banner's height, so the
    /// large mark fits inside it instead of overflowing a header.
    pub fn banner(&self, c: &BRenderCtx) -> AnyElement {
        self.strip(c.style.dimensions.banner_height, c)
    }

    fn strip(&self, height: f32, c: &BRenderCtx) -> AnyElement {
        let mut element = div()
            .id(gpui::SharedString::from("panel-header"))
            .debug_selector(|| "panel-header".to_string())
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .h(px(height))
            // A strip keeps its height: the column it heads never trades the
            // strip's height for its cards', which is what shrank the banner
            // to its mark.
            .flex_shrink_0()
            .px(px(surface_gutter(c)))
            .gap(px(c.style.spacing.gap_xs))
            .rounded_t(px(c.style.radius_for(BStyleRole::Panel)))
            .bg(panel_bg(BPanelRole::Header, c));
        // A strip's controls follow the menu treatment whether the strip is
        // a region in a host or a panel in a modal (`atom::chrome`).
        let c = &c.in_strip();
        for child in self.0 {
            element = element.child(walk(child, c));
        }
        element.into_any_element()
    }
}

use super::super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BHeader<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BHeader::render(self, c)
    }
}
