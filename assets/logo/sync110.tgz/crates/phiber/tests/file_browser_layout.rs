//! The file browser dialog, measured on the painted UI.
//!
//! The dialog raises the File host, so what it shows is the host's regions:
//! a header, a path strip and an execute bar of one height, a source list
//! column beside the file list, and the content gap under the strips — the
//! same rules a workspace lays the editor out by, not a second set.

use gpui::{Pixels as px_t, TestAppContext, px, size};
use phiber::v2::app::BPhiberApp;
use phiber::v2::part::custom::file::keys;
use phiber::v2::state::{
    BState,
    key::{K_MODAL, K_SPACE},
    val::{V_MODAL_FILE_BROWSER, V_TRUE},
};
use phiber::v2::theme::METRICS;

async fn dialog(cx: &mut TestAppContext, filter_open: bool) -> &mut gpui::VisualTestContext {
    let (app, cx) = cx.add_window_view(|_, _| BPhiberApp::new());
    cx.simulate_resize(size(px(1400.0), px(900.0)));
    app.update(cx, |app, cx| {
        app.state = BState::new();
        app.state.set(&K_SPACE, "layout");
        app.state.set(&K_MODAL, V_MODAL_FILE_BROWSER);
        if filter_open {
            app.state.set(&keys::k_filter_open(), V_TRUE);
        }
        cx.notify();
    });
    cx.run_until_parked();
    cx
}

fn bounds(cx: &mut gpui::VisualTestContext, id: &'static str) -> gpui::Bounds<px_t> {
    cx.debug_bounds(id).unwrap_or_else(|| panic!("{id} was not painted"))
}

fn top(b: gpui::Bounds<px_t>) -> f32 {
    f32::from(b.origin.y)
}
fn bottom(b: gpui::Bounds<px_t>) -> f32 {
    f32::from(b.origin.y) + f32::from(b.size.height)
}
fn mid(b: gpui::Bounds<px_t>) -> f32 {
    f32::from(b.origin.y) + f32::from(b.size.height) / 2.0
}

#[gpui::test]
async fn the_strips_are_one_height_and_the_content_sits_a_gutter_below(cx: &mut TestAppContext) {
    let cx = dialog(cx, false).await;
    let header = bounds(cx, "region-Header-File");
    let path = bounds(cx, "region-ToolHeader-File");
    let execute = bounds(cx, "region-Execute-File");
    for (name, strip) in [("header", header), ("path strip", path), ("execute bar", execute)] {
        assert_eq!(f32::from(strip.size.height), METRICS.h_header, "the {name} is a header's height");
    }
    assert_eq!(top(path), bottom(header), "the path strip sits directly under the header");

    let files = bounds(cx, "panel-body-surface");
    let sources = bounds(cx, "panel-sidebar-column");
    assert_eq!(top(files) - bottom(path), METRICS.pad_md, "the file list sits a gutter under the strips");
    assert_eq!(top(sources), top(files), "the source list and the file list start on one line");
    assert_eq!(bottom(sources), bottom(files), "and end on one line");
    assert_eq!(top(execute) - bottom(files), METRICS.pad_md, "the execute bar sits a gutter below them");
}

#[gpui::test]
async fn the_fields_and_buttons_sit_on_the_strips_centre_line(cx: &mut TestAppContext) {
    let cx = dialog(cx, false).await;
    let path = bounds(cx, "region-ToolHeader-File");
    let directory = bounds(cx, "btn-label-set-ctx.edit-ctx.file.path-text");
    let search = bounds(cx, "btn-label-set-ctx.edit-ctx.file.search-text");
    let up = bounds(cx, "btn-icon-set-ctx.file.nav-file.parent-arrow_up");
    for (name, control) in [("directory", directory), ("search", search), ("up", up)] {
        assert!((mid(control) - mid(path)).abs() < 0.51, "the {name} control is centred on the strip");
    }
    // The display-mode radio sits in the header's right pane; the
    // hidden-files eye, the filter toggle and its popover in the path
    // strip's right pane — each centred on its strip, right of the fields.
    let header = bounds(cx, "region-Header-File");
    let radio = bounds(cx, "tab-list-list");
    assert!((mid(radio) - mid(header)).abs() < 1.01, "the display-mode radio hangs in the header");
    let hidden = bounds(cx, "btn-icon-set-ctx.file.show_hidden-true-eye_off");
    assert!((mid(hidden) - mid(path)).abs() < 0.51, "the hidden-files eye is centred on the path strip");
    assert!(f32::from(hidden.origin.x) > f32::from(search.origin.x) + f32::from(search.size.width), "and right of the search");
    assert!(
        f32::from(directory.size.width) > 120.0 && f32::from(search.size.width) > 120.0,
        "the directory and the search take the strip's slack"
    );
    let execute = bounds(cx, "region-Execute-File");
    let filename = bounds(cx, "btn-label-set-ctx.edit-ctx.file.filename-text");
    assert!((mid(filename) - mid(execute)).abs() < 0.51, "the file name field is centred on the bar");
}

#[gpui::test]
async fn the_filter_popover_lists_menu_rows_from_its_left_edge(cx: &mut TestAppContext) {
    let cx = dialog(cx, true).await;
    let panel = bounds(cx, "popover-panel");
    let hidden = bounds(cx, "menu-Show Hidden Files");
    let folders = bounds(cx, "menu-Folders");
    assert_eq!(f32::from(hidden.origin.x), f32::from(folders.origin.x), "every row starts on one line");
    let inset = f32::from(hidden.origin.x) - f32::from(panel.origin.x);
    assert!(inset > 0.0 && inset < METRICS.pad_md * 2.0, "rows run from the panel's left edge, inset {inset}");
    assert_eq!(
        f32::from(hidden.size.width),
        f32::from(folders.size.width),
        "rows are the panel's width, not each its own"
    );
}
