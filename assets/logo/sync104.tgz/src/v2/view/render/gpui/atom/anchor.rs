//! Menubar anchor with stable geometry and resolved semantic styling.

use super::super::flex::{BFlex, BSpace};
use super::super::{
    color::to_hsla,
    ctx::BRenderCtx,
};
use super::{brand, chrome, icon_path};
use crate::v2::theme::BStyleRole;
use crate::v2::view::prim::BControl;
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, div, px, svg};
use std::rc::Rc;

/// A menu cap fills its strip apart from the gap above it, so the cap's
/// bottom edge is the strip's bottom edge and the popover that drops from it
/// continues the same surface.
fn resolved_height(c: &BRenderCtx) -> f32 {
    // The same cap height a tab uses. It no longer subtracts a hairline: the
    // header/content seam is a tone change now, not a rule, so there is no
    // border for the cap to stop short of.
    c.style.dimensions.header_height - c.style.dimensions.menu_top_gap
}

pub fn view(ctl: &BControl, c: &BRenderCtx) -> AnyElement {
    let icon = ctl.icon.as_deref().unwrap_or("");
    let label = ctl.label.as_deref();
    let active = ctl.active;
    let action = ctl.action.as_ref();
    let hover = ctl.hover.as_ref();
    let r = px(c.style.radius_for(BStyleRole::MenuItem));
    // Menu anchor row: only the top corners are rounded because the popover
    // drops from the bottom — the anchor and its popover form a continuous
    // surface with the top pair rounded and the bottom pair flush.
    let mut row = div()
        .flex()
        .flex_row()
        .items_center()
        .gap(px(c.style.spacing.gap_sm))
        .h(px(resolved_height(c)))
        .px(px(c.style.spacing.pad_md))
        .rounded_t(r)
        .text_color(to_hsla(c.style.colors.text))
        .text_size(px(c.style.typography.body));
    // A property row's value column hands its whole width to one control, so
    // the dropdown there lines up with the label opposite it and with every
    // value below it rather than hugging its own longest option.
    row = if c.fill {
        row.w_full().min_w_0().justify_between()
    } else {
        row.flex_shrink_0()
    };

    if !icon.is_empty() {
        // The app's mark is not one more icon in the row: it is drawn larger
        // and in the brand's own two tones, so the head of the top bar reads
        // as the product rather than as another menu.
        //
        row = if ctl.brand {
            // The cap hangs from the strip's bottom edge, one `menu_top_gap`
            // short of its top, so the cap's centre sits half a gap below the
            // strip's. Text is too small to show it; the mark is not. Lifting
            // it by the gap (a negative top margin moves a centred item by
            // half of itself) puts it on the strip's centre line.
            row.child(
                BFlex::row()
                    .keeps_size()
                    .raised_by(BSpace::MenuTopGap)
                    .div(c)
                    .child(brand::mark(c.style.dimensions.brand_size, "brand-mark", c)),
            )
        } else {
            row.child(
                svg()
                    .path(icon_path(icon))
                    .size(px(c.style.dimensions.icon_size))
                    .flex_shrink_0()
                    .text_color(to_hsla(c.style.colors.text)),
            )
        };
    }
    if let Some(text) = label.filter(|text| !text.is_empty()) {
        row = row.child(SharedString::from(text.to_string()));
    }
    let Some(action) = action else {
        return row.self_end().mt(px(c.style.dimensions.menu_top_gap)).into_any_element();
    };
    let handler = c.h.clone();
    let action_copy = action.clone();
    let id_text = super::button::element_id(icon, label, action);
    // The outer clickable owns the rounded top-cap and hard-clips its
    // children so a hover fill can never bleed past the corners (was the
    // "squarish on hover" bug — hover bg was painting a full rectangle).
    let element = div()
        .id(SharedString::from(id_text.clone()))
        .debug_selector(|| id_text)
        .cursor_pointer()
        // A cap is as wide as its label. Without this a greedy sibling in the
        // same pane crushed the menus to a few pixels each, which read as the
        // menu names overlapping.
        .flex_shrink_0()
        // Pinned to the strip's bottom with the gap above it, so the cap's own
        // bottom edge is the header's rule and the popover continues from it.
        .self_end()
        .mt(px(c.style.dimensions.menu_top_gap))
        .rounded_t(r)
        .overflow_hidden()
        .child(row);
    // Rest / hover / active come from the one strip treatment, so a menu, an
    // icon button and a tab in the same row cannot drift apart. Active is a
    // filled cap only — no accent strip — so the surface stays continuous
    // with the popover that drops beneath it.
    let mut element = chrome::paint(element, active, c);
    element = element.on_click(move |_event: &ClickEvent, window, app| {
        (Rc::clone(&handler))(&action_copy, window, app);
    });
    if let Some(hover_action) = hover {
        let handler = c.h.clone();
        let action = hover_action.clone();
        element = element.on_hover(move |hovered, window, app| {
            if *hovered {
                (Rc::clone(&handler))(&action, window, app);
            }
        });
    }
    element.into_any_element()
}
