//! `BPanelItem` — one collapsible property section: a `BCard` headed by the
//! section's title, its body one prop row per `BPropSpec` in `spec.props`.
//! Blender ref: a `bpy.types.Panel` in `properties_*.py`, drawn by
//! `interface_panel.cc`.

use super::prop_view::prop_row;
use super::set::BSectionSpec;
use crate::v2::host::{BHostType, host_slug};
use crate::v2::state::{BPath, BState};
use crate::v2::view::prim::BCard;
use crate::v2::view::{BView, BViewItem};

#[derive(Clone, Copy, Debug)]
pub struct BPanelItem {
    pub host: BHostType,
    pub tab: &'static str,
    pub spec: BSectionSpec,
    pub expanded: bool,
}

impl BPanelItem {
    pub fn new(host: BHostType, tab: &'static str, spec: BSectionSpec, expanded: bool) -> Self {
        Self {
            host,
            tab,
            spec,
            expanded,
        }
    }

    /// State key for this section's expanded flag:
    /// `ctx.<host>.<tab>.<section>.expanded`. Including the active tab avoids
    /// collisions between common section names such as Surface and Preview.
    pub fn expand_key(host: BHostType, tab: &str, title: &str) -> BPath {
        BPath::owned(vec![
            host_slug(host),
            leak_slug(tab),
            leak_slug(title),
            "expanded",
        ])
    }
}

/// Leak a slugified title to `&'static str` so it can live in a `BPath`
/// segment. Titles come from a static `SECTIONS` table so the set of leaked
/// strings is bounded by the compiled panel specs.
fn leak_slug(title: &str) -> &'static str {
    Box::leak(
        title
            .to_ascii_lowercase()
            .replace(' ', "_")
            .into_boxed_str(),
    )
}

impl BViewItem for BPanelItem {
    fn build(&self, s: &BState) -> BView {
        let key = Self::expand_key(self.host, self.tab, self.spec.title);
        let rows = if self.expanded { self.spec.props.iter().map(|p| prop_row(p, s)).collect() } else { Vec::new() };
        BCard::panel(self.spec.title).fold(key, self.expanded).body(rows).into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::part::panel::prop::BPropSpec;

    static EMPTY: &[BPropSpec] = &[];

    #[test]
    fn initially_expanded_header_first_click_sets_false() {
        use crate::v2::state::val::V_FALSE;
        use crate::v2::view::prim::BAction;
        let spec = BSectionSpec {
            title: "Surface",
            props: EMPTY,
        };
        let BView::Card(card) = BPanelItem::new(BHostType::Buts, "Material", spec, true).build(&BState::new())
        else {
            panic!()
        };
        let BAction::Set(_, value) = card.fold.as_ref().unwrap().flip() else { panic!() };
        assert_eq!(value, V_FALSE);
        assert_eq!(card.title(), Some("Surface"));
    }
}
