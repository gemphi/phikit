//! The one renderer for `BView::Card` — Blender's panel drawing
//! (`draw_aligned_panel` → `panel_draw_aligned_backdrop` +
//! `panel_draw_aligned_widgets`, `interface_panel.cc`).
//!
//! The header is one strip, `PNL_HEADER` tall: the fold triangle at its left
//! (`ICON_RIGHTARROW` closed, `ICON_DOWNARROW_HLT` open), the title after it,
//! the header's own controls (`draw_header`), then, pushed right, the preset
//! controls (`draw_header_preset`) and the grip (`ICON_GRIP`, half alpha).
//! A closed panel is its header alone, rounded on every corner; an open one
//! rounds the header's top and the backdrop's bottom. The whole header,
//! except what it holds, is the fold's click target, as Blender's is.
//!
//! Every container here is a `BFlex` — this file writes no GPUI styling
//! (`tests/style_budget.rs` starts it at zero).

use super::super::flex::{
    BAlign, BEdge, BFill, BFlex, BFlexed, BJustify, BLen, BOverflow, BRadius, BSpace, BType,
};
use super::super::{ctx::BRenderCtx, walk};
use crate::v2::host::BHostType;
use crate::v2::theme::{BStyleRole, BSurfaceTone};
use crate::v2::view::BView;
use crate::v2::view::prim::{BCard, BCardKind};
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString};
use std::rc::Rc;

enum BCardPart {
    /// The card: backdrop and outline, per kind.
    Frame(BCardKind),
    /// The heading strip; `open` decides which corners it rounds.
    Head { kind: BCardKind, open: bool },
    /// A fixed-size slot in the header: the triangle, the grip.
    Glyph { dimmed: bool },
    /// The title, which takes the header's free space and clips.
    Title,
    /// A run of header controls (`draw_header` / `draw_header_preset`).
    Controls,
    /// The rows under the header.
    Body,
    /// One row; bare text gets a row's own inset so it lines up with rows
    /// that carry theirs.
    Row { text: bool },
    /// The strip under the body — a dialog's actions.
    Foot,
}

fn corner(c: &BRenderCtx) -> f32 {
    c.style.radius_for(BStyleRole::Card)
}

impl BFlexed for BCardPart {
    fn flex(&self, c: &BRenderCtx) -> BFlex {
        match self {
            Self::Frame(kind) => {
                let column = BFlex::column().width(BLen::Full);
                match kind {
                    // No clipping: a dropdown opened from a row has to escape
                    // the card (`file_browser_accordion_refinement`).
                    BCardKind::Panel => column
                        .radius(BRadius::Role(BStyleRole::Card))
                        .border(BEdge::All)
                        .fill(BFill::Tone(panel_tone(c))),
                    BCardKind::Sub => column
                        .radius(BRadius::Role(BStyleRole::Card))
                        .fill(BFill::Tone(BSurfaceTone::Section)),
                    BCardKind::Bare => column,
                }
            }
            Self::Head { kind, open } => {
                let strip = BFlex::row()
                    .width(BLen::Full)
                    .height(BLen::Dim(super::super::flex::BDim::HeaderHeight))
                    .align(BAlign::Center)
                    .gap(BSpace::GapSm)
                    .pad_x(BSpace::PadMd)
                    .type_size(BType::Body)
                    .ink();
                match kind {
                    // Only a top-level panel paints its header
                    // (`panel_draw_aligned_backdrop`: "Panel header backdrops
                    // for non sub-panels").
                    BCardKind::Panel => strip.fill(BFill::Tone(BSurfaceTone::Header)).radius(if *open {
                        BRadius::Top(corner(c))
                    } else {
                        BRadius::Role(BStyleRole::Card)
                    }),
                    // A sub-panel's triangle and title sit 0.7 of a unit in.
                    BCardKind::Sub => strip.pad_left(BSpace::PadLg),
                    BCardKind::Bare => strip,
                }
            }
            Self::Glyph { dimmed } => {
                let cell = BFlex::row().align(BAlign::Center).justify(BJustify::Center).keeps_size();
                if *dimmed { cell.dimmed() } else { cell }
            }
            Self::Title => BFlex::row()
                .fills()
                .min_width(BLen::Zero)
                .align(BAlign::Center)
                .overflow(BOverflow::Clip),
            Self::Controls => BFlex::row().align(BAlign::Center).gap(BSpace::GapXs).keeps_size(),
            Self::Body => BFlex::column()
                .width(BLen::Full)
                .pad_x(BSpace::CardInset)
                .pad_y(BSpace::PadXs)
                .gap(BSpace::GapXs),
            Self::Row { text } => {
                let row = BFlex::cell().width(BLen::Full);
                if *text { row.pad_x(BSpace::PadSm) } else { row }
            }
            Self::Foot => BFlex::row()
                .width(BLen::Full)
                .align(BAlign::Center)
                .justify(BJustify::End)
                .gap(BSpace::GapSm)
                .pad_x(BSpace::PadMd)
                .pad_y(BSpace::PadSm),
        }
    }
}

/// A panel's body surface. Properties draws its panels on the pane's own
/// surface; everywhere else a card carries the card tone.
fn panel_tone(c: &BRenderCtx) -> BSurfaceTone {
    if c.host == BHostType::Buts { BSurfaceTone::Body } else { BSurfaceTone::Card }
}

/// The name a card's selectors are built from: its fold key, or its title.
fn slot(card: &BCard) -> String {
    match &card.fold {
        Some(fold) => fold.key.encode().replace('.', "-"),
        None => card.title().unwrap_or("card").to_lowercase().replace(' ', "-"),
    }
}

fn tagged(el: gpui::Div, id: String) -> gpui::Stateful<gpui::Div> {
    let selector = id.clone();
    el.id(SharedString::from(id)).debug_selector(move || selector.clone())
}

fn head(card: &BCard, name: &str, c: &BRenderCtx) -> Option<AnyElement> {
    let head = card.head.as_ref()?;
    let open = card.is_open();
    let mut strip = tagged(BCardPart::Head { kind: card.kind, open }.flex(c).div(c), format!("card-head-{name}"));
    if card.fold.is_some() {
        let triangle = if open { "triangle_down" } else { "triangle_right" };
        strip = strip.child(tagged(
            BCardPart::Glyph { dimmed: false }.flex(c).div(c),
            format!("card-fold-{name}"),
        )
        .child(walk(&BView::icon(triangle), c)));
    }
    if let Some(icon) = &head.icon {
        strip = strip.child(BCardPart::Glyph { dimmed: false }.flex(c).div(c).child(walk(&BView::icon(icon.clone()), c)));
    }
    strip = strip.child(
        tagged(BCardPart::Title.flex(c).div(c), format!("card-title-{name}"))
            .child(SharedString::from(head.title.clone())),
    );
    if !head.controls.is_empty() {
        strip = strip.child(controls(&head.controls, c));
    }
    if !head.preset.is_empty() {
        strip = strip.child(controls(&head.preset, c));
    }
    // The grip is a top-level panel's, in a stack it could be reordered in.
    if card.kind == BCardKind::Panel && card.fold.is_some() {
        strip = strip.child(tagged(
            BCardPart::Glyph { dimmed: true }.flex(c).div(c),
            format!("card-grip-{name}"),
        )
        .child(walk(&BView::icon("grip"), c)));
    }
    if let Some(fold) = &card.fold {
        let handler = c.h.clone();
        let action = fold.flip();
        strip = strip
            .cursor(gpui::CursorStyle::PointingHand)
            .on_click(move |_: &ClickEvent, window, app| (Rc::clone(&handler))(&action, window, app));
    }
    Some(strip.into_any_element())
}

/// Header controls take their own clicks: the header's fold is not fired
/// through them (Blender's header buttons sit over the header's hit area).
fn controls(views: &[BView], c: &BRenderCtx) -> AnyElement {
    let mut run = BCardPart::Controls.flex(c).div(c).occlude();
    for v in views {
        run = run.child(walk(v, c));
    }
    run.into_any_element()
}

pub fn view(card: &BCard, c: &BRenderCtx) -> AnyElement {
    let name = slot(card);
    let mut frame = tagged(BCardPart::Frame(card.kind).flex(c).div(c), format!("card-{name}"));
    if let Some(head) = head(card, &name, c) {
        frame = frame.child(head);
    }
    if card.is_open() && !card.body.is_empty() {
        let mut body = tagged(BCardPart::Body.flex(c).div(c), format!("card-content-{name}"));
        for (n, row) in card.body.iter().enumerate() {
            let text = matches!(row, BView::Label { .. });
            body = body.child(
                tagged(BCardPart::Row { text }.flex(c).div(c), format!("card-row-{name}-{n}")).child(walk(row, c)),
            );
        }
        frame = frame.child(body);
    }
    if card.is_open() && !card.foot.is_empty() {
        let mut foot = tagged(BCardPart::Foot.flex(c).div(c), format!("card-foot-{name}"));
        for v in &card.foot {
            foot = foot.child(walk(v, c));
        }
        frame = frame.child(foot);
    }
    frame.into_any_element()
}
