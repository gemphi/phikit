//! `BModalSpec` — static descriptor for one modal.

use super::BModalType;
use crate::v2::spec::{BSpec, BSpecKind};

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BModalSpec {
    pub kind: BModalType,
    pub label: &'static str,
    pub icon: &'static str,
    pub width: f32,
    pub height: f32,
    pub shape: BModalShape,
    /// The editors the dialog raises, declared exactly as a space declares
    /// its areas and built by the same zone builder: the file dialog is a
    /// Center area whose default host is File; Preferences is the Prefs
    /// editor; the render window is an Image editor. Empty for the dialogs
    /// that are Blender menus rather than editors (Splash, About, Help…),
    /// whose body is their own `BViewItem`.
    pub areas: &'static [crate::v2::area::BAreaSpec],
}

/// How a modal takes the window.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BModalShape {
    /// A card of the declared size, centred.
    Card,
    /// The whole window (Welcome, About).
    Fullscreen,
    /// A reading sheet: `share` of the window's width, its full height,
    /// centred — a page over the workspace.
    Sheet { share: f32 },
}

impl BSpec for BModalSpec {
    fn kind(&self) -> BSpecKind {
        BSpecKind::Part(crate::v2::part::BPartType::Custom) // modals rendered as overlay parts
    }
    fn label(&self) -> &'static str {
        self.label
    }
    fn icon(&self) -> &'static str {
        self.icon
    }
}
