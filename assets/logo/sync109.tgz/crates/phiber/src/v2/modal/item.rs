//! `BModalItem` — one modal. Emits `BView::Modal` populated by the
//! per-modal content module.

use super::{
    BModalType, about, collab, command, file_browser, help, profile, progress, reader, render,
    settings, spaces, splash,
};
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BModalItem {
    pub modal: BModalType,
}

impl BModalItem {
    pub fn new(modal: BModalType) -> Self {
        Self { modal }
    }
}

impl BViewItem for BModalItem {
    /// A dialog that raises editors (`spec.areas`) is built exactly as a
    /// space is: its areas go through the zone builder, scoped to the modal
    /// so its slots stay its own. A dialog that is a menu (Splash, About…)
    /// builds its own body.
    fn build(&self, s: &BState) -> BView {
        let spec = self.modal.spec();
        if !spec.areas.is_empty() {
            let zones = crate::v2::area::with_scope(self.modal, || {
                crate::v2::zone::BZoneList::of(spec.areas).items(s)
            });
            let body = match zones.len() {
                1 => zones.into_iter().next().unwrap_or_else(BView::empty),
                _ => BView::column(zones),
            };
            return BView::Modal { kind: self.modal, body: Box::new(body) };
        }
        let body = match self.modal {
            BModalType::Settings => settings::BSettingsModal.build(s),
            BModalType::Help => help::BHelpModal.build(s),
            BModalType::Profile => profile::BProfileModal.build(s),
            BModalType::Command => command::BCommandModal.build(s),
            BModalType::FileBrowser => file_browser::BFileBrowserModal.build(s),
            BModalType::Splash => splash::BSplashModal.build(s),
            BModalType::About => about::BAboutModal.build(s),
            BModalType::Render => render::BRenderModal.build(s),
            BModalType::Spaces => spaces::BSpacesModal.build(s),
            BModalType::Progress => progress::BProgressModal.build(s),
            BModalType::Reader => reader::BReaderModal.build(s),
            BModalType::Collab => collab::BCollabModal.build(s),
        };
        BView::Modal {
            kind: self.modal,
            body: Box::new(body),
        }
    }
}
