//! The path bar — shared by the modal dialog and the File / Asset hosts.
//! Blender's `RGN_TYPE_UI` region, panel
//! `FILEBROWSER_PT_directory_path` (`space_filebrowser.py:414`).
//!
//! This strip is NOT the header. Blender's file-browser header carries only
//! the View and Select menus; the navigation buttons, the directory field,
//! the search field, the display-mode radio and the filter toggle live in a
//! dynamic-height UI region directly beneath it. Phiber had them in the
//! header, which is why the strip overflowed and the menus had nowhere to go.
//!
//! Left → right: Back · Forward · Up · Refresh │ New Folder │ directory │
//! search │ display modes │ filter toggle.

use super::set::{DISPLAY_MODES, FILTERS, NAV};
use super::{history, keys, listing};
use crate::v2::state::BPath;
use crate::v2::view::prim::BPopoverSide;
use crate::v2::state::file_nav::{NAV_NEXT, NAV_PARENT, NAV_PREVIOUS};
use crate::v2::state::{
    BState,
    val::{V_FALSE, V_TRUE},
};
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BControl};
use crate::v2::view::BViewItem;

fn nav_group(s: &BState) -> BView {
    let mut out = Vec::with_capacity(NAV.len());
    for n in NAV {
        // Back / Forward render dimmed when their stack is empty, matching
        // Blender's greyed-out nav buttons.
        let enabled = match n.action {
            NAV_PREVIOUS => history::can_back(s),
            NAV_NEXT => history::can_forward(s),
            NAV_PARENT => listing::parent_of(&listing::current_dir(s)).is_some(),
            _ => true,
        };
        out.push(if enabled {
            BView::Button(
                BControl::new()
                    .with_icon(n.icon)
                    .with_action(BAction::Set(keys::k_nav(), n.action.to_string())),
            )
        } else {
            BView::Button(BControl::new().with_icon(n.icon))
        });
    }
    BView::row(out)
}

fn directory_field(s: &BState) -> BView {
    // Typing a path and pressing Return navigates there, as Blender's
    // directory field does.
    let key = keys::k_path();
    let editing = crate::v2::state::edit::is_editing(s, &key);
    let shown = if editing {
        s.get(&key).unwrap_or("").to_string()
    } else {
        listing::current_dir(s)
    };
    BView::text_field(shown.clone(), shown, editing, BAction::Set(key, String::new()))
}

fn display_modes(s: &BState) -> BView {
    let active = s.get(&keys::k_display()).unwrap_or(DISPLAY_MODES[0].label);
    BView::row(
        DISPLAY_MODES
            .iter()
            .map(|v| {
                BView::Tab(
                    BControl::new()
                        .with_icon(v.icon)
                        .with_active(v.label == active)
                        .with_action(BAction::Set(keys::k_display(), v.label.to_string())),
                )
            })
            .collect(),
    )
}

/// The master filter switch — `FILTER` / `FILTER_FILLED` in Blender. Rendered
/// as a tab so the "on" state gets the same lit cap as every other toggle.
fn filter_toggle(s: &BState) -> BView {
    let on = listing::use_filter(s);
    let next = if on { V_FALSE } else { V_TRUE };
    BView::Tab(
        BControl::new()
            .with_icon("filter")
            .with_active(on)
            .with_action(BAction::Set(keys::k_use_filter(), next.to_string())),
    )
}

/// `FILE_HIDE_DOT`, inverted — the eye is open when hidden files are shown.
fn hidden_toggle(s: &BState) -> BView {
    let on = listing::show_hidden(s);
    let next = if on { V_FALSE } else { V_TRUE };
    BView::Button(
        BControl::new()
            .with_icon(if on { "eye" } else { "eye_off" })
            .with_action(BAction::Set(keys::k_show_hidden(), next.to_string())),
    )
}

// ── Filter popover ─────────────────────────────────────────────────────────

/// The type-filter popover body: hidden-file toggle, separator, 10 type flags.
fn filter_body(s: &BState) -> Vec<BView> {
    let hidden_on = listing::show_hidden(s);
    // Rows of a menu, not buttons: a menu item leads with its check and
    // runs its label from the left edge like every other popover row.
    let mut body = vec![
        BView::MenuItem(
            BControl::new()
                .with_icon(if hidden_on { "check_square" } else { "square" })
                .with_label("Show Hidden Files")
                .with_active(hidden_on)
                .with_action(BAction::Toggle(keys::k_show_hidden())),
        ),
        BView::menu_sep(),
    ];
    for f in FILTERS {
        let fkey = BPath::owned(vec!["file", f.key]);
        let active = s.get(&fkey) != Some(V_FALSE);
        body.push(BView::MenuItem(
            BControl::new()
                .with_icon(f.icon)
                .with_label(f.label)
                .with_active(active)
                .with_action(BAction::Toggle(fkey)),
        ));
    }
    body
}

/// The filter-settings popover (`FILEBROWSER_PT_filter`, a HEADER-region
/// panel Blender opens from the arrow beside the filter toggle).
fn filter_popover(s: &BState) -> BView {
    let fkey = keys::k_filter_open();
    let open = s.get(&fkey) == Some(V_TRUE);
    let toggle = BAction::Set(fkey.clone(), if open { V_FALSE } else { V_TRUE }.to_string());
    let close = BAction::Set(fkey, V_FALSE.to_string());
    let anchor = BView::Button(BControl::new().with_icon("chevron_down").with_action(toggle));
    BView::popover(anchor, filter_body(s), open, close, BPopoverSide::Below)
}

/// The strip's row, in Blender's order (`FILEBROWSER_PT_directory_path`):
/// nav, directory, search. It is the `ui` region's content — the region is
/// the strip, so this is a row and paints nothing itself. The search field
/// lives here rather than in the header's middle, as Blender's
/// `filter_search` does (`host.searches_in_tool_header()`).
pub fn view(host: crate::v2::host::BHostType, s: &BState) -> BView {
    BView::row(vec![
        nav_group(s),
        directory_field(s),
        crate::v2::part::search::BSearch::new(host).build(s),
    ])
}

/// The header's right-hand icons (`FILEBROWSER_HT_header`, after the
/// spacer): the display-mode radio, the hidden-files eye, the filter toggle
/// and its settings popover. The `Filter` part of the File and Asset hosts.
pub fn header_icons(s: &BState) -> BView {
    BView::row(vec![display_modes(s), hidden_toggle(s), filter_toggle(s), filter_popover(s)])
}
