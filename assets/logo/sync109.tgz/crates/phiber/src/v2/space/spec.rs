//! `BSpaceSpec` — one space with its area set inline.

use super::BSpaceType;
use crate::v2::area::BAreaSpec;
use crate::v2::spec::{BSpec, BSpecKind};
use crate::v2::zone::BZoneType;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BSpaceSpec {
    pub kind: BSpaceType,
    pub label: &'static str,
    pub icon: &'static str,
    pub areas: &'static [BAreaSpec],
}

impl BSpec for BSpaceSpec {
    fn kind(&self) -> BSpecKind {
        BSpecKind::Space(self.kind)
    }
    fn label(&self) -> &'static str {
        self.label
    }
    fn icon(&self) -> &'static str {
        self.icon
    }
}

impl BSpaceSpec {
    /// Areas whose slot sits inside the given zone.
    pub fn areas_in(&self, zone: BZoneType) -> &[BAreaSpec] {
        crate::v2::zone::list::areas_in(self.areas, zone)
    }
}
