//! `BZoneList` — iterate the zones of a space.

use super::{BZoneItem, BZoneType};
use crate::v2::area::BAreaSpec;
use crate::v2::space::BSpaceSpec;
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BZoneList<'a> {
    pub areas: &'a [BAreaSpec],
}

impl<'a> BZoneList<'a> {
    pub fn new(space: &'a BSpaceSpec) -> Self {
        Self { areas: space.areas }
    }

    /// The zones of any declared area set — a space's, or a dialog's.
    pub fn of(areas: &'a [BAreaSpec]) -> Self {
        Self { areas }
    }
}

impl<'a> BViewList for BZoneList<'a> {
    fn items(&self, state: &BState) -> Vec<BView> {
        // Zones in screen order, left to right across the middle band: the
        // rail leads. (`ALL` is discriminant order, which the spec table is
        // indexed by, so the rail sits at its end there.)
        BZoneType::IN_ORDER
            .iter()
            .map(|&z| BZoneItem::new(z, areas_in(self.areas, z)).build(state))
            .filter(|v| !v.is_empty())
            .collect()
    }
}

/// The contiguous run of `areas` declared in `zone` (area tables are grouped
/// by zone).
pub fn areas_in(areas: &[BAreaSpec], zone: BZoneType) -> &[BAreaSpec] {
    let mut start = None;
    let mut end = 0usize;
    for (i, a) in areas.iter().enumerate() {
        if a.zone == zone {
            if start.is_none() {
                start = Some(i);
            }
            end = i + 1;
        }
    }
    match start {
        Some(s) => &areas[s..end],
        None => &[],
    }
}
