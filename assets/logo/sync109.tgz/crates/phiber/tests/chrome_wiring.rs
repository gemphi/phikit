//! Window chrome + activity bar + modal wiring.

use phiber::v2::host::BHostType;
use phiber::v2::modal::{BModalItem, BModalType};
use phiber::v2::part::caption::{BCaption, BCaptionSide, CAPTION};
use phiber::v2::state::key::{K_ACTIVITY_TAB, K_MODAL, K_SPACE};
use phiber::v2::state::{BState, action::apply_action};
use phiber::v2::view::prim::BAction;
use phiber::v2::view::{BView, BViewItem};

#[test]
fn an_activity_entry_that_is_not_a_grouping_opens_its_modal() {
    for (label, modal) in [
        ("Home", "splash"),
        ("Chat", "collab"),
        ("Stream", "collab"),
        ("Profile", "profile"),
    ] {
        let mut s = BState::default();
        apply_action(&mut s, &BAction::Set(K_ACTIVITY_TAB, label.into()));
        assert_eq!(s.get(&K_MODAL), Some(modal), "{label}");
    }
}

#[test]
fn a_grouping_entry_opens_its_secondary_strip_instead_of_a_dialog() {
    use phiber::v2::part::activity::options;
    use phiber::v2::state::key::K_ACTIVITY_GROUP;

    for label in ["Spaces", "Settings"] {
        let mut s = BState::default();
        apply_action(&mut s, &BAction::Set(K_ACTIVITY_TAB, label.into()));
        assert_eq!(s.get(&K_ACTIVITY_GROUP), Some(label), "{label} opens its strip");
        assert_ne!(s.get(&K_MODAL), Some("spaces"), "{label} raises no dialog");
        let entry = options::open_group(&s).expect("a group is open");
        assert!(
            !options::options_for(entry, &s).is_empty(),
            "{label} must carry options"
        );
        // Clicking the same icon again puts it away.
        apply_action(&mut s, &BAction::Set(K_ACTIVITY_TAB, label.into()));
        assert_eq!(s.get(&K_ACTIVITY_GROUP), None, "{label} closes on a second click");
    }
}

#[test]
fn an_option_from_the_strip_does_what_it_names() {
    use phiber::v2::part::activity::options;
    use phiber::v2::state::key::K_ACTIVITY_PICK;

    let mut s = BState::default();
    apply_action(&mut s, &BAction::Set(K_ACTIVITY_PICK, "Spaces:Shading".into()));
    assert_eq!(s.get(&K_SPACE), Some(phiber::v2::space::BSpaceType::Shading.slug()));
    assert_eq!(s.get(&K_ACTIVITY_PICK), None, "the pick does not linger");

    let mut s = BState::default();
    apply_action(&mut s, &BAction::Set(K_ACTIVITY_PICK, "Settings:Themes".into()));
    assert_eq!(s.get(&options::prefs_tab_key()), Some("Themes"));
    assert_eq!(s.get(&K_MODAL), Some("settings"), "and raises the screen showing it");
}

#[test]
fn picking_a_space_closes_the_spaces_dialog() {
    let mut s = BState::default();
    apply_action(&mut s, &BAction::Set(K_MODAL, "spaces".into()));
    apply_action(&mut s, &BAction::Set(K_SPACE, "Shading".into()));
    assert_eq!(s.get(&K_SPACE), Some("Shading"));
    assert_eq!(s.get(&K_MODAL), Some(""));
}

#[test]
fn settings_modal_is_the_preferences_host() {
    // A dialog that raises an editor declares it as an area (`spec.areas`)
    // and is built by the zone builder, exactly as a space is: Zone ▸ Area ▸
    // Host. The Preferences dialog is the Prefs editor in a Center area.
    let v = BModalItem::new(BModalType::Settings).build(&BState::default());
    let BView::Modal { body, .. } = v else { panic!("modal") };
    let BView::Zone { kind: phiber::v2::zone::BZoneType::Center, children } = *body else {
        panic!("the dialog's body is its Center zone, got {body:?}")
    };
    let [BView::Area { child, .. }] = children.as_slice() else { panic!("one area") };
    assert!(matches!(**child, BView::Host { kind: BHostType::Prefs, .. }));
    // Every editor dialog is declared the same way.
    for kind in [BModalType::FileBrowser, BModalType::Render] {
        assert!(!kind.spec().areas.is_empty(), "{kind:?} raises an editor through its areas");
    }
}

#[test]
fn command_palette_searches_every_menu_leaf() {
    let hits = phiber::v2::modal::command::palette::hits("open");
    assert!(hits.iter().any(|h| h.path == "File ▸ Open…" || h.path.starts_with("File ▸ Open")), "{:?}", hits.iter().map(|h| &h.path).collect::<Vec<_>>());
    assert!(phiber::v2::modal::command::palette::hits("").len() > 30);
}

#[test]
fn caption_controls_only_in_the_topbar_on_the_platform_side() {
    let s = BState::default();
    let lead = BCaption { host: BHostType::Topbar, side: BCaptionSide::Lead }.build(&s);
    let trail = BCaption { host: BHostType::Topbar, side: BCaptionSide::Trail }.build(&s);
    let shown = if CAPTION == BCaptionSide::Lead { (&lead, &trail) } else { (&trail, &lead) };
    assert!(matches!(shown.0, BView::WindowControls { .. }));
    assert!(shown.1.is_empty());
    assert!(BCaption { host: BHostType::View3D, side: CAPTION }.build(&s).is_empty());
}
