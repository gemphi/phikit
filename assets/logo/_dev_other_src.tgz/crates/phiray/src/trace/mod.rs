//! Rendered mode: GPU ray tracing over a [`GpuBvh`] — primary ray, sun with
//! shadow, short-range ambient occlusion, sky gradient. One dispatch per frame.

mod kernel;
mod lamps;
mod mat;
mod scene;
mod shader;

pub use kernel::{Atlas, Camera, LIGHTS, Light, NO_TEX, Tri};
pub use lamps::Lamps;
pub use shader::{Solid, Solid4, Trace, Trace4, Wire, Wire4};
pub use mat::Mat;
pub use scene::Scene;

use crate::bvh::{Aabb, Bvh, Node};
use crate::gpu::{Gpu, GpuArray, Pass};
use crate::kernel::Dispatch;
use crate::mode::Mode;

pub struct Tracer {
    /// Each large array over `chunks()` bindings.
    nodes: Vec<GpuArray<Node>>,
    faces: Vec<GpuArray<[u32; 4]>>,
    verts: Vec<GpuArray<[f32; 8]>>,
    /// `[table…, atlas…]` (`Scene::table`, `Atlas::words`).
    data: GpuArray<u32>,
    /// `[packed pixel × n, accumulated rgb × n]`.
    px: Option<GpuArray<u32>>,
    /// Items per binding (nodes, faces, vertices) and the atlas offset.
    split: [u32; 4],
    last: Option<Camera>,
    frame: u32,
    pass: Pass,
    size: (u32, u32),
    /// Emissive faces (Camera::glow).
    glow: u32,
    /// Scene diagonal (for ray offsets and AO reach).
    pub extent: f32,
    /// Which kernel draws a frame. Solid is Workbench — one deterministic
    /// dispatch; the others path trace and refine.
    mode: Mode,
}

impl Tracer {
    /// `None` for an empty scene.
    pub fn new(gpu: &Gpu, tris: &[Tri], atlas: &Atlas) -> Option<Self> {
        Self::from_scene(gpu, Scene::from_tris(tris, atlas))
    }

    /// Build from a compact scene; `None` when empty or larger than the device allows.
    pub fn from_scene(gpu: &Gpu, scene: Scene) -> Option<Self> {
        Self::with_limit(gpu, scene, gpu.max_binding())
    }

    /// Like [`Self::from_scene`] with an explicit per-binding byte limit, over as
    /// many bindings per array as the device allows ([`Self::chunks_for`]).
    pub fn with_limit(gpu: &Gpu, scene: Scene, limit: u64) -> Option<Self> {
        Self::with_chunks(gpu, scene, limit, Self::chunks_for(gpu))
    }

    /// 4 bindings per array when the device has 14 storage bindings, else 2.
    pub fn chunks_for(gpu: &Gpu) -> usize {
        if gpu.device.limits().max_storage_buffers_per_shader_stage >= 14 { 4 } else { 2 }
    }

    /// The BVH is built on the CPU (all cores) and compacted; nodes, faces and
    /// vertices are each split over `chunks` (2 or 4) bindings, so a scene may use
    /// `chunks ×` the limit per array (as Blender's GPU backends chunk large buffers).
    pub fn with_chunks(gpu: &Gpu, mut scene: Scene, limit: u64, chunks: usize) -> Option<Self> {
        let chunks = if chunks > 2 { 4 } else { 2 };
        if scene.biggest() > limit * chunks as u64 {
            return None;
        }
        if scene.is_empty() {
            return None;
        }
        let boxes: Vec<Aabb> = scene.boxes();
        scene.seal();
        let bvh = Bvh::build_compact(&boxes, 4);
        // Faces in leaf order, so leaves index faces directly.
        scene.reorder(&bvh.order);
        let s = Bvh::scene(&boxes);
        drop(boxes);
        let extent = (0..3).map(|k| (s.hi[k] - s.lo[k]).powi(2)).sum::<f32>().sqrt().max(1e-3);
        let mut data = scene.table();
        let (glow, atlas_at) = (data[0], data.len() as u32);
        data.extend(scene.atlas.words());
        if data.len() as u64 * 4 > limit {
            return None;
        }
        let verts: Vec<[f32; 8]> = scene.pos.iter().zip(&scene.attr).map(|(p, a)| [p[0], p[1], p[2], p[3], a[0], a[1], a[2], a[3]]).collect();
        let (nodes, n_at) = GpuArray::split(gpu, &bvh.nodes, limit, chunks)?;
        let (faces, f_at) = GpuArray::split(gpu, &scene.faces, limit, chunks)?;
        let (verts, v_at) = GpuArray::split(gpu, &verts, limit, chunks)?;
        Some(Self {
            glow,
            nodes,
            faces,
            verts,
            data: GpuArray::from(gpu, &data),
            px: None,
            split: [n_at, f_at, v_at, atlas_at],
            last: None,
            frame: 0,
            pass: Pass::default(),
            size: (0, 0),
            extent,
            mode: Mode::Rendered,
        })
    }

    /// Items per binding for nodes, faces, vertices (and the atlas offset).
    pub fn split(&self) -> [u32; 4] {
        self.split
    }

    /// Bindings per large array (2 or 4).
    pub fn chunks(&self) -> usize {
        self.nodes.len()
    }

    /// Samples averaged before a still view stops refining.
    pub const SAMPLES: u32 = 32;

    /// Pick the kernel. Changing it drops the recorded pass so the next frame
    /// records the new one.
    pub fn set_mode(&mut self, mode: Mode) {
        if self.mode == mode {
            return;
        }
        self.mode = mode;
        self.pass.clear();
        self.size = (0, 0);
        self.last = None;
        self.frame = 0;
    }

    pub fn mode(&self) -> Mode {
        self.mode
    }

    /// How many samples this mode averages. Workbench and the wire pass are
    /// deterministic, so a second sample would return the same image: one pass
    /// is the frame.
    pub fn samples(&self) -> u32 {
        if self.mode.deterministic() { 1 } else { Self::SAMPLES }
    }

    /// Render `w × h` RGBA8 pixels (row 0 at the top). A repeated camera adds a
    /// sample to the running average; the flag is `true` once refinement is done.
    pub fn render(&mut self, gpu: &Gpu, cam: Camera, w: u32, h: u32) -> (Vec<u8>, bool) {
        let (_, done) = self.sample(gpu, cam, w, h);
        (self.pixels(gpu), done)
    }

    /// Trace one sample without reading it back: `(sample index, done)`.
    pub fn sample(&mut self, gpu: &Gpu, mut cam: Camera, w: u32, h: u32) -> (u32, bool) {
        let (w, h) = (w.max(1), h.max(1));
        let n = w * h;
        cam.w = w;
        cam.h = h;
        if cam.ao <= 0.0 {
            cam.ao = self.extent * 0.08;
        }
        cam.eps = self.extent * 1e-5;
        cam.glow = self.glow;
        cam.split = self.split;
        cam.frame = 0;
        let same = self.last.is_some_and(|l| bytemuck::bytes_of(&l)[8..] == bytemuck::bytes_of(&cam)[8..]) && self.size == (w, h);
        if same && self.frame + 1 >= self.samples() {
            return (self.frame, true);
        }
        self.frame = if same { self.frame + 1 } else { 0 };
        self.last = Some(cam);
        cam.frame = self.frame;
        if self.size != (w, h) || self.pass.is_empty() {
            let px = GpuArray::from(gpu, &vec![0u32; 4 * n as usize]);
            self.pass.clear();
            let arrays = self.nodes.iter().map(|a| a.buffer());
            let arrays = arrays.chain(self.faces.iter().map(|a| a.buffer())).chain(self.verts.iter().map(|a| a.buffer()));
            let bufs: Vec<&wgpu::Buffer> = arrays.chain([self.data.buffer(), px.buffer()]).collect();
            match (self.mode, self.chunks()) {
                (Mode::Wire, 4) => self.pass.add::<Wire4>(gpu, n, cam, &bufs),
                (Mode::Wire, _) => self.pass.add::<Wire>(gpu, n, cam, &bufs),
                (Mode::Solid, 4) => self.pass.add::<Solid4>(gpu, n, cam, &bufs),
                (Mode::Solid, _) => self.pass.add::<Solid>(gpu, n, cam, &bufs),
                (_, 4) => self.pass.add::<Trace4>(gpu, n, cam, &bufs),
                _ => self.pass.add::<Trace>(gpu, n, cam, &bufs),
            };
            self.px = Some(px);
            self.size = (w, h);
        } else {
            let d = Dispatch::new(n);
            cam.n = n;
            cam.groups_x = d.x;
            self.pass.set(gpu, 0, 0, &cam);
        }
        self.pass.run(gpu);
        (self.frame, self.frame + 1 >= self.samples())
    }

    /// Linear radiance per pixel (mean of the samples so far), before tone mapping.
    pub fn radiance(&self, gpu: &Gpu) -> Vec<[f32; 3]> {
        let n = (self.size.0 * self.size.1) as usize;
        let words = self.px.as_ref().map(|o| o.read_first(gpu, 4 * n)).unwrap_or_default();
        let k = (self.frame + 1) as f32;
        words[n.min(words.len())..].chunks_exact(3).map(|c| [0, 1, 2].map(|i| f32::from_bits(c[i]) / k)).collect()
    }

    /// The current image (RGBA8).
    pub fn pixels(&self, gpu: &Gpu) -> Vec<u8> {
        let n = (self.size.0 * self.size.1) as usize;
        let px = self.px.as_ref().map(|o| o.read_first(gpu, n)).unwrap_or_default();
        bytemuck::cast_slice(&px).to_vec()
    }
}
