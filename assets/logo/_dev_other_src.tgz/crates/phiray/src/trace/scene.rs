//! Compact GPU scene: shared vertices (position + packed normal/UV, 32 bytes),
//! faces (3 vertex ids + material, 16 bytes) and a material table — about a
//! quarter of the memory of one 160-byte [`Tri`] per triangle.

use super::kernel::{Atlas, Tri};
use super::mat::Mat;
use crate::bvh::Aabb;
use std::collections::HashMap;

/// Octahedral encoding of a unit normal into two floats.
fn oct(n: [f32; 3]) -> [f32; 2] {
    let l = n[0].abs() + n[1].abs() + n[2].abs();
    if l < 1e-12 {
        return [0.0, 0.0];
    }
    let (x, y, z) = (n[0] / l, n[1] / l, n[2] / l);
    if z >= 0.0 {
        [x, y]
    } else {
        [(1.0 - y.abs()) * x.signum(), (1.0 - x.abs()) * y.signum()]
    }
}

/// Packed normal; outside the octahedron (2, 2) marks flat.
fn pack(n: [f32; 3]) -> [f32; 2] {
    if n == [0.0; 3] { [2.0, 2.0] } else { oct(n) }
}

#[derive(Default)]
pub struct Scene {
    pub pos: Vec<[f32; 4]>,
    /// Octahedral normal (xy) + UV (zw). A zero normal packs to (0, 0) → flat.
    pub attr: Vec<[f32; 4]>,
    /// Vertex ids + material id.
    pub faces: Vec<[u32; 4]>,
    pub mats: Vec<Mat>,
    pub atlas: Atlas,
    verts: HashMap<[u32; 7], u32>,
    mat_ids: HashMap<[u32; 17], u32>,
}

impl Scene {
    pub fn new(atlas: Atlas) -> Self {
        Self { atlas, ..Default::default() }
    }

    pub fn from_tris(tris: &[Tri], atlas: &Atlas) -> Self {
        let mut s = Self::new(atlas.clone());
        tris.iter().for_each(|t| s.add(t));
        s
    }

    /// Add one triangle record.
    pub fn add(&mut self, t: &Tri) {
        let uv = [[t.us[0], t.vs[0]], [t.us[1], t.vs[1]], [t.us[2], t.vs[2]]];
        self.push([t.a, t.b, t.c], [t.na, t.nb, t.nc], uv, Mat::of(t));
    }

    fn vert(&mut self, p: [f32; 3], n: [f32; 3], uv: [f32; 2]) -> u32 {
        let o = pack(n);
        let key = [p[0], p[1], p[2], o[0], o[1], uv[0], uv[1]].map(f32::to_bits);
        let next = self.pos.len() as u32;
        *self.verts.entry(key).or_insert_with(|| {
            self.pos.push([p[0], p[1], p[2], 1.0]);
            self.attr.push([o[0], o[1], uv[0], uv[1]]);
            next
        })
    }

    /// Append one vertex with no de-duplication (callers that already share
    /// vertices, e.g. per mesh); returns its id. A zero normal = flat.
    pub fn vertex(&mut self, p: [f32; 3], n: [f32; 3], uv: [f32; 2]) -> u32 {
        let o = pack(n);
        self.pos.push([p[0], p[1], p[2], 1.0]);
        self.attr.push([o[0], o[1], uv[0], uv[1]]);
        self.pos.len() as u32 - 1
    }

    /// Shared id of a material.
    pub fn material(&mut self, mat: Mat) -> u32 {
        let next = self.mats.len() as u32;
        *self.mat_ids.entry(mat.key()).or_insert_with(|| {
            self.mats.push(mat);
            next
        })
    }

    /// Append a face over existing vertex ids.
    pub fn face(&mut self, v: [u32; 3], mat: u32) {
        self.faces.push([v[0], v[1], v[2], mat]);
    }

    pub fn push(&mut self, p: [[f32; 3]; 3], n: [[f32; 3]; 3], uv: [[f32; 2]; 3], mat: Mat) {
        let m = self.material(mat);
        let v = [0, 1, 2].map(|k| self.vert(p[k], n[k], uv[k]));
        self.face(v, m);
    }

    /// Done adding: free the de-duplication maps.
    pub fn seal(&mut self) {
        self.verts = HashMap::new();
        self.mat_ids = HashMap::new();
    }

    pub fn len(&self) -> usize {
        self.faces.len()
    }

    pub fn is_empty(&self) -> bool {
        self.faces.is_empty()
    }

    fn corner(&self, f: usize, k: usize) -> [f32; 3] {
        let p = self.pos[self.faces[f][k] as usize];
        [p[0], p[1], p[2]]
    }

    pub fn boxes(&self) -> Vec<Aabb> {
        (0..self.len()).map(|f| Aabb::of_tri(self.corner(f, 0), self.corner(f, 1), self.corner(f, 2))).collect()
    }

    /// Put faces in BVH leaf order (`order[slot]` = old face).
    pub fn reorder(&mut self, order: &[u32]) {
        self.faces = order.iter().map(|&i| self.faces[i as usize]).collect();
    }

    /// Largest single buffer in bytes.
    pub fn biggest(&self) -> u64 {
        [self.pos.len() * 32, self.faces.len() * 16, self.atlas.words().len() * 4, self.mats.len() * 68 + 64]
            .into_iter()
            .max()
            .unwrap_or(0) as u64
    }

    /// `[lamp count, face ids…, cdf bits…, materials…]` (see `wgsl/layout.wgsl`).
    pub fn table(&self) -> Vec<u32> {
        let area = |f: usize| {
            let (a, b, c) = (self.corner(f, 0), self.corner(f, 1), self.corner(f, 2));
            let (e1, e2) = ([0, 1, 2].map(|k| b[k] - a[k]), [0, 1, 2].map(|k| c[k] - a[k]));
            let cr = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
            0.5 * cr.iter().map(|v| v * v).sum::<f32>().sqrt()
        };
        let glowing: Vec<bool> = self.mats.iter().map(|m| m.power() > 0.0).collect();
        let (ids, pw): (Vec<u32>, Vec<f32>) = (0..self.len())
            .filter(|&f| glowing[self.faces[f][3] as usize])
            .map(|f| (f as u32, area(f) * self.mats[self.faces[f][3] as usize].power()))
            .filter(|(_, p)| *p > 0.0)
            .unzip();
        let total: f32 = pw.iter().sum();
        let mut run = 0.0;
        let mut w = vec![ids.len() as u32];
        w.extend(&ids);
        w.extend(pw.iter().map(|p| {
            run += p;
            (run / total).to_bits()
        }));
        w.extend(self.mats.iter().flat_map(|m| m.key()));
        w
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::trace::NO_TEX;

    #[test]
    fn shares_vertices_and_materials() {
        let n = [[0.0, 0.0, 1.0]; 3];
        let c = [0.5; 4];
        let q = [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0]];
        let tris = [Tri::new([q[0], q[1], q[2]], n, c), Tri::new([q[0], q[2], q[3]], n, c)];
        let s = Scene::from_tris(&tris, &Atlas::default());
        assert_eq!((s.pos.len(), s.faces.len(), s.mats.len()), (4, 2, 1));
        assert_eq!(s.mats[0].tex, NO_TEX);
        assert_eq!(oct([0.0, 0.0, -1.0]).map(|v| v.abs()), [1.0, 1.0]);
    }
}
