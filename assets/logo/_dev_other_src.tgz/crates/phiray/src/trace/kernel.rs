//! The tracer's data types (the kernels are in `shader.rs`).

use crate::bvh::Aabb;
use bytemuck::{Pod, Zeroable};

/// A triangle: vertex normals, linear base colour (alpha = Principled Alpha),
/// PBR inputs and optional texture (160 bytes).
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Pod, Zeroable)]
pub struct Tri {
    pub a: [f32; 3],
    pub rough: f32,
    pub na: [f32; 3],
    /// Transmission weight (glass).
    pub trans: f32,
    pub b: [f32; 3],
    pub metal: f32,
    pub nb: [f32; 3],
    /// Index of refraction.
    pub ior: f32,
    pub c: [f32; 3],
    pub _c: f32,
    pub nc: [f32; 3],
    pub _nc: f32,
    pub color: [f32; 4],
    /// Corner UVs (u of a, b, c) and texture id (`NO_TEX` = none).
    pub us: [f32; 3],
    pub tex: u32,
    /// Corner UVs (v of a, b, c).
    pub vs: [f32; 3],
    /// Normal map texture id (`NO_TEX` = none).
    pub nmap: u32,
    /// Emitted radiance (linear).
    pub emit: [f32; 3],
    /// Normal Map node strength.
    pub bump: f32,
    /// Roughness / metallic / emission texture ids (`NO_TEX` = none); each
    /// multiplies the matching value (Blender replaces the socket, so the
    /// caller passes 1 there).
    pub maps: [u32; 3],
    pub _m: u32,
}

/// `Tri::tex` value for untextured triangles.
pub const NO_TEX: u32 = u32::MAX;

impl Tri {
    pub fn new(p: [[f32; 3]; 3], n: [[f32; 3]; 3], color: [f32; 4]) -> Self {
        Self { a: p[0], b: p[1], c: p[2], na: n[0], nb: n[1], nc: n[2], color, rough: 0.5, ior: 1.5, tex: NO_TEX, nmap: NO_TEX, maps: [NO_TEX; 3], ..Default::default() }
    }

    /// Texture `tex` (from [`Atlas::add`]) mapped by corner UVs; it multiplies `color`.
    pub fn with_texture(mut self, tex: u32, uv: [[f32; 2]; 3]) -> Self {
        self.tex = tex;
        self.us = [uv[0][0], uv[1][0], uv[2][0]];
        self.vs = [uv[0][1], uv[1][1], uv[2][1]];
        self
    }

    /// Tangent-space normal map (atlas id, raw bytes) with the node's strength;
    /// uses the same corner UVs as [`Self::with_texture`].
    pub fn with_normal_map(mut self, id: u32, strength: f32, uv: [[f32; 2]; 3]) -> Self {
        (self.nmap, self.bump) = (id, strength);
        self.us = [uv[0][0], uv[1][0], uv[2][0]];
        self.vs = [uv[0][1], uv[1][1], uv[2][1]];
        self
    }

    /// Emission (colour × strength), transmission weight and IOR.
    pub fn with_optics(mut self, emit: [f32; 3], trans: f32, ior: f32) -> Self {
        (self.emit, self.trans, self.ior) = (emit, trans.clamp(0.0, 1.0), ior.max(1.0));
        self
    }

    /// Roughness / metallic / emission-colour textures (atlas ids, `NO_TEX` for
    /// none); each multiplies its value, with the same corner UVs as
    /// [`Self::with_texture`].
    pub fn with_maps(mut self, maps: [u32; 3], uv: [[f32; 2]; 3]) -> Self {
        self.maps = maps;
        self.us = [uv[0][0], uv[1][0], uv[2][0]];
        self.vs = [uv[0][1], uv[1][1], uv[2][1]];
        self
    }

    /// Principled roughness / metallic.
    pub fn with_pbr(mut self, rough: f32, metal: f32) -> Self {
        (self.rough, self.metal) = (rough.clamp(0.02, 1.0), metal.clamp(0.0, 1.0));
        self
    }

    pub fn bounds(&self) -> Aabb {
        Aabb::of_tri(self.a, self.b, self.c)
    }
}

/// View for one frame. Screen `u, v ∈ [-0.5, 0.5]`; view-space point
/// `x = (u − pan.x) / scale`, `y = −(v / aspect − pan.y) / scale`, placed on the
/// basis `right, up, back` around `pivot` and divided by `units` (view units per
/// world unit). Perspective puts the eye `dist` along `back`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, Pod, Zeroable)]
pub struct Camera {
    pub n: u32,
    pub groups_x: u32,
    pub w: u32,
    pub h: u32,
    pub right: [f32; 3],
    pub persp: u32,
    pub up: [f32; 3],
    pub scale: f32,
    pub back: [f32; 3],
    pub units: f32,
    pub pivot: [f32; 3],
    pub aspect: f32,
    /// Direction *towards* the sun (world).
    pub sun: [f32; 3],
    pub dist: f32,
    /// Background (display space).
    pub sky: [f32; 4],
    pub pan: [f32; 2],
    /// AO reach in world units (0 = auto).
    pub ao: f32,
    /// Ray offset (set by the tracer).
    pub eps: f32,
    /// Accumulated sample index (set by the tracer).
    pub frame: u32,
    /// Floor grid spacing in world units (0 = no grid).
    pub grid: f32,
    /// Used entries of `lights`; 0 = studio three-point rig around the view.
    pub count: u32,
    /// Emissive triangles in the scene (set by the tracer); > 0 lets
    /// indirect rays pick up light from glowing meshes.
    pub glow: u32,
    /// Grid line colour (display space, alpha = strength).
    pub grid_color: [f32; 4],
    /// World radiance (linear) for ambient light and reflections.
    pub env: [f32; 4],
    /// Where the second chunk starts for nodes, faces, vertices; atlas start in `data`
    /// (set by the tracer).
    pub split: [u32; 4],
    pub lights: [Light; LIGHTS],
}

pub const LIGHTS: usize = 16;

/// A Blender light (`kind`: 0 sun, 1 point, 2 spot, 3 area).
/// `color` is colour × strength (sun, W/m²) or colour × power (W).
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Pod, Zeroable)]
pub struct Light {
    pub pos: [f32; 3],
    pub kind: u32,
    pub color: [f32; 3],
    /// Soft-shadow size: sun angle (rad) or radius (m).
    pub size: f32,
    /// Direction the light shines (sun, spot, area).
    pub dir: [f32; 3],
    /// Spot: cosine of the half cone angle.
    pub cone: f32,
}

/// All textures in one `u32` buffer: `[count, (offset, w, h) × count, texels…]`,
/// texels packed RGBA8 (sRGB), row 0 at the top.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Atlas {
    heads: Vec<[u32; 3]>,
    texels: Vec<u32>,
}

impl Atlas {
    /// Add an image, box-downsampled by a whole factor until neither side
    /// exceeds `max_side`. Blender's Preferences → Viewport → Textures →
    /// *Limit Size* (`U.glreslimit`) does the same on upload; without it a
    /// character's 4K maps put the whole atlas past one storage binding and
    /// the GPU declined the scene outright.
    pub fn add_bounded(&mut self, w: u32, h: u32, rgba: &[u8], max_side: u32) -> u32 {
        let mut f = 1u32;
        while (w / f).max(h / f) > max_side.max(1) && f < w.max(h) {
            f *= 2;
        }
        if f == 1 {
            return self.add(w, h, rgba);
        }
        let (ow, oh) = ((w / f).max(1), (h / f).max(1));
        let mut out = vec![0u8; (ow * oh * 4) as usize];
        let at = |x: u32, y: u32| ((y * w + x) * 4) as usize;
        for y in 0..oh {
            for x in 0..ow {
                let mut sum = [0u32; 4];
                let mut n = 0u32;
                for dy in 0..f {
                    for dx in 0..f {
                        let (sx, sy) = (x * f + dx, y * f + dy);
                        if sx < w && sy < h && at(sx, sy) + 4 <= rgba.len() {
                            let p = &rgba[at(sx, sy)..at(sx, sy) + 4];
                            for k in 0..4 { sum[k] += p[k] as u32; }
                            n += 1;
                        }
                    }
                }
                let o = ((y * ow + x) * 4) as usize;
                for k in 0..4 { out[o + k] = if n == 0 { 0 } else { (sum[k] / n) as u8 }; }
            }
        }
        self.add(ow, oh, &out)
    }

    /// Bytes this atlas will occupy on the GPU (`words()` × 4).
    pub fn bytes(&self) -> u64 {
        (1 + 3 * self.heads.len() + self.texels.len()) as u64 * 4
    }

    pub fn add(&mut self, w: u32, h: u32, rgba: &[u8]) -> u32 {
        let px = (w * h) as usize;
        self.heads.push([self.texels.len() as u32, w, h]);
        self.texels.extend(rgba.chunks_exact(4).take(px).map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]])));
        self.texels.resize(self.heads.last().map_or(0, |h| h[0] as usize) + px, 0xff00ffff);
        self.heads.len() as u32 - 1
    }

    pub fn len(&self) -> usize {
        self.heads.len()
    }

    pub fn is_empty(&self) -> bool {
        self.heads.is_empty()
    }

    pub fn words(&self) -> Vec<u32> {
        let base = 1 + 3 * self.heads.len() as u32;
        let mut out = vec![self.heads.len() as u32];
        out.extend(self.heads.iter().flat_map(|h| [h[0] + base, h[1], h[2]]));
        out.extend_from_slice(&self.texels);
        out
    }
}
