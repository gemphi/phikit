//! The path-tracing kernels (WGSL in `wgsl/`).

use super::kernel::Camera;
use crate::kernel::{Bind, Kernel};

/// The path tracer with each large array over 2 bindings (8 storage bindings).
pub struct Trace;

/// The same tracer over 4 bindings per array (14 storage bindings).
pub struct Trace4;

const R: Bind = Bind::Read;

/// Workbench (Solid) over 2 bindings per array.
pub struct Solid;

/// Wireframe over 2 bindings per array.
pub struct Wire;

/// Wireframe over 4 bindings per array.
pub struct Wire4;

/// Workbench (Solid) over 4 bindings per array.
pub struct Solid4;

macro_rules! trace_wgsl {
    ($binds:literal) => {
        concat!(
            include_str!("wgsl/layout.wgsl"),
            include_str!($binds),
            include_str!("wgsl/texture.wgsl"),
            include_str!("wgsl/bvh.wgsl"),
            include_str!("wgsl/util.wgsl"),
            include_str!("wgsl/light.wgsl"),
            include_str!("wgsl/shade.wgsl"),
        )
    };
}

// Solid and Wire need no lighting integrator: one primary ray, done. They
// differ only in the entry point, so they share the prelude.
macro_rules! direct_wgsl {
    ($binds:literal, $main:literal) => {
        concat!(
            include_str!("wgsl/layout.wgsl"),
            include_str!($binds),
            include_str!("wgsl/texture.wgsl"),
            include_str!("wgsl/bvh.wgsl"),
            include_str!("wgsl/util.wgsl"),
            include_str!("wgsl/workbench.wgsl"),
            include_str!($main),
        )
    };
}

impl Kernel for Trace {
    const NAME: &'static str = "trace";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = trace_wgsl!("wgsl/binds2.wgsl");
}

impl Kernel for Trace4 {
    const NAME: &'static str = "trace4";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = trace_wgsl!("wgsl/binds4.wgsl");
}

impl Kernel for Solid {
    const NAME: &'static str = "solid";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = direct_wgsl!("wgsl/binds2.wgsl", "wgsl/solid.wgsl");
}

impl Kernel for Solid4 {
    const NAME: &'static str = "solid4";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = direct_wgsl!("wgsl/binds4.wgsl", "wgsl/solid.wgsl");
}

impl Kernel for Wire {
    const NAME: &'static str = "wire";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = direct_wgsl!("wgsl/binds2.wgsl", "wgsl/wire.wgsl");
}

impl Kernel for Wire4 {
    const NAME: &'static str = "wire4";
    const BINDS: &'static [Bind] = &[R, R, R, R, R, R, R, R, R, R, R, R, R, Bind::Write];
    type Params = Camera;
    const WGSL: &'static str = direct_wgsl!("wgsl/binds4.wgsl", "wgsl/wire.wgsl");
}
