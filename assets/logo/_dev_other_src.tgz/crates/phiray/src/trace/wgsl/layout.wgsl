struct Camera {
    n: u32, groups_x: u32, w: u32, h: u32,
    right: vec3<f32>, persp: u32,
    up: vec3<f32>, scale: f32,
    back: vec3<f32>, units: f32,
    pivot: vec3<f32>, aspect: f32,
    sun: vec3<f32>, dist: f32,
    sky: vec4<f32>,
    pan: vec2<f32>, ao: f32, eps: f32,
    frame: u32, grid: f32, count: u32, glow: u32,
    grid_color: vec4<f32>,
    env: vec4<f32>,
    split: vec4<u32>,
    lights: array<Light, 16>,
}
struct Light { pos: vec3<f32>, kind: u32, color: vec3<f32>, size: f32, dir: vec3<f32>, cone: f32 }
struct Node { lo: vec3<f32>, li: u32, hi: vec3<f32>, ri: u32 }
struct Tri {
    a: vec3<f32>, rough: f32, na: vec3<f32>, trans: f32,
    b: vec3<f32>, metal: f32, nb: vec3<f32>, ior: f32,
    c: vec3<f32>, _c: f32, nc: vec3<f32>, _nc: f32,
    color: vec4<f32>,
    us: vec3<f32>, tex: u32,
    vs: vec3<f32>, nmap: u32,
    emit: vec3<f32>, bump: f32,
    // Roughness / metallic / emission textures (NO_TEX = none).
    maps: vec3<u32>,
}
struct Hit { t: f32, tri: u32, u: f32, v: f32 }

const LEAF: u32 = 0x80000000u;
// Words per material record (`Mat`).
const MAT_WORDS: u32 = 17u;
const NO_TEX: u32 = 0xffffffffu;
const INF: f32 = 3.0e38;

@group(0) @binding(0) var<uniform> p: Camera;
struct Vert { p: vec4<f32>, a: vec4<f32> }

fn atlas(i: u32) -> u32 { return data[p.split.w + i]; }

fn tf(i: u32) -> f32 { return bitcast<f32>(data[i]); }

// First word of face `f`'s material.
fn mat_at(f: u32) -> u32 { return 1u + 2u * data[0] + MAT_WORDS * face(f).w; }

fn unoct(e: vec2<f32>) -> vec3<f32> {
    if (e.x > 1.5) { return vec3<f32>(0.0); }
    var n = vec3<f32>(e, 1.0 - abs(e.x) - abs(e.y));
    if (n.z < 0.0) {
        n = vec3<f32>((1.0 - abs(e.y)) * sign(e.x), (1.0 - abs(e.x)) * sign(e.y), n.z);
    }
    return normalize(n);
}

// Assemble face `f` as a full triangle record.
fn tri_at(f: u32) -> Tri {
    let v = face(f);
    let m = mat_at(f);
    let x = vert(v.x);
    let y = vert(v.y);
    let z = vert(v.z);
    let a0 = x.a;
    let a1 = y.a;
    let a2 = z.a;
    return Tri(
        x.p.xyz, tf(m + 4u), unoct(a0.xy), tf(m + 6u),
        y.p.xyz, tf(m + 5u), unoct(a1.xy), tf(m + 7u),
        z.p.xyz, 0.0, unoct(a2.xy), 0.0,
        vec4<f32>(tf(m), tf(m + 1u), tf(m + 2u), tf(m + 3u)),
        vec3<f32>(a0.z, a1.z, a2.z), data[m + 12u],
        vec3<f32>(a0.w, a1.w, a2.w), data[m + 13u],
        vec3<f32>(tf(m + 8u), tf(m + 9u), tf(m + 10u)), tf(m + 11u),
        vec3<u32>(data[m + 14u], data[m + 15u], data[m + 16u]),
    );
}

