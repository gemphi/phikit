// Solid mode's whole frame: one primary ray per pixel, shaded by the studio
// rig. No jitter, no bounces, no accumulation — Workbench is deterministic, so
// asking for a second sample would return the same image.
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = item(gid, p.groups_x);
    if (i >= p.n) { return; }
    let su = (f32(i % p.w) + 0.5) / f32(p.w) - 0.5;
    let sv = (f32(i / p.w) + 0.5) / f32(p.h) - 0.5;
    let vx = (su - p.pan.x) / p.scale;
    let vy = -(sv / p.aspect - p.pan.y) / p.scale;
    var o: vec3<f32>;
    var d: vec3<f32>;
    if (p.persp != 0u) {
        o = p.pivot + p.back * (p.dist / p.units);
        d = normalize(p.right * vx + p.up * vy - p.back * p.dist);
    } else {
        o = p.pivot + (p.right * vx + p.up * vy + p.back * 1.0e4) / p.units;
        d = -p.back;
    }
    let pix = 1.0 / (p.scale * p.units * f32(p.w));
    let sky = mix(p.sky.rgb * 1.08, p.sky.rgb * 0.85, clamp(sv + 0.5, 0.0, 1.0));

    let h = trace(o, d, INF, false);
    if (h.tri == 0xffffffffu) {
        once(i, floor_grid(o, d, INF, pix, sky));
        return;
    }
    let t = tri_at(h.tri);
    let w = 1.0 - h.u - h.v;
    let bary = vec3<f32>(w, h.u, h.v);
    let ng0 = normalize(cross(t.b - t.a, t.c - t.a));
    let front = dot(ng0, d) < 0.0;
    let ng = select(-ng0, ng0, front);
    var n = t.na * w + t.nb * h.u + t.nc * h.v;
    n = select(ng, normalize(n) * select(-1.0, 1.0, front), dot(n, n) > 1e-12);
    if (t.nmap != NO_TEX) { n = mapped_normal(t, n, bary); }

    var base = max(t.color.rgb, vec3<f32>(0.0));
    var rough = t.rough;
    var metal = t.metal;
    let uv = vec2<f32>(dot(t.us, bary), dot(t.vs, bary));
    if (t.tex != NO_TEX) { base *= sample_tex(t.tex, uv).rgb; }
    if (t.maps.x != NO_TEX) { rough *= sample_raw(t.maps.x, uv).r; }
    if (t.maps.y != NO_TEX) { metal *= sample_raw(t.maps.y, uv).r; }

    // The rig is fixed to the camera, so the normal goes into view space:
    // +x right, +y up, +z toward the viewer.
    let nv = vec3<f32>(dot(n, p.right), dot(n, p.up), dot(n, p.back));
    let col = workbench(base, clamp(rough, 0.0, 1.0), clamp(metal, 0.0, 1.0), nv)
            + emit_at(t, bary);
    // Standard view transform: scene-linear → sRGB display.
    once(i, floor_grid(o, d, h.t, pix, srgb(col)));
}
