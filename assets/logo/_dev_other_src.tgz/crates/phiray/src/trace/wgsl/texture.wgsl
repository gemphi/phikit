fn texel(base: u32, w: u32, x: i32, y: i32) -> vec4<f32> {
    let c = atlas(base + u32(y) * w + u32(x));
    return vec4<f32>(f32(c & 255u), f32((c >> 8u) & 255u), f32((c >> 16u) & 255u), f32(c >> 24u)) / 255.0;
}

// Colour textures are sRGB; normal maps are read raw (`sample_raw`).
fn sample_tex(id: u32, uv: vec2<f32>) -> vec4<f32> {
    let s = sample_raw(id, uv);
    return vec4<f32>(pow(s.rgb, vec3<f32>(2.2)), s.a);
}

// Emitted radiance at barycentrics `bary` (emission texture when linked).
fn emit_at(t: Tri, bary: vec3<f32>) -> vec3<f32> {
    if (t.maps.z == NO_TEX) { return t.emit; }
    let uv = vec2<f32>(dot(t.us, bary), dot(t.vs, bary));
    return t.emit * sample_tex(t.maps.z, uv).rgb;
}

// Tangent-space normal from triangle `t`'s normal map, around shading normal `n`.
fn mapped_normal(t: Tri, n: vec3<f32>, bary: vec3<f32>) -> vec3<f32> {
    let uv = vec2<f32>(dot(t.us, bary), dot(t.vs, bary));
    let raw = sample_raw(t.nmap, uv).xyz * 2.0 - 1.0;
    let ts = normalize(mix(vec3<f32>(0.0, 0.0, 1.0), raw, clamp(t.bump, 0.0, 10.0)));
    let e1 = t.b - t.a;
    let e2 = t.c - t.a;
    let du1 = t.us.y - t.us.x;
    let dv1 = t.vs.y - t.vs.x;
    let du2 = t.us.z - t.us.x;
    let dv2 = t.vs.z - t.vs.x;
    let det = du1 * dv2 - du2 * dv1;
    if (abs(det) < 1e-12) { return n; }
    let tu = (e1 * dv2 - e2 * dv1) / det;
    let tv = (e2 * du1 - e1 * du2) / det;
    let tan = normalize(tu - n * dot(n, tu));
    let bit = cross(n, tan) * select(-1.0, 1.0, dot(cross(n, tan), tv) >= 0.0);
    return normalize(tan * ts.x + bit * ts.y + n * ts.z);
}

// Bilinear, repeat-wrapped, v up (Blender) → row 0 at the top.
fn sample_raw(id: u32, uv: vec2<f32>) -> vec4<f32> {
    if (id >= atlas(0u)) { return vec4<f32>(1.0); }
    let base = atlas(1u + 3u * id);
    let w = atlas(2u + 3u * id);
    let h = atlas(3u + 3u * id);
    let fx = fract(uv.x) * f32(w) - 0.5;
    let fy = (1.0 - fract(uv.y)) * f32(h) - 0.5;
    let x0 = i32(floor(fx));
    let y0 = i32(floor(fy));
    let tx = fx - f32(x0);
    let ty = fy - f32(y0);
    let wi = i32(w);
    let hi = i32(h);
    let xa = (x0 % wi + wi) % wi;
    let xb = (xa + 1) % wi;
    let ya = (y0 % hi + hi) % hi;
    let yb = (ya + 1) % hi;
    let top = mix(texel(base, w, xa, ya), texel(base, w, xb, ya), tx);
    let bot = mix(texel(base, w, xa, yb), texel(base, w, xb, yb), tx);
    return mix(top, bot, ty);
}

