// Wireframe shading (`V3D_SHADING_WIREFRAME`): the mesh's edges, depth-tested.
//
// One primary ray per pixel, as in Solid. Where it hits, the distance from the
// hit point to each of the triangle's three edges decides whether this pixel
// is on a wire: for barycentrics (a, b, c) the perpendicular distance to the
// edge opposite each vertex is that vertex's weight times the triangle's
// height on that edge, `2 * area / |edge|`. Comparing that against the pixel's
// world footprint gives a line of constant screen width at any depth.
//
// Because it is a real ray cast, the wire is hidden-surface correct: an edge
// behind a face does not draw. The CPU stroke path it replaces had no depth
// test at all, so every edge in the scene drew over every other.
//
// In this mode `p.env` carries the wire colour — there is no environment to
// reflect in a wireframe.
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = item(gid, p.groups_x);
    if (i >= p.n) { return; }
    let su = (f32(i % p.w) + 0.5) / f32(p.w) - 0.5;
    let sv = (f32(i / p.w) + 0.5) / f32(p.h) - 0.5;
    let vx = (su - p.pan.x) / p.scale;
    let vy = -(sv / p.aspect - p.pan.y) / p.scale;
    var o: vec3<f32>;
    var d: vec3<f32>;
    if (p.persp != 0u) {
        o = p.pivot + p.back * (p.dist / p.units);
        d = normalize(p.right * vx + p.up * vy - p.back * p.dist);
    } else {
        o = p.pivot + (p.right * vx + p.up * vy + p.back * 1.0e4) / p.units;
        d = -p.back;
    }
    let pix = 1.0 / (p.scale * p.units * f32(p.w));
    let sky = mix(p.sky.rgb * 1.08, p.sky.rgb * 0.85, clamp(sv + 0.5, 0.0, 1.0));

    let h = trace(o, d, INF, false);
    if (h.tri == 0xffffffffu) {
        once(i, floor_grid(o, d, INF, pix, sky));
        return;
    }
    let t = tri_at(h.tri);
    let bary = vec3<f32>(1.0 - h.u - h.v, h.u, h.v);

    // Twice the triangle's area, and the length of the edge opposite each
    // vertex: BC, CA, AB.
    let area2 = length(cross(t.b - t.a, t.c - t.a));
    let e = vec3<f32>(length(t.c - t.b), length(t.a - t.c), length(t.b - t.a));
    let heights = area2 / max(e, vec3<f32>(1e-12));
    let dist = min(min(bary.x * heights.x, bary.y * heights.y), bary.z * heights.z);

    // The pixel's footprint where the ray landed: constant under an
    // orthographic view, growing with distance under a perspective one.
    var foot = pix;
    if (p.persp != 0u) { foot = pix * h.t * p.units / p.dist; }
    // Half a line width, plus half a pixel of feather so the wire does not
    // crawl as the view turns.
    let half = foot * 0.75;
    let wire = 1.0 - smoothstep(half, half + foot * 0.5, dist);

    let behind = floor_grid(o, d, h.t, pix, sky);
    once(i, mix(behind, p.env.rgb, wire));
}
