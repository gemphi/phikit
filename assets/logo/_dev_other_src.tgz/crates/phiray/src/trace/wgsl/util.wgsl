fn hash(x: u32) -> u32 {
    var h = x * 747796405u + 2891336453u;
    h = ((h >> ((h >> 28u) + 4u)) ^ h) * 277803737u;
    return (h >> 22u) ^ h;
}

fn rnd(seed: ptr<function, u32>) -> f32 {
    *seed = hash(*seed);
    return f32(*seed) / 4294967295.0;
}

// Display value → scene-linear (inverse of `pow(aces(x), 1/2.2)`), so samples
// average in linear light and bright noise does not bias the result.
fn to_scene(disp: vec3<f32>) -> vec3<f32> {
    let y = clamp(pow(max(disp, vec3<f32>(0.0)), vec3<f32>(2.2)), vec3<f32>(0.0), vec3<f32>(0.995));
    let a = 2.43 * y - 2.51;
    let b = 0.59 * y - 0.03;
    let c = 0.14 * y;
    return max((-b - sqrt(max(b * b - 4.0 * a * c, vec3<f32>(0.0)))) / (2.0 * a), vec3<f32>(0.0));
}

fn to_display(x: vec3<f32>) -> vec3<f32> {
    let t = clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), vec3<f32>(0.0), vec3<f32>(1.0));
    return pow(t, vec3<f32>(1.0 / 2.2));
}

// Blend this sample (display value) into the linear running average and
// write the display pixel. The average's words hold scene-linear radiance.
fn emit(i: u32, disp: vec3<f32>) {
    let a = p.n + 3u * i;
    let old = vec3<f32>(bitcast<f32>(px[a]), bitcast<f32>(px[a + 1u]), bitcast<f32>(px[a + 2u]));
    let sum = select(vec3<f32>(0.0), old, p.frame > 0u) + to_scene(disp);
    px[a] = bitcast<u32>(sum.x);
    px[a + 1u] = bitcast<u32>(sum.y);
    px[a + 2u] = bitcast<u32>(sum.z);
    px[i] = pack(to_display(sum / f32(p.frame + 1u)));
}

// Floor grid on z = 0 (Blender overlay): lines every `grid`, X axis red, Y axis green.
fn floor_grid(o: vec3<f32>, d: vec3<f32>, t_hit: f32, px: f32, base: vec3<f32>) -> vec3<f32> {
    if (p.grid <= 0.0 || abs(d.z) < 1e-6) { return base; }
    let t = -o.z / d.z;
    if (t <= 0.0 || t >= t_hit) { return base; }
    let q = o + d * t;
    var foot = px;
    if (p.persp != 0u) { foot = px * t * p.units / p.dist; }
    let cell = q.xy / p.grid;
    let dist = abs(cell - round(cell)) * p.grid;
    let w = foot * 0.9;
    let line = max(1.0 - smoothstep(0.0, w, dist.x), 1.0 - smoothstep(0.0, w, dist.y));
    let fade = clamp(1.0 - foot / (p.grid * 0.08), 0.0, 1.0) * clamp(abs(d.z) * 6.0, 0.0, 1.0);
    var c = mix(base, p.grid_color.rgb, line * p.grid_color.a * fade);
    if (abs(q.y) < w) { c = mix(c, vec3<f32>(0.85, 0.3, 0.33), 0.8); }
    if (abs(q.x) < w) { c = mix(c, vec3<f32>(0.47, 0.72, 0.2), 0.8); }
    return c;
}

// Blender's "Standard" view transform: scene-linear to sRGB display.
fn srgb(c: vec3<f32>) -> vec3<f32> {
    let x = clamp(c, vec3<f32>(0.0), vec3<f32>(1.0));
    let lo = x * 12.92;
    let hi = 1.055 * pow(x, vec3<f32>(1.0 / 2.4)) - 0.055;
    return select(hi, lo, x <= vec3<f32>(0.0031308));
}

// A finished pixel: Solid mode is deterministic, so its value is written
// straight out rather than averaged into the sample buffer.
fn once(i: u32, disp: vec3<f32>) {
    px[i] = pack(disp);
}

fn pack(c: vec3<f32>) -> u32 {
    let q = vec3<u32>(clamp(c, vec3<f32>(0.0), vec3<f32>(1.0)) * 255.0 + 0.5);
    return q.r | (q.g << 8u) | (q.b << 16u) | (255u << 24u);
}

