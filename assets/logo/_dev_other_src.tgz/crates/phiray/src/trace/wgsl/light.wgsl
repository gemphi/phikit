const PI: f32 = 3.14159265;

fn onb(n: vec3<f32>, a: f32, b: f32) -> vec3<f32> {
    let tx = normalize(select(cross(n, vec3<f32>(0.0, 0.0, 1.0)), cross(n, vec3<f32>(1.0, 0.0, 0.0)), abs(n.z) > 0.9));
    let ty = cross(n, tx);
    return tx * a + ty * b;
}

// Direction inside a cone of half-angle `ang` around `axis`.
fn cone_dir(axis: vec3<f32>, ang: f32, seed: ptr<function, u32>) -> vec3<f32> {
    if (ang <= 0.0) { return axis; }
    let r = ang * sqrt(rnd(seed));
    let ph = 2.0 * PI * rnd(seed);
    return normalize(axis + onb(axis, r * cos(ph), r * sin(ph)));
}

fn env_at(d: vec3<f32>) -> vec3<f32> {
    // Brighter above the horizon, darker below (a soft sky dome).
    return p.env.rgb * mix(0.35, 1.15, clamp(d.z * 0.5 + 0.5, 0.0, 1.0));
}

fn aces(x: vec3<f32>) -> vec3<f32> {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), vec3<f32>(0.0), vec3<f32>(1.0));
}

struct Surf { pos: vec3<f32>, n: vec3<f32>, v: vec3<f32>, albedo: vec3<f32>, f0: vec3<f32>, rough: f32 }

// Diffuse + GGX-ish specular for light from `l` with irradiance `e`.
fn brdf(s: Surf, l: vec3<f32>, e: vec3<f32>) -> vec3<f32> {
    let nl = max(dot(s.n, l), 0.0);
    if (nl <= 0.0) { return vec3<f32>(0.0); }
    let hv = normalize(l + s.v);
    let nh = max(dot(s.n, hv), 0.0);
    let a2 = max(s.rough * s.rough * s.rough * s.rough, 1e-4);
    let dd = nh * nh * (a2 - 1.0) + 1.0;
    let dist = a2 / (PI * dd * dd);
    let fres = s.f0 + (1.0 - s.f0) * pow(1.0 - max(dot(hv, s.v), 0.0), 5.0);
    let spec = fres * dist * 0.25;
    return (s.albedo / PI + spec) * e * nl;
}

fn visible(org: vec3<f32>, l: vec3<f32>, dist: f32) -> f32 {
    return select(1.0, 0.0, trace(org, l, dist, true).tri != 0xffffffffu);
}

fn lights(s: Surf, seed: ptr<function, u32>) -> vec3<f32> {
    var c = vec3<f32>(0.0);
    if (p.count == 0u) {
        // Studio rig tied to the view: key (shadowed), fill, rim.
        let key = cone_dir(p.sun, 0.06, seed);
        c += brdf(s, key, vec3<f32>(2.0)) * visible(s.pos, key, INF);
        let fill = normalize(-p.right * 0.8 + p.up * 0.2 + p.back * 0.6);
        c += brdf(s, fill, vec3<f32>(0.45));
        let rim = normalize(p.up * 0.6 - p.back * 0.8 + p.right * 0.2);
        c += brdf(s, rim, vec3<f32>(0.9)) * visible(s.pos, rim, INF);
        return c;
    }
    // Up to 4 lights per sample; with more, pick 4 at random and reweight.
    let many = p.count > 4u;
    let weight = select(1.0, f32(p.count) / 4.0, many);
    for (var k = 0u; k < min(p.count, 4u); k++) {
        var idx = k;
        if (many) { idx = min(u32(rnd(seed) * f32(p.count)), p.count - 1u); }
        let li = p.lights[idx];
        if (li.kind == 0u) {
            let l = cone_dir(-li.dir, li.size * 0.5, seed);
            c += brdf(s, l, li.color) * visible(s.pos, l, INF) * weight;
            continue;
        }
        let r1 = rnd(seed);
        let r2 = rnd(seed);
        let aim = li.pos + onb(normalize(s.pos - li.pos), (r1 - 0.5) * li.size, (r2 - 0.5) * li.size);
        let to = aim - s.pos;
        let d2 = max(dot(to, to), 1e-6);
        let l = to / sqrt(d2);
        var e = li.color / (4.0 * PI * PI * d2);
        if (li.kind == 2u) {
            e *= smoothstep(li.cone, mix(li.cone, 1.0, 0.15), dot(-l, li.dir));
        } else if (li.kind == 3u) {
            e *= max(dot(-l, li.dir), 0.0) * 2.0;
        }
        if (max(e.r, max(e.g, e.b)) < 1e-5) { continue; }
        c += brdf(s, l, e) * visible(s.pos, l, sqrt(d2) * 0.999) * weight;
    }
    return c;
}

// One cosine-weighted diffuse sample: world (occluded within `ao`), or the
// light of a glowing mesh it reaches.
fn indirect(pos: vec3<f32>, n: vec3<f32>, seed: ptr<function, u32>) -> vec3<f32> {
    let r1 = rnd(seed);
    let r2 = rnd(seed);
    let rr = sqrt(r1);
    let ph = 2.0 * PI * r2;
    let dir = normalize(onb(n, rr * cos(ph), rr * sin(ph)) + n * sqrt(max(0.0, 1.0 - r1)));
    if (p.glow == 0u) {
        return env_at(dir) * mix(0.25, 1.0, visible(pos, dir, p.ao));
    }
    let h = trace(pos, dir, INF, false);
    if (h.tri == 0xffffffffu) { return env_at(dir); }
    var c = env_at(dir) * select(0.25, 1.0, h.t > p.ao);
    // A glowing face reached by this ray: MIS with `glow_light` (power heuristic).
    let chance = lamp_chance(h.tri);
    if (chance > 0.0) {
        let t = tri_at(h.tri);
        let cr = cross(t.b - t.a, t.c - t.a);
        let pl = chance * h.t * h.t / max(0.5 * length(cr) * abs(dot(normalize(cr), dir)), 1e-8);
        let pb = max(dot(n, dir), 0.0) / PI;
        c += emit_at(t, vec3<f32>(1.0 - h.u - h.v, h.u, h.v)) * pb * pb / max(pb * pb + pl * pl, 1e-12);
    }
    return c;
}

// Probability that `glow_light` picks face `f` (0 when it does not glow).
fn lamp_chance(f: u32) -> f32 {
    let count = data[0];
    if (count == 0u) { return 0.0; }
    var lo = 0u;
    var hi = count - 1u;
    while (lo < hi) {
        let mid = (lo + hi) / 2u;
        if (data[1u + mid] < f) { lo = mid + 1u; } else { hi = mid; }
    }
    if (data[1u + lo] != f) { return 0.0; }
    let prev = select(0.0, tf(count + lo), lo > 0u);
    return tf(1u + count + lo) - prev;
}

// Next-event estimation: one emissive triangle (by power), one point on it.
fn glow_light(s: Surf, seed: ptr<function, u32>) -> vec3<f32> {
    let count = data[0];
    if (count == 0u) { return vec3<f32>(0.0); }
    // Pick by power: binary search in the cdf stored after the ids.
    let u = rnd(seed);
    var lo = 0u;
    var hi = count - 1u;
    while (lo < hi) {
        let mid = (lo + hi) / 2u;
        if (tf(1u + count + mid) < u) { lo = mid + 1u; } else { hi = mid; }
    }
    let prev = select(0.0, tf(count + lo), lo > 0u);
    let chance = max(tf(1u + count + lo) - prev, 1e-8);
    let t = tri_at(data[1u + lo]);
    var a = rnd(seed);
    var b = rnd(seed);
    if (a + b > 1.0) { a = 1.0 - a; b = 1.0 - b; }
    let q = t.a + (t.b - t.a) * a + (t.c - t.a) * b;
    let cr = cross(t.b - t.a, t.c - t.a);
    let area = 0.5 * length(cr);
    let to = q - s.pos;
    let d2 = max(dot(to, to), 1e-6);
    let l = to / sqrt(d2);
    let cos_l = abs(dot(normalize(cr), l));
    let e = emit_at(t, vec3<f32>(1.0 - a - b, a, b)) * cos_l * area / (chance * d2);
    // MIS weight against the cosine-sampled diffuse ray (power heuristic).
    let pl = chance * d2 / max(area * cos_l, 1e-8);
    let pb = max(dot(s.n, l), 0.0) / PI;
    let w = pl * pl / max(pl * pl + pb * pb, 1e-12);
    return brdf(s, l, e) * w * visible(s.pos, l, sqrt(d2) * 0.999);
}

// Radiance leaving a secondary hit (flat normal, no texture, direct + ambient).
fn bounce_light(h: Hit, org: vec3<f32>, d: vec3<f32>, seed: ptr<function, u32>) -> vec3<f32> {
    let t = tri_at(h.tri);
    let ng0 = normalize(cross(t.b - t.a, t.c - t.a));
    let ng = select(-ng0, ng0, dot(ng0, d) < 0.0);
    let pos = org + d * h.t + ng * (p.eps + h.t * 1e-5);
    let base = max(t.color.rgb, vec3<f32>(0.0));
    let s = Surf(pos, ng, -d, base * (1.0 - t.metal), mix(vec3<f32>(0.04), base, t.metal), max(t.rough, 0.3));
    return lights(s, seed) + glow_light(s, seed) + s.albedo * p.env.rgb * 0.8 + emit_at(t, vec3<f32>(1.0 - h.u - h.v, h.u, h.v));
}

