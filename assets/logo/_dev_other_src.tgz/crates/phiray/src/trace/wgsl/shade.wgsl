@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = item(gid, p.groups_x);
    if (i >= p.n) { return; }
    let su = (f32(i % p.w) + 0.5) / f32(p.w) - 0.5;
    let sv = (f32(i / p.w) + 0.5) / f32(p.h) - 0.5;
    var seed = hash(i * 9781u + p.frame * 6271u + 1u);
    let jx = (rnd(&seed) - 0.5) / f32(p.w);
    let jy = (rnd(&seed) - 0.5) / f32(p.h);
    let vx = (su + jx - p.pan.x) / p.scale;
    let vy = -((sv + jy) / p.aspect - p.pan.y) / p.scale;
    var o: vec3<f32>;
    var d: vec3<f32>;
    if (p.persp != 0u) {
        o = p.pivot + p.back * (p.dist / p.units);
        d = normalize(p.right * vx + p.up * vy - p.back * p.dist);
    } else {
        o = p.pivot + (p.right * vx + p.up * vy + p.back * 1.0e4) / p.units;
        d = -p.back;
    }
    let pix = 1.0 / (p.scale * p.units * f32(p.w));
    let sky = mix(p.sky.rgb * 1.08, p.sky.rgb * 0.85, clamp(sv + 0.5, 0.0, 1.0));
    let o0 = o;
    let d0 = d;
    var first_t = INF;
    var col = vec3<f32>(0.0);
    var thr = vec3<f32>(1.0);
    // Primary path: alpha cut-outs and glass continue the ray (≤ 8 events).
    for (var bounce = 0u; bounce < 8u; bounce++) {
        let h = trace(o, d, INF, false);
        if (h.tri == 0xffffffffu) {
            if (bounce == 0u) { emit(i, floor_grid(o, d, INF, pix, sky)); return; }
            col += thr * env_at(d);
            break;
        }
        if (bounce == 0u) { first_t = h.t; }
        let t = tri_at(h.tri);
        let w = 1.0 - h.u - h.v;
        let ng0 = normalize(cross(t.b - t.a, t.c - t.a));
        let front = dot(ng0, d) < 0.0;
        let ng = select(-ng0, ng0, front);
        var n = t.na * w + t.nb * h.u + t.nc * h.v;
        n = select(ng, normalize(n) * select(-1.0, 1.0, front), dot(n, n) > 1e-12);
        if (t.nmap != NO_TEX) { n = mapped_normal(t, n, vec3<f32>(w, h.u, h.v)); }
        if (dot(n, -d) < 0.0) { n = ng; }
        let hit = o + d * h.t;
        let off = ng * (p.eps + h.t * 1e-5);
        let pos = hit + off;
        var base = max(t.color.rgb, vec3<f32>(0.0));
        var alpha = t.color.a;
        let bary = vec3<f32>(w, h.u, h.v);
        let uv = vec2<f32>(dot(t.us, bary), dot(t.vs, bary));
        if (t.tex != NO_TEX) {
            let tc = sample_tex(t.tex, uv);
            base *= tc.rgb;
            alpha *= tc.a;
        }
        // Roughness / metallic are non-colour data (raw); emission is colour.
        var rough = t.rough;
        var metal = t.metal;
        if (t.maps.x != NO_TEX) { rough *= sample_raw(t.maps.x, uv).r; }
        if (t.maps.y != NO_TEX) { metal *= sample_raw(t.maps.y, uv).r; }
        let emit = emit_at(t, bary);
        if (rnd(&seed) >= alpha) {
            o = hit - off;
            continue;
        }
        col += thr * emit;
        let s = Surf(pos, n, -d, base * (1.0 - metal), mix(vec3<f32>(0.04), base, metal), max(rough, 0.04));
        let opaque = 1.0 - t.trans * (1.0 - metal);
        var c = (lights(s, &seed) + glow_light(s, &seed)) * opaque;

        c += s.albedo * indirect(pos, n, &seed) * opaque;

        // Reflection: one glossy sample; sky → world, geometry → its dimmed colour.
        let cosv = max(dot(n, -d), 0.0);
        var f0 = s.f0;
        if (t.trans > 0.0) { f0 = vec3<f32>(pow((t.ior - 1.0) / (t.ior + 1.0), 2.0)); }
        let fres = f0 + (1.0 - f0) * pow(1.0 - cosv, 5.0);
        let refl = cone_dir(reflect(d, n), s.rough * s.rough * 1.2, &seed);
        if (dot(refl, ng) > 0.0) {
            let rh = trace(pos, refl, INF, false);
            var rc = env_at(refl);
            if (rh.tri != 0xffffffffu) { rc = bounce_light(rh, pos, refl, &seed); }
            c += fres * rc * (1.0 - s.rough * 0.7);
        }
        col += thr * c;

        // Glass: refract and keep going, tinted by the base colour.
        let tw = t.trans * (1.0 - metal);
        if (tw <= 0.0) { break; }
        let eta = select(t.ior, 1.0 / t.ior, front);
        var nd = refract(d, n, eta);
        if (dot(nd, nd) < 1e-6) { nd = reflect(d, n); o = pos; } else { o = hit - off; }
        thr *= tw * base * (vec3<f32>(1.0) - fres);
        d = cone_dir(normalize(nd), s.rough * s.rough, &seed);
        if (max(thr.r, max(thr.g, thr.b)) < 0.01) { break; }
    }

    let shown = pow(aces(col), vec3<f32>(1.0 / 2.2));
    emit(i, floor_grid(o0, d0, first_t, pix, shown));
}
