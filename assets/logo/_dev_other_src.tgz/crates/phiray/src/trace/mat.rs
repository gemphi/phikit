//! Material table entry shared by many faces.

use super::kernel::Tri;
use bytemuck::{Pod, Zeroable};

/// Surface inputs shared by many faces (17 words on the GPU).
#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq, Pod, Zeroable)]
pub struct Mat {
    pub color: [f32; 4],
    pub rough: f32,
    pub metal: f32,
    pub trans: f32,
    pub ior: f32,
    pub emit: [f32; 3],
    pub bump: f32,
    pub tex: u32,
    pub nmap: u32,
    /// Roughness / metallic / emission textures (see [`Tri::with_maps`]).
    pub maps: [u32; 3],
}

impl Mat {
    pub fn of(t: &Tri) -> Self {
        Self {
            color: t.color, rough: t.rough, metal: t.metal, trans: t.trans, ior: t.ior,
            emit: t.emit, bump: t.bump, tex: t.tex, nmap: t.nmap, maps: t.maps,
        }
    }
    pub(super) fn key(&self) -> [u32; 17] {
        bytemuck::cast(*self)
    }
    pub(super) fn power(&self) -> f32 {
        0.2126 * self.emit[0] + 0.7152 * self.emit[1] + 0.0722 * self.emit[2]
    }
}

impl Tri {
    /// This triangle's material inputs.
    pub fn mat(&self) -> Mat {
        Mat::of(self)
    }
}

