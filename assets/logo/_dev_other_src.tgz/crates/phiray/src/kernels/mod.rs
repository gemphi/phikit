//! Built-in kernels. Each has a WGSL body and a CPU twin used for tests and fallback.

mod skin;

pub use skin::{Pair, Skin, SkinParams};
