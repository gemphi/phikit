//! Device ownership, buffers and recorded passes.

mod array;
mod pass;

pub use array::GpuArray;
pub use pass::Pass;

/// The GPU: one device + queue, shared by every renderer mode.
#[derive(Clone)]
pub struct Gpu {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    /// Which GPU this is (name, backend, driver) — reported by `examples/limits`.
    pub info: wgpu::AdapterInfo,
}

impl Gpu {
    /// Headless default adapter; `None` when no adapter is available.
    pub fn new() -> Option<Self> {
        pollster::block_on(Self::open())
    }

    async fn open() -> Option<Self> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle());
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions::default())
            .await
            .ok()?;
        // Everything the adapter offers (kernels need > 4 storage buffers).
        let limits = adapter.limits();
        let (device, queue) = adapter
            .request_device(&wgpu::DeviceDescriptor {
                label: Some("phiray"),
                required_limits: limits,
                ..Default::default()
            })
            .await
            .ok()?;
        Some(Self { device, queue, info: adapter.get_info() })
    }

    /// Largest storage buffer one binding may cover on this device.
    pub fn max_binding(&self) -> u64 {
        self.device.limits().max_storage_buffer_binding_size
    }

    /// Block until queued work is done.
    pub fn wait(&self) {
        let _ = self.device.poll(wgpu::PollType::wait_indefinitely());
    }
}
