//! `GpuArray<T>`: one storage buffer, grown by doubling, never reallocated per frame.

use super::Gpu;
use bytemuck::Pod;
use std::marker::PhantomData;

pub struct GpuArray<T: Pod> {
    buf: wgpu::Buffer,
    len: usize,
    cap: usize,
    _t: PhantomData<T>,
}

const USAGE: wgpu::BufferUsages = wgpu::BufferUsages::STORAGE
    .union(wgpu::BufferUsages::COPY_DST)
    .union(wgpu::BufferUsages::COPY_SRC)
    .union(wgpu::BufferUsages::VERTEX);

impl<T: Pod> GpuArray<T> {
    pub fn new(gpu: &Gpu, cap: usize) -> Self {
        let cap = cap.max(1);
        Self { buf: Self::alloc(gpu, cap), len: 0, cap, _t: PhantomData }
    }

    pub fn from(gpu: &Gpu, items: &[T]) -> Self {
        let mut a = Self::new(gpu, items.len());
        a.write(gpu, items);
        a
    }

    fn alloc(gpu: &Gpu, cap: usize) -> wgpu::Buffer {
        gpu.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("phiray.array"),
            size: (cap * size_of::<T>()).max(4) as u64,
            usage: USAGE,
            mapped_at_creation: false,
        })
    }

    /// Replace contents. Returns `true` when the buffer was reallocated (rebind needed).
    pub fn write(&mut self, gpu: &Gpu, items: &[T]) -> bool {
        let grown = items.len() > self.cap;
        if grown {
            self.cap = items.len().next_power_of_two();
            self.buf = Self::alloc(gpu, self.cap);
        }
        self.len = items.len();
        gpu.queue.write_buffer(&self.buf, 0, bytemuck::cast_slice(items));
        grown
    }

    /// `items` over `chunks` arrays of at most `limit` bytes each; `None` if that
    /// is not enough. Returns the arrays and the items per chunk (index `i` is in
    /// chunk `i / per`); unused chunks hold one placeholder item.
    pub fn split(gpu: &Gpu, items: &[T], limit: u64, chunks: usize) -> Option<(Vec<Self>, u32)> {
        let cap = (limit / size_of::<T>() as u64).max(1) as usize;
        if items.len() > chunks * cap {
            return None;
        }
        let cut = items.len().clamp(1, cap);
        let parts = (0..chunks)
            .map(|k| match items.get(k * cut..((k + 1) * cut).min(items.len())) {
                Some(part) if !part.is_empty() => Self::from(gpu, part),
                _ => Self::new(gpu, 1),
            })
            .collect();
        Some((parts, cut as u32))
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn buffer(&self) -> &wgpu::Buffer {
        &self.buf
    }

    /// Copy back to the CPU (tests, readback). Blocks.
    pub fn read(&self, gpu: &Gpu) -> Vec<T> {
        self.read_first(gpu, self.len)
    }

    /// Copy back the first `count` items only.
    pub fn read_first(&self, gpu: &Gpu, count: usize) -> Vec<T> {
        let bytes = (count.min(self.len) * size_of::<T>()) as u64;
        if bytes == 0 {
            return Vec::new();
        }
        let staging = gpu.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("phiray.read"),
            size: bytes,
            usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let mut enc = gpu.device.create_command_encoder(&Default::default());
        enc.copy_buffer_to_buffer(&self.buf, 0, &staging, 0, bytes);
        gpu.queue.submit([enc.finish()]);
        let slice = staging.slice(..);
        slice.map_async(wgpu::MapMode::Read, |_| {});
        gpu.wait();
        let out = bytemuck::cast_slice(&slice.get_mapped_range()).to_vec();
        staging.unmap();
        out
    }
}
