//! Viewport shading modes served by phiray.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    /// Edges only, depth-tested (`V3D_SHADING_WIREFRAME`).
    Wire,
    /// Flat/studio shading (phiber canvas today).
    Solid,
    /// wgpu raster with materials and textures.
    Preview,
    /// wgpu compute path tracer.
    Rendered,
}

impl Mode {
    /// Blender's viewport order: wireframe, solid, material, rendered.
    pub const ALL: &'static [Mode] = &[Mode::Wire, Mode::Solid, Mode::Preview, Mode::Rendered];

    /// Modes that finish in a single dispatch: no sampling, no refinement.
    pub fn deterministic(self) -> bool {
        matches!(self, Mode::Wire | Mode::Solid)
    }

    /// Blender's `View3DShading.type` name.
    pub fn blender(self) -> &'static str {
        match self {
            Mode::Wire => "WIREFRAME",
            Mode::Solid => "SOLID",
            Mode::Preview => "MATERIAL",
            Mode::Rendered => "RENDERED",
        }
    }

    pub fn from_blender(name: &str) -> Option<Self> {
        Self::ALL.iter().copied().find(|m| m.blender() == name)
    }
}
