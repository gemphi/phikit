//! The two deterministic modes: Workbench (Solid) and Wireframe.
//!
//! Blender's Solid viewport is a Workbench pass, not a path trace — it is
//! finished the instant it is drawn. These tests hold that: one sample, a lit
//! surface that reads brighter than the sky behind it, and the same image
//! whether it is asked for once or ten times. Wireframe is the same shape of
//! pass, drawing edges instead of surfaces.

use phiray::{Atlas, Camera, Mode, Ray, Tracer, Tri};

fn quad(p: [[f32; 3]; 4], n: [f32; 3], c: [f32; 4]) -> [Tri; 2] {
    [Tri::new([p[0], p[1], p[2]], [n; 3], c), Tri::new([p[0], p[2], p[3]], [n; 3], c)]
}

/// One grey wall square on, filling the middle of the frame.
fn wall() -> Vec<Tri> {
    quad(
        [[-3., 0., -3.], [3., 0., -3.], [3., 0., 3.], [-3., 0., 3.]],
        [0., -1., 0.],
        [0.6, 0.6, 0.6, 1.0],
    )
    .to_vec()
}

/// Looking down −Y at the wall, orthographic, no floor grid in shot.
fn camera() -> Camera {
    Camera {
        right: [1.0, 0.0, 0.0],
        up: [0.0, 0.0, 1.0],
        back: [0.0, -1.0, 0.0],
        pivot: [0.0, 0.0, 0.0],
        units: 1.0,
        scale: 0.1,
        aspect: 1.0,
        persp: 0,
        dist: 10.0,
        sky: [0.2, 0.22, 0.25, 1.0],
        env: [0.2, 0.22, 0.25, 1.0],
        grid: 0.0,
        ..Default::default()
    }
}

const W: u32 = 64;
const H: u32 = 64;

fn pixel(px: &[u8], x: u32, y: u32) -> [u8; 3] {
    let i = ((y * W + x) * 4) as usize;
    [px[i], px[i + 1], px[i + 2]]
}

fn luma(c: [u8; 3]) -> f32 {
    0.2126 * c[0] as f32 + 0.7152 * c[1] as f32 + 0.0722 * c[2] as f32
}

#[test]
fn solid_finishes_in_one_dispatch_and_lights_the_surface() {
    let Some(gpu) = Ray::gpu() else {
        eprintln!("no GPU adapter; skipped");
        return;
    };
    let mut tr = Tracer::new(&gpu, &wall(), &Atlas::default()).expect("scene");
    tr.set_mode(Mode::Solid);
    assert_eq!(tr.samples(), 1, "Workbench is deterministic — one sample is the frame");

    let (px, done) = tr.render(&gpu, camera(), W, H);
    assert!(done, "Solid must report finished on its first frame");
    assert_eq!(px.len(), (W * H * 4) as usize);

    // Centre is the wall, a corner is sky.
    let centre = pixel(&px, W / 2, H / 2);
    let corner = pixel(&px, 1, 1);
    assert!(
        luma(centre) > luma(corner) + 20.0,
        "a surface facing the studio rig must read brighter than the sky: \
         centre {centre:?} vs sky {corner:?}"
    );
    // The rig is neutral-to-cool on a grey surface, but it is not black and
    // not clipped — those are the two ways the port fails silently.
    assert!(luma(centre) > 30.0, "surface came out black: {centre:?}");
    assert!(luma(centre) < 250.0, "surface clipped to white: {centre:?}");
}

#[test]
fn asking_again_returns_the_same_image() {
    let Some(gpu) = Ray::gpu() else {
        eprintln!("no GPU adapter; skipped");
        return;
    };
    let mut tr = Tracer::new(&gpu, &wall(), &Atlas::default()).expect("scene");
    tr.set_mode(Mode::Solid);
    let (first, _) = tr.render(&gpu, camera(), W, H);
    for _ in 0..3 {
        let (again, done) = tr.render(&gpu, camera(), W, H);
        assert!(done);
        assert_eq!(first, again, "Solid must not drift between frames");
    }
}

#[test]
fn switching_modes_rebuilds_the_pass() {
    let Some(gpu) = Ray::gpu() else {
        eprintln!("no GPU adapter; skipped");
        return;
    };
    let mut tr = Tracer::new(&gpu, &wall(), &Atlas::default()).expect("scene");
    tr.set_mode(Mode::Solid);
    let (solid, _) = tr.render(&gpu, camera(), W, H);
    tr.set_mode(Mode::Rendered);
    assert_eq!(tr.samples(), Tracer::SAMPLES);
    let (traced, done) = tr.render(&gpu, camera(), W, H);
    assert!(!done, "the tracer refines, so its first frame is not the last");
    assert_ne!(solid, traced, "the two modes must not produce the same image");
    tr.set_mode(Mode::Solid);
    let (back, done) = tr.render(&gpu, camera(), W, H);
    assert!(done);
    assert_eq!(solid, back, "returning to Solid must return the same frame");
}

/// Wire tests light the wire white so it is unambiguous against the sky.
/// In `Mode::Wire` the camera's `env` carries the wire colour.
fn wire_camera() -> Camera {
    Camera { env: [1.0, 1.0, 1.0, 1.0], ..camera() }
}

/// The sky at this row. The sky is a vertical gradient, so a pixel can only
/// be compared with another on the SAME row — x = 1 is outside the wall at
/// every row, so it is always sky.
fn sky_at(px: &[u8], y: u32) -> [u8; 3] {
    pixel(px, 1, y)
}

fn is_wire(px: &[u8], x: u32, y: u32) -> bool {
    luma(pixel(px, x, y)) > luma(sky_at(px, y)) + 40.0
}

#[test]
fn wire_draws_edges_and_leaves_the_interior_alone() {
    let Some(gpu) = Ray::gpu() else {
        eprintln!("no GPU adapter; skipped");
        return;
    };
    let mut tr = Tracer::new(&gpu, &wall(), &Atlas::default()).expect("scene");
    tr.set_mode(Mode::Wire);
    assert_eq!(tr.samples(), 1, "the wire pass is deterministic too");
    let (px, done) = tr.render(&gpu, wire_camera(), W, H);
    assert!(done);

    // The wall's interior is background: a wireframe shows what is behind the
    // surface, not the surface. Sampled on the wall but away from its edges
    // and its diagonal.
    assert!(
        !is_wire(&px, W / 2 - 8, H / 2 + 2),
        "the inside of a face must read as background in wireframe"
    );

    // The quad's silhouette and the diagonal where its two triangles meet do
    // draw — but as lines, not as a fill.
    let wired = (0..H)
        .flat_map(|y| (0..W).map(move |x| (x, y)))
        .filter(|&(x, y)| is_wire(&px, x, y))
        .count();
    assert!(wired > 50, "almost nothing was drawn: {wired} px");
    assert!(
        wired < (W * H) as usize / 8,
        "the wire pass filled the frame instead of drawing lines: {wired} px"
    );
}

#[test]
fn a_wire_behind_a_face_does_not_draw() {
    let Some(gpu) = Ray::gpu() else {
        eprintln!("no GPU adapter; skipped");
        return;
    };
    // A band nearer the camera than the wall. The wall's diagonal runs at 45°
    // through the origin; the band's runs at a different slope, so at world
    // (1.5, 1.5) the wall's diagonal is hidden behind the band and the band's
    // own diagonal is 0.75 units away — several pixels clear.
    let mut scene = wall();
    scene.extend(quad(
        [[-3., -2., -2.], [3., -2., -2.], [3., -2., 2.], [-3., -2., 2.]],
        [0., -1., 0.],
        [0.6, 0.6, 0.6, 1.0],
    ));
    let mut tr = Tracer::new(&gpu, &scene, &Atlas::default()).expect("scene");
    tr.set_mode(Mode::Wire);
    let (px, _) = tr.render(&gpu, wire_camera(), W, H);

    // World (1.5, 1.5): the frame spans ±5 units over 64 px, so 1.5 units is
    // 9.6 px from the centre — right on the hidden diagonal.
    let (x, y) = (W / 2 + 10, H / 2 - 10);
    assert!(
        !is_wire(&px, x, y),
        "an edge behind a face must be hidden, but ({x}, {y}) drew a wire"
    );

    // Without the band in front, that same pixel IS on the wall's diagonal —
    // otherwise the test above would pass for the wrong reason.
    let mut bare = Tracer::new(&gpu, &wall(), &Atlas::default()).expect("scene");
    bare.set_mode(Mode::Wire);
    let (open, _) = bare.render(&gpu, wire_camera(), W, H);
    assert!(
        is_wire(&open, x, y),
        "the control pixel is not on an edge, so the test proves nothing"
    );
}
