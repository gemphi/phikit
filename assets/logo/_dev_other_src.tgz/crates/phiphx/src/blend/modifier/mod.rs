//! The viewport modifier stack (Blender `mesh_calc_modifiers`), limited to
//! modifiers that change how an existing mesh looks.
//!
//! Declarative: [`KINDS`] maps a DNA `ModifierData.type` to a reader that
//! turns the saved settings into a [`BModifier`]. The stack runs in file
//! order on an [`BlendEvalMesh`]; unknown or disabled modifiers are skipped
//! (and listed in the read report by the caller).

pub(crate) mod armature;
mod array;
mod displace;
mod geom;
mod mirror;
mod solidify;
pub mod skin;
mod subsurf;
mod topology;
mod triangulate;
mod weld;
mod lattice;
#[cfg(test)]
mod tests;

use crate::blend::file::types::*;
use glam::Mat4;
use std::collections::HashMap;

/// `eModifierMode_Realtime` — shown in the viewport.
const MODE_REALTIME: u32 = 1;

/// The mesh a modifier stack works on (object space).
#[derive(Debug, Clone, Default, PartialEq)]
pub struct BlendEvalMesh {
    pub vertices: Vec<[f32; 3]>,
    pub faces: crate::blend::BFaces,
    /// Per-corner UVs in face-corner order (empty when the mesh has none).
    pub loop_uvs: Vec<[f32; 2]>,
    pub face_materials: Vec<u16>,
    pub face_smooth: Vec<bool>,
    /// Per-vertex `(group, weight)`; carried through topology changes so a
    /// later Armature still deforms (Blender interpolates `MDeformVert`).
    pub dverts: Vec<Vec<(u32, f32)>>,
}

/// What a modifier may look up while evaluating.
pub(crate) struct EvalCtx<'a> {
    /// The evaluated object's world matrix.
    pub world: Mat4,
    /// World matrices of all scene objects by saved address.
    pub worlds: &'a HashMap<u64, Mat4>,
}

pub(crate) trait BModifier: Send + Sync {
    fn apply(&self, mesh: &mut BlendEvalMesh, ctx: &EvalCtx);
    /// Whether the stack must load vertex-group weights for this modifier.
    fn wants_weights(&self) -> bool {
        false
    }
    /// As a batched skin job instead of `apply` (only asked of the last modifier).
    /// Test hook: is this the lattice deform?
    #[cfg(test)]
    fn is_lattice(&self) -> bool {
        false
    }
    fn skin_job(&self, _mesh: &BlendEvalMesh, _ctx: &EvalCtx) -> Option<skin::SkinJob> {
        None
    }
}

type Reader = fn(&BlendFile, &BlendBlock, &BlendBlock, &DnaType) -> Option<Box<dyn BModifier>>;

/// One supported modifier type.
pub(crate) struct BModifierKind {
    pub dna_type: u32,
    pub name: &'static str,
    pub read: Reader,
}

/// Supported modifiers, by `eModifierType`.
pub(crate) const KINDS: &[BModifierKind] = &[
    BModifierKind { dna_type: 8, name: "ARMATURE", read: armature::read },
    BModifierKind { dna_type: 1, name: "SUBSURF", read: subsurf::read },
    BModifierKind { dna_type: 5, name: "MIRROR", read: mirror::read },
    BModifierKind { dna_type: 12, name: "ARRAY", read: array::read },
    BModifierKind { dna_type: 44, name: "TRIANGULATE", read: triangulate::read },
    BModifierKind { dna_type: 33, name: "SOLIDIFY", read: solidify::read },
    BModifierKind { dna_type: 14, name: "DISPLACE", read: displace::read },
    BModifierKind { dna_type: 55, name: "WELD", read: weld::read },
    BModifierKind { dna_type: 2, name: "LATTICE", read: lattice::read },
];

/// Names of the modifiers the viewport evaluates (Blender's RNA type ids).
pub fn supported_modifiers() -> impl Iterator<Item = &'static str> {
    KINDS.iter().map(|k| k.name)
}

impl BlendFile {
    /// Enabled viewport modifiers of `ob`, in stack order (supported ones).
    fn modifier_stack(&self, ob: &BlendBlock, dna: &DnaType) -> Vec<Box<dyn BModifier>> {
        let first = self.ptr(ob, self.off("Object", "modifiers", dna));
        let next = self.off("ModifierData", "*next", dna);
        let mds = self.scoped(ob, || self.list(first, next));
        mds.into_iter()
            .filter(|md| self.int_field(md, "ModifierData", "mode", dna) & MODE_REALTIME != 0)
            .filter_map(|md| {
                let ty = self.int_field(md, "ModifierData", "type", dna);
                let kind = KINDS.iter().find(|k| k.dna_type == ty)?;
                self.scoped(ob, || (kind.read)(self, md, ob, dna))
            })
            .collect()
    }

    /// Linked-list walk from a `ListBase.first` address.
    pub(crate) fn list(&self, first: u64, next: Option<usize>) -> Vec<&BlendBlock> {
        let mut out = Vec::new();
        let mut addr = first;
        while let Some(b) = self.block_at(addr) {
            if out.len() > 100_000 { break; }
            out.push(b);
            addr = self.ptr(b, next);
        }
        out
    }

    /// Evaluated meshes for every mesh object whose stack changes it, keyed
    /// by index into `objects`. Objects without modifiers are left out.
    pub(crate) fn evaluate_modifiers(&self, objects: &[BlendSceneObject], dna: &DnaType) -> HashMap<usize, BlendEvalMesh> {
        let worlds: HashMap<u64, Mat4> = objects
            .iter()
            .map(|o| (o.block_address, Mat4::from_cols_array_2d(&o.matrix_world)))
            .collect();
        // Reading stays sequential (pointer scoping); evaluation is parallel.
        let mut jobs = Vec::new();
        for (i, o) in objects.iter().enumerate() {
            if o.object_type != "MESH" || o.vertices.is_empty() {
                continue;
            }
            let Some(ob) = self.block_at_code(o.block_address, "OB") else { continue };
            let stack = self.modifier_stack(ob, dna);
            if stack.is_empty() {
                continue;
            }
            let dverts = match (stack.iter().any(|m| m.wants_weights()), self.mesh_block_of(ob, dna)) {
                (true, Some(me)) => self.deform_verts(me, dna, o.vertices.len()),
                _ => Vec::new(),
            };
            jobs.push((i, o, stack, dverts));
        }
        use rayon::prelude::*;
        let batch = skin::skinner();
        let evaluated: Vec<(usize, BlendEvalMesh, Option<skin::SkinJob>)> = jobs
            .into_par_iter()
            .map(|(i, o, stack, dverts)| {
                let mut mesh = BlendEvalMesh {
                    vertices: o.vertices.clone(),
                    faces: o.faces.clone(),
                    loop_uvs: o.loop_uvs.clone(),
                    face_materials: o.face_materials.clone(),
                    face_smooth: o.face_smooth.clone(),
                    dverts,
                };
                let ctx = EvalCtx { world: Mat4::from_cols_array_2d(&o.matrix_world), worlds: &worlds };
                let (last, head) = stack.split_last().expect("non-empty stack");
                for m in head {
                    m.apply(&mut mesh, &ctx);
                }
                let job = batch.as_ref().and_then(|_| last.skin_job(&mesh, &ctx));
                if job.is_none() {
                    last.apply(&mut mesh, &ctx);
                }
                (i, mesh, job)
            })
            .collect();
        Self::finish_skins(evaluated, batch.as_deref())
    }

    /// Run all pending skin jobs in one batch and write the results back.
    fn finish_skins(
        evaluated: Vec<(usize, BlendEvalMesh, Option<skin::SkinJob>)>,
        batch: Option<&dyn skin::Skinner>,
    ) -> HashMap<usize, BlendEvalMesh> {
        let (mut meshes, mut jobs): (Vec<_>, Vec<_>) = (Vec::new(), Vec::new());
        for (i, mesh, job) in evaluated {
            if let Some(j) = job {
                jobs.push(j);
            }
            meshes.push((i, mesh, jobs.len()));
        }
        if !jobs.is_empty() && !batch.is_some_and(|s| s.run(&mut jobs)) {
            skin::Skinner::run(&skin::CpuSkin, &mut jobs);
        }
        let mut prev = 0;
        meshes
            .into_iter()
            .map(|(i, mut mesh, upto)| {
                if upto > prev {
                    mesh.vertices = std::mem::take(&mut jobs[upto - 1].out);
                    prev = upto;
                }
                (i, mesh)
            })
            .collect()
    }
}
