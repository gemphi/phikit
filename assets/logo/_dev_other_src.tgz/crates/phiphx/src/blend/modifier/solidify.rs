//! Solidify modifier, simple mode (`SolidifyModifierData`, Blender
//! `MOD_solidify_extrude.cc`): give a surface thickness by adding an inner
//! shell offset along the vertex normals and a rim joining the two along the
//! open boundary.
//!
//! `offset` places the shell relative to the original surface: −1 puts it
//! entirely inside, +1 entirely outside, 0 centres it. Not yet: the complex
//! (non-manifold) mode, per-vertex-group thickness, rim material offsets.

use super::geom::{boundary, vertex_normals};
use super::{BModifier, BlendEvalMesh, EvalCtx};
use crate::blend::file::types::*;
use glam::Vec3;

/// `MOD_SOLIDIFY_RIM` — close the open boundary between the two shells.
const RIM: u32 = 1 << 1;
/// `MOD_SOLIDIFY_FLIP` — reverse the inner shell's winding.
const FLIP: u32 = 1 << 2;

pub(crate) struct BSolidify {
    pub thickness: f32,
    pub offset: f32,
    pub flag: u32,
}

pub(super) fn read(
    f: &BlendFile,
    md: &BlendBlock,
    _ob: &BlendBlock,
    dna: &DnaType,
) -> Option<Box<dyn BModifier>> {
    Some(Box::new(BSolidify {
        thickness: f.float_field(md, "SolidifyModifierData", "offset", dna, 0.01),
        offset: f.float_field(md, "SolidifyModifierData", "offset_fac", dna, -1.0),
        flag: f.int_field(md, "SolidifyModifierData", "flag", dna),
    }))
}

impl BModifier for BSolidify {
    fn apply(&self, mesh: &mut BlendEvalMesh, _ctx: &EvalCtx) {
        if mesh.vertices.is_empty() || mesh.faces.is_empty() {
            return;
        }
        let normals = vertex_normals(mesh);
        let rim_edges = boundary(mesh);
        let base_verts = mesh.vertices.len() as u32;
        let base_faces = mesh.faces.len();

        // `MOD_solidify_extrude.cc`: `ofs_orig = -((1 - offset_fac) / 2) *
        // thickness`, `ofs_new = ofs_orig + thickness`. Which shell takes which
        // is decided by `INIT_VERT_ARRAY_OFFSETS`, not by name: without FLIP
        // the original vertices take the larger offset and the copies the
        // smaller, whatever the sign of the thickness. A negative thickness
        // (a garment offset outward from its base surface) used to leave the
        // originals at the base and push the reversed copies out, so the
        // correctly-wound surface sat exactly on the body underneath it.
        let ofs_orig = -((1.0 - self.offset) * 0.5) * self.thickness;
        let ofs_new = ofs_orig + self.thickness;
        let flip = self.flag & FLIP != 0;
        let (outer, inner) = if (ofs_new >= ofs_orig) != flip {
            (ofs_new, ofs_orig)
        } else {
            (ofs_orig, ofs_new)
        };
        for i in 0..base_verts as usize {
            let v = Vec3::from(mesh.vertices[i]);
            mesh.vertices[i] = (v + normals[i] * outer).into();
        }
        for i in 0..base_verts as usize {
            let v = Vec3::from(mesh.vertices[i]) - normals[i] * outer;
            mesh.vertices.push((v + normals[i] * inner).into());
            let weights = mesh.dverts.get(i).cloned().unwrap_or_default();
            mesh.dverts.push(weights);
        }

        let flip = !flip;
        for face in 0..base_faces {
            let mut corners: Vec<u32> = mesh.faces.get(face).iter().map(|c| c + base_verts).collect();
            if flip {
                corners.reverse();
            }
            mesh.faces.push(&corners);
            let material = mesh.face_materials.get(face).copied().unwrap_or(0);
            mesh.face_materials.push(material);
            let smooth = mesh.face_smooth.get(face).copied().unwrap_or(true);
            mesh.face_smooth.push(smooth);
        }
        if self.flag & RIM != 0 {
            for (a, b) in rim_edges {
                mesh.faces.push(&[a, b, b + base_verts, a + base_verts]);
                mesh.face_materials.push(0);
                mesh.face_smooth.push(false);
            }
        }
        // The shells and rim have no UVs of their own; clearing keeps the
        // corner count consistent with the face list.
        if !mesh.loop_uvs.is_empty() && mesh.loop_uvs.len() != mesh.faces.corners() {
            mesh.loop_uvs.clear();
        }
    }
}
