//! Array, Triangulate and Solidify: modifiers that rebuild the face list.

use super::super::array::BArray;
use super::super::solidify::BSolidify;
use super::super::triangulate::BTriangulate;
use super::{eval, quad};

#[test]
fn array_repeats_the_mesh_and_everything_that_travels_with_it() {
    let mut m = quad();
    eval(
        &mut m,
        &BArray {
            count: 3,
            offset_type: 1, // constant
            constant: glam::Vec3::new(2.0, 0.0, 0.0),
            relative: glam::Vec3::ZERO,
            offset_ob: 0,
        },
    );
    assert_eq!((m.vertices.len(), m.faces.len()), (12, 3));
    // Each copy is displaced by one whole step, not a cumulative drift.
    assert_eq!(m.vertices[4][0], 2.0);
    assert_eq!(m.vertices[8][0], 4.0);
    // The copies' faces index their own vertices.
    assert_eq!(m.faces.get(2), &[8, 9, 10, 11]);
    // UVs, materials, smooth flags and weights come along.
    assert_eq!(m.loop_uvs.len(), 12);
    assert_eq!(m.face_materials, vec![2, 2, 2]);
    assert_eq!(m.face_smooth, vec![true; 3]);
    assert_eq!(m.dverts.len(), 12);
}

#[test]
fn array_relative_offset_measures_the_mesh_itself() {
    let mut m = quad();
    eval(
        &mut m,
        &BArray {
            count: 2,
            offset_type: 2, // relative
            constant: glam::Vec3::ZERO,
            relative: glam::Vec3::new(1.0, 0.0, 0.0),
            offset_ob: 0,
        },
    );
    // The quad is one unit wide, so one relative step is one unit.
    assert_eq!(m.vertices[4][0], 1.0);
}

#[test]
fn a_single_copy_array_changes_nothing() {
    let mut m = quad();
    let before = m.clone();
    eval(
        &mut m,
        &BArray {
            count: 1,
            offset_type: 1,
            constant: glam::Vec3::new(5.0, 0.0, 0.0),
            relative: glam::Vec3::ZERO,
            offset_ob: 0,
        },
    );
    assert_eq!(m, before);
}

// ── Triangulate ───────────────────────────────────────────────────────────

#[test]
fn triangulate_splits_quads_and_keeps_what_rides_on_each_face() {
    let mut m = quad();
    eval(&mut m, &BTriangulate { min_vertices: 4 });
    assert_eq!(m.faces.len(), 2);
    assert_eq!(m.faces.get(0), &[0, 1, 2]);
    assert_eq!(m.faces.get(1), &[0, 2, 3]);
    // Both halves inherit the face's material and shading.
    assert_eq!(m.face_materials, vec![2, 2]);
    assert_eq!(m.face_smooth, vec![true, true]);
    // One UV per corner of the new faces.
    assert_eq!(m.loop_uvs.len(), 6);
}

#[test]
fn triangulate_leaves_faces_below_its_threshold_alone() {
    let mut m = quad();
    // Blender's default keeps quads: only faces of 5+ corners are split.
    eval(&mut m, &BTriangulate { min_vertices: 5 });
    assert_eq!(m.faces.len(), 1);
    assert_eq!(m.faces.get(0), &[0, 1, 2, 3]);
}

// ── Solidify ──────────────────────────────────────────────────────────────

#[test]
fn solidify_adds_a_second_shell_and_a_rim() {
    let mut m = quad();
    eval(
        &mut m,
        &BSolidify {
            thickness: 0.2,
            offset: -1.0,
            flag: 1 << 1, // rim
        },
    );
    // The original four vertices gain a shell of four more.
    assert_eq!(m.vertices.len(), 8);
    // Two shells, plus one rim face per boundary edge of the quad.
    assert_eq!(m.faces.len(), 2 + 4);
    // With offset -1 the outer shell stays put and the inner moves inward.
    assert!((m.vertices[0][2] - 0.0).abs() < 1e-6, "{:?}", m.vertices[0]);
    assert!((m.vertices[4][2] + 0.2).abs() < 1e-6, "{:?}", m.vertices[4]);
}

#[test]
fn a_negative_thickness_pushes_the_original_surface_outward_as_blender_does() {
    // The Female-01 garments: thickness -0.004, offset -1. Blender gives the
    // original vertices the larger of the two offsets (`INIT_VERT_ARRAY_OFFSETS`
    // without FLIP), so the correctly-wound surface moves 4 mm off the base
    // and the reversed copy stays on it. The other way round put the visible
    // surface exactly on the body the garment was made from.
    let mut m = quad();
    eval(&mut m, &BSolidify { thickness: -0.004, offset: -1.0, flag: 0 });
    assert!((m.vertices[0][2] - 0.004).abs() < 1e-6, "original moved out: {:?}", m.vertices[0]);
    assert!((m.vertices[4][2] - 0.0).abs() < 1e-6, "copy stays on the base: {:?}", m.vertices[4]);
}

#[test]
fn solidify_reverses_the_inner_shell_so_it_faces_outward() {
    let mut m = quad();
    eval(&mut m, &BSolidify { thickness: 0.1, offset: -1.0, flag: 0 });
    let inner = m.faces.get(1).to_vec();
    // The inner shell's corners run the other way round from the outer's.
    assert_eq!(inner, vec![7, 6, 5, 4]);
}

