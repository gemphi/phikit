//! Subdivision Surface (`SubsurfModifierData`), evaluated like Blender's
//! OpenSubdiv path for the viewport `levels`: Catmull-Clark (or Simple)
//! refinement, boundaries smoothed (`SUBSURF_BOUNDARY_SMOOTH_ALL`) or with
//! corners kept, then — unless "Use Limit Surface" is off
//! (`eSubsurfModifierFlag_UseRecursiveSubdivision`) — every vertex moved to
//! its limit position. Face materials / smooth flags are inherited; UVs are
//! interpolated linearly. Not yet: creases, UV smoothing.

use crate::blend::file::types::*;
use super::{BModifier, BlendEvalMesh, EvalCtx};
use super::topology::Topology;
use rayon::prelude::*;

const RECURSIVE: u32 = 1 << 6;
/// Guard against runaway levels on huge meshes (faces after refinement).
const MAX_FACES: usize = 8_000_000;

pub(crate) struct BSubsurf {
    pub levels: u32,
    pub simple: bool,
    pub limit: bool,
    pub keep_corners: bool,
}

pub(super) fn read(f: &BlendFile, md: &BlendBlock, _ob: &BlendBlock, dna: &DnaType) -> Option<Box<dyn BModifier>> {
    let levels = f.int_field(md, "SubsurfModifierData", "levels", dna);
    (levels > 0).then(|| {
        Box::new(BSubsurf {
            levels: levels.min(6),
            simple: f.int_field(md, "SubsurfModifierData", "subdivType", dna) == 1,
            limit: f.int_field(md, "SubsurfModifierData", "flags", dna) & RECURSIVE == 0,
            keep_corners: f.int_field(md, "SubsurfModifierData", "boundary_smooth", dna) == 0,
        }) as Box<dyn BModifier>
    })
}

impl BModifier for BSubsurf {
    fn apply(&self, mesh: &mut BlendEvalMesh, _ctx: &EvalCtx) {
        for _ in 0..self.levels {
            if mesh.faces.len() * 4 > MAX_FACES {
                break;
            }
            refine(mesh, self);
        }
        if self.limit && !self.simple {
            let t = Topology::of(mesh);
            let m = &*mesh;
            let limited = (0..m.vertices.len()).into_par_iter().map(|v| limit(&t, m, v, self.keep_corners)).collect();
            mesh.vertices = limited;
        }
    }
}

type V3 = [f32; 3];
fn add(a: V3, b: V3) -> V3 { [a[0] + b[0], a[1] + b[1], a[2] + b[2]] }
fn scale(a: V3, s: f32) -> V3 { [a[0] * s, a[1] * s, a[2] * s] }

/// Boundary neighbours of `v` (edges with ≠ 2 faces).
fn boundary_nbrs(t: &Topology, v: usize) -> Vec<u32> {
    t.vert_edges(v).iter().filter(|&&e| t.is_boundary(e)).map(|&e| t.other(e, v)).collect()
}

/// Boundary / corner rule shared by refinement (`w = 6/8`) and the limit
/// (`w = 4/6`); `None` for interior vertices.
fn boundary_rule(t: &Topology, m: &BlendEvalMesh, v: usize, keep_corners: bool, w: f32) -> Option<V3> {
    let p = m.vertices[v];
    let b = boundary_nbrs(t, v);
    if b.is_empty() {
        return None;
    }
    if b.len() != 2 || (keep_corners && t.vert_corners(v).len() == 1) {
        return Some(p);
    }
    let e = add(m.vertices[b[0] as usize], m.vertices[b[1] as usize]);
    Some(add(scale(p, w), scale(e, (1.0 - w) * 0.5)))
}

/// Catmull-Clark limit position (all faces are quads after one level).
fn limit(t: &Topology, m: &BlendEvalMesh, v: usize, keep_corners: bool) -> V3 {
    if t.vert_corners(v).is_empty() {
        return m.vertices[v];
    }
    if let Some(p) = boundary_rule(t, m, v, keep_corners, 4.0 / 6.0) {
        return p;
    }
    let n = t.vert_edges(v).len() as f32;
    let e = t.vert_edges(v).iter().fold([0.0; 3], |s, &x| add(s, m.vertices[t.other(x, v) as usize]));
    let f = t.vert_corners(v).iter().fold([0.0; 3], |s, &(fi, c)| {
        let face = &m.faces[fi as usize];
        add(s, m.vertices[face[(c as usize + face.len() / 2) % face.len()] as usize])
    });
    scale(add(add(scale(m.vertices[v], n * n), scale(e, 4.0)), f), 1.0 / (n * (n + 5.0)))
}

fn vertex_point(m: &BlendEvalMesh, t: &Topology, face_pts: &[V3], v: usize, s: &BSubsurf) -> V3 {
    let p = m.vertices[v];
    if s.simple || t.vert_corners(v).is_empty() {
        return p;
    }
    if let Some(b) = boundary_rule(t, m, v, s.keep_corners, 6.0 / 8.0) {
        return b;
    }
    let n = t.vert_edges(v).len() as f32;
    let q = t.vert_corners(v).iter().fold([0.0; 3], |a, &(f, _)| add(a, face_pts[f as usize]));
    let r = t.vert_edges(v).iter().fold([0.0; 3], |a, &e| add(a, add(p, m.vertices[t.other(e, v) as usize])));
    let (q, r) = (scale(q, 1.0 / t.vert_corners(v).len() as f32), scale(r, 0.5 / n));
    scale(add(add(q, scale(r, 2.0)), scale(p, n - 3.0)), 1.0 / n)
}

/// Equal-weight blend of the listed vertices' group weights.
fn mix(dverts: &[Vec<(u32, f32)>], of: &[u32]) -> Vec<(u32, f32)> {
    let mut acc: Vec<(u32, f32)> = Vec::new();
    let share = 1.0 / of.len().max(1) as f32;
    for &v in of {
        for &(g, w) in &dverts[v as usize] {
            match acc.iter_mut().find(|e| e.0 == g) {
                Some(e) => e.1 += w * share,
                None => acc.push((g, w * share)),
            }
        }
    }
    acc
}

fn refine(m: &mut BlendEvalMesh, s: &BSubsurf) {
    let t = Topology::of(m);
    let nv = m.vertices.len();
    let face_pts: Vec<V3> = (0..m.faces.len())
        .into_par_iter()
        .map(|fi| {
            let f = m.faces.get(fi);
            scale(f.iter().fold([0.0; 3], |a, &i| add(a, m.vertices[i as usize])), 1.0 / f.len() as f32)
        })
        .collect();
    let edge_pts: Vec<V3> = (0..t.edges.len())
        .into_par_iter()
        .map(|e| {
            let (a, b) = t.edges[e];
            let mid = scale(add(m.vertices[a as usize], m.vertices[b as usize]), 0.5);
            if s.simple || t.edge_nfaces[e] != 2 {
                return mid;
            }
            let [f0, f1] = t.edge_faces[e];
            scale(add(mid, scale(add(face_pts[f0 as usize], face_pts[f1 as usize]), 0.5)), 0.5)
        })
        .collect();
    let mut verts: Vec<V3> = (0..nv).into_par_iter().map(|v| vertex_point(m, &t, &face_pts, v, s)).collect();
    // Vertex data follows the same stencil shape: corners keep theirs, face
    // points average the face, edge points the two ends.
    let mut dverts = Vec::new();
    if m.dverts.len() == nv {
        dverts = std::mem::take(&mut m.dverts);
        let src = dverts.clone();
        dverts.extend((0..m.faces.len()).map(|fi| mix(&src, m.faces.get(fi))));
        dverts.extend(t.edges.iter().map(|&(a, b)| mix(&src, &[a, b])));
    }
    let (fbase, ebase) = (nv as u32, (nv + face_pts.len()) as u32);
    verts.extend(face_pts);
    verts.extend(edge_pts);
    let total: usize = m.faces.corners();
    let uvs = m.loop_uvs.len() >= total;
    let mut out = BlendEvalMesh { vertices: verts, dverts, ..Default::default() };
    out.faces.reserve(total, 4 * total);
    for (fi, f) in m.faces.iter().enumerate() {
        let (k, c0) = (f.len(), t.face_start[fi]);
        let uv = |i: usize| m.loop_uvs.get(c0 + i % k).copied().unwrap_or([0.0; 2]);
        let center = (0..k).fold([0.0, 0.0], |a, i| [a[0] + uv(i)[0] / k as f32, a[1] + uv(i)[1] / k as f32]);
        let mid = |i: usize| { let (a, b) = (uv(i), uv(i + 1)); [(a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5] };
        for i in 0..k {
            let (e_next, e_prev) = (t.corner_edge[c0 + i], t.corner_edge[c0 + (i + k - 1) % k]);
            out.faces.push(&[f[i], ebase + e_next, fbase + fi as u32, ebase + e_prev]);
            if uvs {
                out.loop_uvs.extend([uv(i), mid(i), center, mid(i + k - 1)]);
            }
            out.face_materials.extend(m.face_materials.get(fi).copied());
            out.face_smooth.extend(m.face_smooth.get(fi).copied());
        }
    }
    *m = out;
}
