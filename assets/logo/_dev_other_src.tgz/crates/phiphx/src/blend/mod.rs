//! The native `.blend` reader. Parses Blender's SDNA container and extracts
//! the scene Blender would show, without Blender installed. Entered through
//! `crate::phx::Phx`; `BlendImporter` serves the asset pipeline.
//! Status and next steps: `jobs.md` in this folder.

use crate::Result;
use std::path::Path;


mod anim;
mod asset;
mod file;
mod modifier;
mod object;
mod scene;
mod shade;
pub mod mesh;

pub use file::quick::{BlendQuickInfo, BlendRenderInfo, BlendThumbnail};
pub use file::types::{
    BHeadType, BlendBlock, BlendCollection, BlendFile, BlendHeader, BlendMaterial, BlendScene,
    BlendSceneObject, DnaField, DnaStruct, DnaType,
};
pub use modifier::BlendEvalMesh;
pub use modifier::skin::{CpuSkin, SKIN_MIN, SkinJob, SkinPair, Skinner, set_skinner};
pub(crate) use modifier::supported_modifiers;
pub use object::kind::ObjectKind;
pub use object::data::{BlendCameraData, BlendEmptyData, BlendLightData, BlendObjectData};
pub use object::layer::{BASE_HIDDEN, BASE_SELECTED, LAYER_COLLECTION_EXCLUDE, LAYER_COLLECTION_HIDE, ViewLayerInfo};
pub use scene::props::BlendSceneProps;
pub use scene::types::BlendBsdf;
pub use shade::links::BlendNormalMap;
pub use shade::maps::BlendMaps;
pub use mesh::list::BFaces;
pub use scene::ui::{BlendUiState, BlendView3d, RV3D_CAMOB, RV3D_ORTHO};
pub use shade::image::PackedImages;

/// Structure encapsulating all Blender (.blend) asset import capabilities.
pub struct BlendImporter;

impl BlendImporter {
    /// Read a .blend file and extract a BlendScene.
    /// Zstd-compressed files (Blender 4.5+ "compressed" saves, and all of the
    /// upstream test suite) are decompressed transparently, like blenloader.
    pub fn import_blend_native(path: &Path) -> Result<BlendScene> {
        Self::import_blend_native_with_progress(path, &|_, _| true)
    }

    /// Read a .blend file, reporting progress through `progress(fraction,
    /// stage)`. The callback returns `false` to cancel; a cancelled read
    /// returns [`PointCloudError::Cancelled`].
    ///
    /// Opening a file has **no side effects on disk** (Blender's
    /// `WM_file_read` never writes beside the file). The asset-import
    /// pipeline that wants a `.phx` sidecar calls
    /// [`Self::import_blend_native_with_sidecar`] instead.
    ///
    /// Stage fractions (mirroring the phases of `blo_read_file_internal`):
    /// 0.00–0.05 read bytes · 0.05–0.45 block table + DNA · 0.45–0.90 IDs
    /// (objects/meshes/materials) · 0.90–1.00 scene assembly.
    pub fn import_blend_native_with_progress(
        path: &Path,
        progress: &(dyn Fn(f32, &str) -> bool + Sync),
    ) -> Result<BlendScene> {
        use crate::PointCloudError;
        if !progress(0.0, "Reading file") {
            return Err(PointCloudError::Cancelled);
        }
        let data = std::fs::read(path)?;
        let total = data.len().max(1) as f64;
        if !progress(0.05, "Indexing blocks") {
            return Err(PointCloudError::Cancelled);
        }

        let cancelled = std::sync::atomic::AtomicBool::new(false);
        let mut on_block = |blocks: usize, bytes: u64| {
            // Compressed files decompress to more bytes than `total`; clamp.
            let frac = (bytes as f64 / total).min(1.0) as f32;
            let label = format!("Indexing blocks ({blocks})");
            if !progress(0.05 + 0.40 * frac, &label) {
                cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
            }
        };
        let blend = BlendFile::parse_bytes_with_progress(&data, &mut on_block)?;
        if cancelled.load(std::sync::atomic::Ordering::Relaxed) {
            return Err(PointCloudError::Cancelled);
        }

        let scene = blend.extract_scene_with_progress(&|f, s| progress(0.45 + 0.45 * f, s))?;
        if !progress(0.95, "Building scene") {
            return Err(PointCloudError::Cancelled);
        }
        Ok(scene)
    }

    /// Asset-import variant: read the file **and** emit a portable `.phx`
    /// sidecar beside it (best-effort; never fails the import). Only the
    /// asset pipeline (`AssetImporter`) should call this — opening a file in
    /// the editor must not write next to the user's data.
    pub fn import_blend_native_with_sidecar(path: &Path) -> Result<BlendScene> {
        let scene = Self::import_blend_native(path)?;
        scene.write_sidecar(path);
        Ok(scene)
    }
}

#[cfg(test)]
#[path = "tests/file.rs"]
mod file_tests;

#[cfg(test)]
#[path = "tests/blend.rs"]
mod tests;
