//! Scene-level properties Blender shows on open: frame range / fps
//! (`Scene.r.cfra/sfra/efra/frs_sec/frs_sec_base`), output resolution
//! (`Scene.r.xsch/ysch/size`), render engine (`Scene.r.engine`) and the
//! world's horizon colour (`Scene.world → World.horr/horg/horb`).
//! `Scene.r` is an embedded `RenderData`, so its fields are read at
//! `offset(Scene.r) + offset(RenderData.<field>)`.

use crate::blend::file::types::*;

#[derive(Debug, Clone, PartialEq)]
pub struct BlendSceneProps {
    pub frame_current: i32,
    pub frame_start: i32,
    pub frame_end: i32,
    pub fps: f32,
    pub resolution_x: i32,
    pub resolution_y: i32,
    pub resolution_percent: i32,
    pub engine: String,
    pub world_color: [f32; 3],
    pub view_layer_name: String,
    /// File version from the header ("3.6", "5.2").
    pub file_version: String,
    /// Workspace + 3D view to restore ("Load UI", `ui_state.rs`).
    pub ui: crate::blend::scene::ui::BlendUiState,
    /// Packed image bytes by image key (`image.rs`).
    pub packed_images: crate::blend::shade::image::PackedImages,
    /// Modifier-evaluated meshes by object index (`modifier/`); the
    /// object's own geometry stays the rest mesh (`Object.data`).
    pub evaluated: std::collections::HashMap<usize, crate::blend::modifier::BlendEvalMesh>,
}

impl Default for BlendSceneProps {
    fn default() -> Self {
        Self {
            frame_current: 1,
            frame_start: 1,
            frame_end: 250,
            fps: 24.0,
            resolution_x: 1920,
            resolution_y: 1080,
            resolution_percent: 100,
            engine: "BLENDER_EEVEE".to_string(),
            world_color: [0.05, 0.05, 0.05],
            view_layer_name: "ViewLayer".to_string(),
            file_version: String::new(),
            ui: Default::default(),
            packed_images: Vec::new(),
            evaluated: Default::default(),
        }
    }
}

impl BlendFile {
    fn rd_off(&self, field: &str, dna: &DnaType) -> Option<usize> {
        let ps = self.header.pointer_size as usize;
        let r = Self::struct_field_offset_exact("Scene", "r", dna, ps)?;
        Some(r + Self::struct_field_offset_exact("RenderData", field, dna, ps)?)
    }

    fn sp_i32(&self, d: &[u8], off: Option<usize>, dflt: i32) -> i32 {
        match off {
            Some(o) if o + 4 <= d.len() => self.read_i32(&d[o..o + 4]),
            _ => dflt,
        }
    }
    fn sp_i16(&self, d: &[u8], off: Option<usize>, dflt: i32) -> i32 {
        match off {
            Some(o) if o + 2 <= d.len() => self.read_u16(&d[o..o + 2]) as i16 as i32,
            _ => dflt,
        }
    }
    fn sp_f32(&self, d: &[u8], off: Option<usize>, dflt: f32) -> f32 {
        match off {
            Some(o) if o + 4 <= d.len() => self.read_f32(&d[o..o + 4]),
            _ => dflt,
        }
    }

    pub(crate) fn extract_scene_props(&self, sc: &BlendBlock, dna: &DnaType) -> BlendSceneProps {
        let ps = self.header.pointer_size as usize;
        let le = self.header.little_endian;
        let d = &sc.data;
        let dflt = BlendSceneProps::default();
        let frs_sec = self.sp_i16(d, self.rd_off("frs_sec", dna), 24) as f32;
        let frs_sec_base = self.sp_f32(d, self.rd_off("frs_sec_base", dna), 1.0).max(1e-6);
        let engine = self
            .rd_off("engine[32]", dna)
            .map(|o| {
                let end = (o + 32).min(d.len());
                let b = &d[o.min(end)..end];
                let n = b.iter().position(|&c| c == 0).unwrap_or(b.len());
                String::from_utf8_lossy(&b[..n]).to_string()
            })
            .filter(|e| !e.is_empty())
            .unwrap_or(dflt.engine.clone());
        let world_color = Self::struct_field_offset_exact("Scene", "*world", dna, ps)
            .map(|o| Self::read_ptr(d, o, ps, le))
            .and_then(|addr| self.block_at_code(addr, "WO"))
            .map(|wo| {
                let c = |f: &str| {
                    self.sp_f32(&wo.data, Self::struct_field_offset_exact("World", f, dna, ps), 0.05)
                };
                [c("horr"), c("horg"), c("horb")]
            })
            .unwrap_or(dflt.world_color);
        BlendSceneProps {
            frame_current: self.sp_i32(d, self.rd_off("cfra", dna), 1),
            frame_start: self.sp_i32(d, self.rd_off("sfra", dna), 1),
            frame_end: self.sp_i32(d, self.rd_off("efra", dna), 250),
            fps: frs_sec / frs_sec_base,
            resolution_x: self.sp_i32(d, self.rd_off("xsch", dna), 1920),
            resolution_y: self.sp_i32(d, self.rd_off("ysch", dna), 1080),
            resolution_percent: self.sp_i16(d, self.rd_off("size", dna), 100),
            engine,
            world_color,
            view_layer_name: dflt.view_layer_name,
            file_version: self.header.version_label(),
            ui: Default::default(),
            packed_images: Vec::new(),
            evaluated: Default::default(),
        }
    }
}
