//! Principled BSDF input values carried by a material slot.

/// Unlinked Principled BSDF input values (Blender defaults when absent).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BlendBsdf {
    pub base: [f32; 4],
    pub roughness: f32,
    pub metallic: f32,
    pub alpha: f32,
    pub ior: f32,
    pub transmission: f32,
    pub emission: [f32; 3],
    pub emission_strength: f32,
}

impl Default for BlendBsdf {
    fn default() -> Self {
        Self {
            base: [0.8, 0.8, 0.8, 1.0],
            roughness: 0.5,
            metallic: 0.0,
            alpha: 1.0,
            ior: 1.5,
            transmission: 0.0,
            emission: [0.0; 3],
            emission_strength: 0.0,
        }
    }
}

impl BlendBsdf {
    /// Emitted radiance (colour × strength).
    pub fn emitted(&self) -> [f32; 3] {
        self.emission.map(|c| c * self.emission_strength)
    }
}
