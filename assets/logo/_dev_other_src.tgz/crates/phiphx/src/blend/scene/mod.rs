//! Scene assembly. `extract_scene`, scene properties, result types, saved UI (workspace, 3D view).
//! Status and next steps: `jobs.md` in this folder.

pub mod props;
pub(crate) mod read;
pub mod bsdf;
pub mod types;
pub mod ui;
