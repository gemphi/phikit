//! Image datablocks (#26): the key a material uses to name its texture and
//! the bytes of images packed into the `.blend`.
//!
//! Blender ref (`DNA_image_types.h`, `DNA_packedFile_types.h`,
//! `packedFile.cc`): `Image { filepath[1024], packedfiles (ListBase of
//! ImagePackedFile { *packedfile, filepath, view, tile_number }),
//! *packedfile (legacy) }`, `PackedFile { int size; int seek; *data }`.
//! The data is written as its own block at the old `data` address.

use crate::blend::file::types::*;
use std::sync::Arc;

/// `(image key, packed file bytes)` for every packed image in the file.
pub type PackedImages = Vec<(String, Arc<Vec<u8>>)>;

impl BlendFile {
    /// How materials refer to an image: its `filepath`, or `ID.name` (no
    /// prefix) for generated / packed images saved without a path.
    pub(crate) fn image_key(&self, im: &BlendBlock, dna: &DnaType) -> String {
        let path = self.off("Image", "filepath[1024]", dna).or_else(|| self.off("Image", "name[1024]", dna)).map_or(String::new(), |o| cstr(&im.data, o, 1024));
        if !path.is_empty() {
            return path;
        }
        let o = self.id_name_offset(dna).unwrap_or(usize::MAX);
        let name = cstr(&im.data, o, 66);
        name.get(2..).unwrap_or_default().to_string()
    }

    fn packed_bytes(&self, pf_addr: u64, dna: &DnaType) -> Option<Vec<u8>> {
        let pf = self.block_at(pf_addr)?;
        let size = self.int_field(pf, "PackedFile", "size", dna) as usize;
        let data = self.block_at(self.ptr(pf, self.off("PackedFile", "*data", dna)))?;
        (size > 0 && size <= data.data.len()).then(|| data.data[..size].to_vec())
    }

    /// Packed image bytes keyed like [`Self::image_key`].
    pub(crate) fn packed_images(&self, dna: &DnaType) -> PackedImages {
        let mut out = PackedImages::new();
        for im in self.blocks.iter().filter(|b| b.code_str == "IM") {
            let bytes = self.scoped(im, || {
                let first = self.ptr(im, self.off("Image", "packedfiles", dna));
                let pf = match self.block_at(first) {
                    Some(ipf) => self.ptr(ipf, self.off("ImagePackedFile", "*packedfile", dna)),
                    None => self.ptr(im, self.off("Image", "*packedfile", dna)),
                };
                self.packed_bytes(pf, dna)
            });
            if let Some(bytes) = bytes {
                out.push((self.image_key(im, dna), Arc::new(bytes)));
            }
        }
        out
    }
}

fn cstr(data: &[u8], off: usize, max: usize) -> String {
    if off >= data.len() {
        return String::new();
    }
    let s = &data[off..(off + max).min(data.len())];
    let n = s.iter().position(|&b| b == 0).unwrap_or(s.len());
    String::from_utf8_lossy(&s[..n]).to_string()
}
