//! Constant folding of a material's colour graph (Mix, Color Ramp,
//! Hue/Saturation, Invert, RGB/Value, Reroute) into one representative
//! value per Principled input. Textures have no single value: image colour
//! counts as white (so the result is the tint the image is multiplied by)
//! and procedural outputs as their mean 0.5; such results are marked inexact.
//! Formulas follow Blender's GPU nodes (`gpu_shader_material_mix_color.glsl`,
//! `…_hue_sat_val.glsl`, `BKE_colorband_evaluate`).

use super::links::BLink;
use super::nodes::read_cstr;
use crate::blend::file::types::*;

/// A folded socket value: colour (floats are grey), and whether it is exact.
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct BVal {
    pub rgba: [f32; 4],
    pub float: bool,
    pub exact: bool,
}

impl BVal {
    fn f(v: f32, exact: bool) -> Self {
        Self { rgba: [v, v, v, 1.0], float: true, exact }
    }
    fn c(rgba: [f32; 4], exact: bool) -> Self {
        Self { rgba, float: false, exact }
    }
    /// As a float socket (colour → Rec.709 luminance, like Blender).
    pub fn value(&self) -> f32 {
        let [r, g, b, _] = self.rgba;
        if self.float { r } else { 0.2126 * r + 0.7152 * g + 0.0722 * b }
    }
}

/// `eNodeSocketDatatype`.
const SOCK_FLOAT: u16 = 0;
const SOCK_VECTOR: u16 = 1;
const SOCK_RGBA: u16 = 2;

pub(crate) struct BGraph<'a> {
    f: &'a BlendFile,
    dna: &'a DnaType,
    nodes: Vec<&'a BlendBlock>,
    links: Vec<BLink>,
}

impl<'a> BGraph<'a> {
    pub fn new(f: &'a BlendFile, ma: &BlendBlock, dna: &'a DnaType) -> Self {
        Self { f, dna, nodes: f.shader_nodes(ma, dna), links: f.links(ma, dna) }
    }

    fn off(&self, s: &str, field: &str) -> Option<usize> {
        self.f.off(s, field, self.dna)
    }

    fn text(&self, b: &BlendBlock, s: &str, field: &str) -> String {
        self.off(s, field).map(|o| read_cstr(&b.data, o, 64)).unwrap_or_default()
    }

    pub fn linked(&self, sock: u64) -> bool {
        self.links.iter().any(|l| l.to_sock == sock)
    }

    /// Value arriving at input socket `sock` (its own default when unlinked).
    pub fn input(&self, sock: u64, depth: u32) -> Option<BVal> {
        match self.links.iter().find(|l| l.to_sock == sock) {
            Some(l) if depth < 64 => {
                let node = self.nodes.iter().copied().find(|n| n.old_address == l.from)?;
                let out = self.f.block_at(l.from_sock)?;
                self.output(node, &self.text(out, "bNodeSocket", "identifier"), &self.text(out, "bNodeSocket", "name"), depth + 1)
            }
            Some(_) => None,
            None => self.default(self.f.block_at(sock)?),
        }
    }

    /// A socket's stored `default_value`.
    fn default(&self, s: &BlendBlock) -> Option<BVal> {
        let ty = self.f.read_u16(s.data.get(self.off("bNodeSocket", "type")?..)?.get(..2)?);
        let v = self.f.block_at(self.f.ptr(s, self.off("bNodeSocket", "*default_value")))?;
        let fl = |i: usize| v.data.get(i..i + 4).map(|b| self.f.read_f32(b));
        Some(match ty {
            SOCK_FLOAT => BVal::f(fl(4)?, true),
            SOCK_VECTOR => BVal::f((fl(4)? + fl(8)? + fl(12)?) / 3.0, true),
            SOCK_RGBA => BVal::c([fl(0)?, fl(4)?, fl(8)?, fl(12)?], true),
            _ => return None,
        })
    }

    /// Input of `node` by identifier (falls back to name).
    fn arg(&self, node: &BlendBlock, id: &str, depth: u32) -> Option<BVal> {
        let socks = self.f.input_sockets(node, self.dna);
        let find = |field: &str| {
            socks.iter().copied().find(|&a| self.f.block_at(a).is_some_and(|b| self.text(b, "bNodeSocket", field) == id))
        };
        self.input(find("identifier").or_else(|| find("name"))?, depth)
    }

    fn output(&self, node: &BlendBlock, out_id: &str, out_name: &str, depth: u32) -> Option<BVal> {
        let kind = self.text(node, "bNode", "idname");
        let arg = |id: &str| self.arg(node, id, depth);
        let storage = || self.f.block_at(self.f.ptr(node, self.off("bNode", "*storage")));
        match kind.as_str() {
            "ShaderNodeMix" => {
                let st = storage()?;
                let byte = |f: &str| self.off("NodeShaderMix", f).and_then(|o| st.data.get(o)).copied().unwrap_or(0);
                let fac = arg("Factor_Float")?;
                let (a, b) = match byte("data_type") as u16 {
                    SOCK_RGBA => (arg("A_Color")?, arg("B_Color")?),
                    _ => (arg("A_Float")?, arg("B_Float")?),
                };
                let t = if byte("clamp_factor") != 0 { fac.value().clamp(0.0, 1.0) } else { fac.value() };
                let mut rgba = super::blend::mix(byte("blend_type"), t, a.rgba, b.rgba);
                if byte("clamp_result") != 0 {
                    rgba = rgba.map(|c| c.clamp(0.0, 1.0));
                }
                Some(BVal { rgba, float: a.float, exact: fac.exact && a.exact && b.exact })
            }
            "ShaderNodeMixRGB" => {
                let (fac, a, b) = (arg("Fac")?, arg("Color1")?, arg("Color2")?);
                let blend = self.off("bNode", "custom1").and_then(|o| node.data.get(o)).copied().unwrap_or(0);
                Some(BVal::c(super::blend::mix(blend, fac.value().clamp(0.0, 1.0), a.rgba, b.rgba), fac.exact && a.exact && b.exact))
            }
            "ShaderNodeValToRGB" => {
                let fac = arg("Fac")?;
                let c = super::blend::ramp(self.f, self.dna, storage()?, fac.value())?;
                Some(if out_name == "Alpha" { BVal::f(c[3], fac.exact) } else { BVal::c(c, fac.exact) })
            }
            "ShaderNodeHueSaturation" => {
                let (h, s, v, fac, c) = (arg("Hue")?, arg("Saturation")?, arg("Value")?, arg("Fac")?, arg("Color")?);
                let out = super::blend::hue_sat(c.rgba, h.value(), s.value(), v.value(), fac.value());
                Some(BVal::c(out, [h, s, v, fac, c].iter().all(|x| x.exact)))
            }
            "ShaderNodeInvert" => {
                let (fac, c) = (arg("Fac")?, arg("Color")?);
                let t = fac.value();
                let rgb = [0, 1, 2].map(|k| c.rgba[k] + t * (1.0 - 2.0 * c.rgba[k]));
                Some(BVal::c([rgb[0], rgb[1], rgb[2], c.rgba[3]], fac.exact && c.exact))
            }
            "ShaderNodeRGB" | "ShaderNodeValue" => {
                let outs = self.f.list(self.f.ptr(node, self.off("bNode", "outputs")), self.off("bNodeSocket", "*next"));
                self.default(outs.first()?)
            }
            "NodeReroute" => self.input(*self.f.input_sockets(node, self.dna).first()?, depth),
            "ShaderNodeRGBCurve" => arg("Color").map(|c| BVal { exact: false, ..c }),
            "ShaderNodeTexImage" => Some(if out_id == "Alpha" { BVal::f(1.0, false) } else { BVal::c([1.0; 4], false) }),
            k if k.starts_with("ShaderNodeTex") => {
                Some(if out_name == "Color" { BVal::c([0.5, 0.5, 0.5, 1.0], false) } else { BVal::f(0.5, false) })
            }
            _ => None,
        }
    }
}
