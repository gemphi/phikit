//! World-matrix resolution and view-layer flag application — the parts of
//! `BKE_object_where_is_calc` / `BKE_layer_collection_sync` Phiber needs.

use crate::blend::file::types::*;

impl BlendFile {
    /// Rebuild every object's world matrix from its parent chain, the way
    /// `BKE_object_where_is_calc` does (`world = parent.world · parentinv ·
    /// local`). Objects whose parent is not in the scene (or a cycle) fall
    /// back to their local matrix. Only `PAROBJECT` parenting is modelled;
    /// bone/vertex parenting uses the parent object's matrix as an
    /// approximation.
    pub(crate) fn resolve_world_matrices(objects: &mut [BlendSceneObject]) {
        use std::collections::HashMap;
        let by_addr: HashMap<u64, usize> = objects
            .iter()
            .enumerate()
            .filter(|(_, o)| o.block_address != 0)
            .map(|(i, o)| (o.block_address, i))
            .collect();
        let n = objects.len();
        let mut world: Vec<Option<[[f32; 4]; 4]>> = vec![None; n];

        fn solve(
            i: usize,
            objects: &[BlendSceneObject],
            by_addr: &HashMap<u64, usize>,
            world: &mut [Option<[[f32; 4]; 4]>],
            depth: usize,
        ) -> [[f32; 4]; 4] {
            if let Some(w) = world[i] {
                return w;
            }
            let o = &objects[i];
            let w = match by_addr.get(&o.parent_address) {
                Some(&p) if p != i && depth < 256 => {
                    let pw = solve(p, objects, by_addr, world, depth + 1);
                    crate::blend::object::transform::compose_world(&pw, &o.parentinv, &o.matrix_local)
                }
                _ => o.matrix_local,
            };
            world[i] = Some(w);
            w
        }

        for i in 0..n {
            let w = solve(i, objects, &by_addr, &mut world, 0);
            objects[i].matrix_world = w;
        }
    }
}

/// Copy `LayerCollection` exclude / hide flags onto the collection tree.
pub(crate) fn apply_layer_flags(c: &mut BlendCollection, flags: &std::collections::HashMap<u64, u32>) {
    if let Some(f) = flags.get(&c.block_address) {
        c.exclude = f & crate::blend::object::layer::LAYER_COLLECTION_EXCLUDE != 0;
        c.hide_viewport = f & crate::blend::object::layer::LAYER_COLLECTION_HIDE != 0;
    }
    for child in &mut c.children {
        apply_layer_flags(child, flags);
    }
}
