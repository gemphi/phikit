//! Objects. DNA fields, transforms and parent chain, rotation modes, kind, camera/light/empty data, collections, view layer, world.
//! Status and next steps: `jobs.md` in this folder.

pub(crate) mod collection;
pub mod data;
pub(crate) mod dna;
pub(crate) mod kind;
pub mod layer;
pub(crate) mod meta;
pub(crate) mod read;
pub(crate) mod rotation;
pub(crate) mod transform;
pub(crate) mod world;
