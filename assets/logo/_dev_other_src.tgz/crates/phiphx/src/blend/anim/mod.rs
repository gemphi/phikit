//! Animation — task 17. Reading actions and evaluating them at a frame.
//!
//! (a) object keyframes: [`read`] takes layered (4.4+) and legacy actions to
//!     [`fcurve::BFCurve`]s; [`channels`] writes them over a transform.
//! (b) pose-bone keyframes: [`pose`] builds each bone's basis and the plain
//!     `BKE_pose_where_is` chain.
//! (c) constraints and drivers — not yet. Rigify's deforming bones are moved
//!     by constraints, so a rigged character does not move until (c) lands.
//!
//! Every step is checked against Blender at several frames
//! (`tests/truth/thymus_anim.txt`, made by `truth/blender_anim.py`).

pub mod channels;
pub mod fcurve;
pub mod pose;
pub mod read;


#[cfg(test)]
mod tests;
