//! Reading `bAction` blocks — Blender 4.4+ layered actions
//! (`layer_array → strip_array → strip_keyframe_data_array → channelbag_array
//! → fcurve_array`, each channelbag bound to a slot) and the legacy
//! `curves` list — and which action and slot an object uses
//! (`Object.adt → AnimData.action / slot_handle`).

use super::fcurve::{BFCurve, BKey};
use crate::blend::file::types::*;
use std::collections::HashMap;

/// An action's curves, grouped by the slot they animate. Legacy actions have
/// one group under slot 0.
#[derive(Clone, Debug, Default)]
pub struct BAction {
    pub name: String,
    pub by_slot: HashMap<i32, Vec<BFCurve>>,
}

impl BAction {
    /// The curves for `slot`, or the only slot's when the handle is unknown.
    pub fn curves(&self, slot: i32) -> &[BFCurve] {
        self.by_slot
            .get(&slot)
            .or_else(|| (self.by_slot.len() == 1).then(|| self.by_slot.values().next()).flatten())
            .map_or(&[], Vec::as_slice)
    }
}

/// Which action, and which slot in it, an object's `AnimData` points at.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct BBinding {
    pub action: u64,
    pub slot: i32,
}

impl BlendFile {
    /// A pointer array of `n` block addresses at `field` of `block`.
    fn ptr_array(&self, block: &BlendBlock, st: &str, field: &str, count: &str, dna: &DnaType) -> Vec<u64> {
        let n = self.int_field(block, st, count, dna) as usize;
        let Some(arr) = self.block_at(self.ptr(block, self.off(st, field, dna))) else { return Vec::new() };
        let ps = self.header.pointer_size as usize;
        (0..n.min(arr.data.len() / ps.max(1)))
            .map(|i| Self::read_ptr(&arr.data, i * ps, ps, self.header.little_endian))
            .collect()
    }

    /// One `FCurve` block: its path, index and keys.
    fn fcurve(&self, fc: &BlendBlock, dna: &DnaType) -> Option<BFCurve> {
        let path = self.cstring_at(fc, "FCurve", "*rna_path", dna)?;
        let index = self.int_field(fc, "FCurve", "array_index", dna);
        let n = self.int_field(fc, "FCurve", "totvert", dna) as usize;
        let size = Self::struct_size("BezTriple", dna, self.header.pointer_size as usize)?;
        let (vec_o, ipo_o) = (self.off("BezTriple", "vec[3][3]", dna)?, self.off("BezTriple", "ipo", dna)?);
        let keys = match self.block_at(self.ptr(fc, self.off("FCurve", "*bezt", dna))) {
            Some(b) => (0..n)
                .filter_map(|i| {
                    let d = b.data.get(i * size..(i + 1) * size)?;
                    let f = |k: usize| -> Option<f32> { Some(self.read_f32(d.get(vec_o + k * 4..vec_o + k * 4 + 4)?)) };
                    Some(BKey {
                        h1: [f(0)?, f(1)?],
                        co: [f(3)?, f(4)?],
                        h2: [f(6)?, f(7)?],
                        ipo: d.get(ipo_o).copied().unwrap_or(2),
                    })
                })
                .collect(),
            None => Vec::new(),
        };
        Some(BFCurve { path, index, keys })
    }

    /// Every action in the file, by block address.
    pub(crate) fn actions(&self, dna: &DnaType) -> HashMap<u64, BAction> {
        let mut out = HashMap::new();
        for ac in self.blocks.iter().filter(|b| b.code_str == "AC") {
            let mut action = BAction { name: self.id_name(ac, dna), ..Default::default() };
            self.scoped(ac, || {
                // Layered: every strip's keyframe data, every channelbag.
                let data = self.ptr_array(ac, "bAction", "*strip_keyframe_data_array", "strip_keyframe_data_array_num", dna);
                for layer in self.ptr_array(ac, "bAction", "*layer_array", "layer_array_num", dna) {
                    let Some(layer) = self.block_at(layer) else { continue };
                    for strip in self.ptr_array(layer, "ActionLayer", "*strip_array", "strip_array_num", dna) {
                        let Some(strip) = self.block_at(strip) else { continue };
                        let idx = self.int_field(strip, "ActionStrip", "data_index", dna) as usize;
                        let Some(kd) = data.get(idx).and_then(|&a| self.block_at(a)) else { continue };
                        for bag in self.ptr_array(kd, "ActionStripKeyframeData", "*channelbag_array", "channelbag_array_num", dna) {
                            let Some(bag) = self.block_at(bag) else { continue };
                            let slot = self.int_field(bag, "ActionChannelbag", "slot_handle", dna) as i32;
                            let curves = self
                                .ptr_array(bag, "ActionChannelbag", "*fcurve_array", "fcurve_array_num", dna)
                                .into_iter()
                                .filter_map(|a| self.fcurve(self.block_at(a)?, dna));
                            action.by_slot.entry(slot).or_default().extend(curves);
                        }
                    }
                }
                // Legacy (≤ 4.3): a plain list of curves.
                if action.by_slot.is_empty() {
                    let first = self.ptr(ac, self.off("bAction", "curves", dna));
                    let curves: Vec<BFCurve> = self
                        .list(first, self.off("FCurve", "*next", dna))
                        .into_iter()
                        .filter_map(|fc| self.fcurve(fc, dna))
                        .collect();
                    if !curves.is_empty() {
                        action.by_slot.insert(0, curves);
                    }
                }
            });
            out.insert(ac.old_address, action);
        }
        out
    }

    /// The action and slot `ob` is bound to, if it has animation data.
    pub(crate) fn binding(&self, ob: &BlendBlock, dna: &DnaType) -> Option<BBinding> {
        let adt = self.block_at(self.ptr(ob, self.off("Object", "*adt", dna)))?;
        let action = self.ptr(adt, self.off("AnimData", "*action", dna));
        (action != 0).then(|| BBinding { action, slot: self.int_field(adt, "AnimData", "slot_handle", dna) as i32 })
    }

    /// `ID.name` without its two-letter code.
    fn id_name(&self, block: &BlendBlock, dna: &DnaType) -> String {
        let Some(o) = self.id_name_offset(dna) else { return String::new() };
        let s = block.data.get(o + 2..(o + 66).min(block.data.len())).unwrap_or(&[]);
        let z = s.iter().position(|&c| c == 0).unwrap_or(s.len());
        String::from_utf8_lossy(&s[..z]).to_string()
    }
}
