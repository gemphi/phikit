//! One F-Curve and its evaluation — Blender `fcurve.cc::fcurve_eval_keyframes`
//! for the interpolations a saved file carries: constant, linear, Bézier.
//! Outside the keyed range the curve holds its end values
//! (`FCURVE_EXTRAPOLATE_CONSTANT`, the default).

/// One keyframe: `BezTriple.vec[0..3]` as (x, y) — left handle, point, right
/// handle — and its interpolation to the next key.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BKey {
    pub h1: [f32; 2],
    pub co: [f32; 2],
    pub h2: [f32; 2],
    /// `BEZT_IPO_CONST` 0, `_LIN` 1, `_BEZ` 2.
    pub ipo: u8,
}

#[derive(Clone, Debug, PartialEq)]
pub struct BFCurve {
    /// `rna_path`, e.g. `location` or `pose.bones["chest"].rotation_quaternion`.
    pub path: String,
    pub index: u32,
    pub keys: Vec<BKey>,
}

impl BFCurve {
    /// The bone this curve drives, when its path is a pose-bone path.
    pub fn bone(&self) -> Option<&str> {
        let rest = self.path.strip_prefix("pose.bones[\"")?;
        rest.split("\"]").next()
    }

    /// The property at the end of the path: `location`, `rotation_euler`, …
    pub fn property(&self) -> &str {
        self.path.rsplit("].").next().unwrap_or(&self.path).rsplit('.').next().unwrap_or(&self.path)
    }

    pub fn eval(&self, frame: f32) -> Option<f32> {
        let keys = &self.keys;
        let (first, last) = (keys.first()?, keys.last()?);
        if frame <= first.co[0] {
            return Some(first.co[1]);
        }
        if frame >= last.co[0] {
            return Some(last.co[1]);
        }
        // The segment [a, b] that holds `frame`.
        let i = keys.partition_point(|k| k.co[0] <= frame);
        let (a, b) = (&keys[i - 1], &keys[i]);
        if (b.co[0] - a.co[0]).abs() < 1e-9 {
            return Some(b.co[1]);
        }
        Some(match a.ipo {
            0 => a.co[1],
            1 => {
                let t = (frame - a.co[0]) / (b.co[0] - a.co[0]);
                a.co[1] + (b.co[1] - a.co[1]) * t
            }
            _ => bezier(a, b, frame),
        })
    }
}

/// `BKE_fcurve_correct_bezpart`: a handle may not reach past the neighbouring
/// key in time, so the segment stays a function of time.
fn correct(v1: [f32; 2], mut v2: [f32; 2], mut v3: [f32; 2], v4: [f32; 2]) -> ([f32; 2], [f32; 2]) {
    let h1 = [v1[0] - v2[0], v1[1] - v2[1]];
    let h2 = [v4[0] - v3[0], v4[1] - v3[1]];
    let len = v4[0] - v1[0];
    let (len1, len2) = (h1[0].abs(), h2[0].abs());
    if len1 + len2 == 0.0 {
        return (v2, v3);
    }
    if len1 > len {
        let fac = len / len1;
        v2 = [v1[0] - fac * h1[0], v1[1] - fac * h1[1]];
    }
    if len2 > len {
        let fac = len / len2;
        v3 = [v4[0] - fac * h2[0], v4[1] - fac * h2[1]];
    }
    (v2, v3)
}

/// Cubic Bézier position at parameter `t` (`berekeny`).
fn at(p0: f32, p1: f32, p2: f32, p3: f32, t: f32) -> f32 {
    let c1 = 3.0 * (p1 - p0);
    let c2 = 3.0 * (p0 - 2.0 * p1 + p2);
    let c3 = p3 - p0 + 3.0 * (p1 - p2);
    p0 + t * c1 + t * t * c2 + t * t * t * c3
}

/// The value of the segment `a → b` at time `frame`: solve the x cubic for
/// `t` (`findzero`), then read the y cubic there. After `correct` the x
/// cubic is monotonic on [0, 1], so a bisection finds the one root.
fn bezier(a: &BKey, b: &BKey, frame: f32) -> f32 {
    let (v2, v3) = correct(a.co, a.h2, b.h1, b.co);
    let (x0, x1, x2, x3) = (a.co[0], v2[0], v3[0], b.co[0]);
    let (mut lo, mut hi) = (0.0f32, 1.0f32);
    for _ in 0..40 {
        let mid = 0.5 * (lo + hi);
        if at(x0, x1, x2, x3, mid) < frame { lo = mid } else { hi = mid }
    }
    let t = 0.5 * (lo + hi);
    at(a.co[1], v2[1], v3[1], b.co[1], t)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key(x: f32, y: f32, ipo: u8) -> BKey {
        BKey { h1: [x - 1.0, y], co: [x, y], h2: [x + 1.0, y], ipo }
    }

    #[test]
    fn holds_its_ends_and_interpolates_between() {
        let c = BFCurve { path: "location".into(), index: 0, keys: vec![key(1.0, 0.0, 1), key(11.0, 10.0, 1)] };
        assert_eq!(c.eval(-5.0), Some(0.0));
        assert_eq!(c.eval(50.0), Some(10.0));
        assert!((c.eval(6.0).unwrap() - 5.0).abs() < 1e-5);
    }

    #[test]
    fn a_flat_bezier_eases_in_and_out() {
        // Flat handles: the curve leaves 0 slowly and arrives at 10 slowly,
        // so it is below the line early and above it late.
        let c = BFCurve { path: "location".into(), index: 0, keys: vec![key(0.0, 0.0, 2), key(10.0, 10.0, 2)] };
        let early = c.eval(2.0).unwrap();
        let late = c.eval(8.0).unwrap();
        assert!(early < 2.0 && early > 0.0, "{early}");
        assert!(late > 8.0 && late < 10.0, "{late}");
        assert!((c.eval(5.0).unwrap() - 5.0).abs() < 1e-4);
    }

    #[test]
    fn paths_split_into_bone_and_property() {
        let c = BFCurve { path: "pose.bones[\"chest\"].rotation_quaternion".into(), index: 1, keys: vec![] };
        assert_eq!(c.bone(), Some("chest"));
        assert_eq!(c.property(), "rotation_quaternion");
        let o = BFCurve { path: "location".into(), index: 0, keys: vec![] };
        assert_eq!(o.bone(), None);
        assert_eq!(o.property(), "location");
    }
}
