# Jobs — `phiphx/blend`

| State | Open | Done |
|---|---|---|
| 🟡 in progress | 3 | 2 |

## Todo

- [ ] Animation reader: legacy `bAction.curves` and layered actions (4.4+); Bézier evaluation
- [ ] Constraints Rigify needs (Copy Transforms/Location/Rotation/Scale, Damped Track, Stretch To, 2-bone IK, Child Of, Armature); simple drivers
- [ ] Linked libraries (`LI` blocks, `ID.lib`)

## Done

- [x] Reads Blender 2.8 → 5.2; 1,276 meshes match Blender 5.0.1 exactly (`tests/blender_truth.rs`)
- [x] Split into `file/`, `object/`, `mesh/`, `shade/`, `scene/`, `modifier/`, `asset/`

Format: one line per job, `- [ ]` open / `- [x]` done; move a line from Todo to Done when it lands, with its test.
