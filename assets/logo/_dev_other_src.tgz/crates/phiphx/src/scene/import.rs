//! Blend → scene conversion helpers. Split out of `scene/mod.rs` so both
//! the file stays under the 200-line cap and the pure geometry pipeline lives
//! in a focused module.
//!
//! Public entry point: [`SceneModel::from_blend`]. Everything else is `pub(super)`
//! so consumers go through the aggregate `SceneModel` rather than reaching
//! into per-object builders.

use super::{
    SceneAction, SceneCamera, SceneLight, SceneModel,
    SceneObject, SceneRender, SceneTimeline, SceneWorld,
};
use crate::blend::BlendScene;
use super::import_extras::{camera_from_blend, empty_from_blend, light_from_blend};

/// Map an imported [`BlendScene`] into a renderable [`SceneModel`].
///
/// This is the single blend→scene traversal in the codebase (Requirement 7.2);
/// it lives in the shared, kit-agnostic layer and nowhere under
/// `crates/phiber/src/`. It mirrors the fan-triangulation
/// `BlendScene::to_phx` already performs so both paths agree.
///
/// For every mesh object it:
///
/// - Triangulates each polygon like Blender (`polyfill.rs`): triangles as-is,
///   quads (0,1,2)+(0,2,3), n-gons ear-clipped on their dominant plane.
/// - Drops any corner whose vertex index is out of range for that object's
///   vertex buffer.
/// - Takes normals from `loop_normals` when present (one per triangle,
///   [`SceneNormals::PerFace`]), otherwise synthesizes a per-face normal.
///
/// Cameras and lights are partitioned into `cameras` / `lights` vectors so
/// the Rendering / Shading spaces can iterate them without a full scan.
///
/// Requirements: 2.5, 2.6, 7.2
impl SceneModel {
/// Build the runtime scene from a read `.blend` scene, freeing each object's
/// raw mesh buffers as soon as it is converted. Opening a 20 M-triangle file
/// otherwise holds the raw arrays and the runtime scene at the same time.
pub fn from_blend_owned(mut blend: BlendScene, source_path: &str) -> SceneModel {
    let raw = std::mem::take(&mut blend.objects);
    Self::build(raw, &blend, source_path)
}

/// Build from a borrowed scene (tests and small files; the raw arrays stay).
pub fn from_blend(blend: &BlendScene, source_path: &str) -> SceneModel {
    Self::build(blend.objects.clone(), blend, source_path)
}

/// `raw` is consumed: each object's buffers are dropped once it is converted.
fn build(raw: Vec<crate::blend::BlendSceneObject>, blend: &BlendScene, source_path: &str) -> SceneModel {
    let mut mesh_jobs: Vec<usize> = Vec::new();
    let mut cameras: Vec<SceneCamera> = Vec::new();
    let mut lights: Vec<SceneLight> = Vec::new();
    // blend index → `objects` index (None for cameras / lights).
    let mut remap: Vec<Option<usize>> = Vec::with_capacity(blend.objects.len());
    let mut object_types: Vec<String> = Vec::new();
    let mut empties = Vec::new();
    let (object_count, face_count) = (raw.len(), raw.iter().map(|o| o.faces.len()).sum::<usize>());
    for (blend_i, obj) in raw.iter().enumerate() {
        match obj.object_type.as_str() {
            "CAMERA" => {
                cameras.push(camera_from_blend(obj));
                remap.push(None);
            }
            "LAMP" | "LIGHT" => {
                lights.push(light_from_blend(obj));
                remap.push(None);
            }
            "EMPTY" => {
                empties.push(empty_from_blend(obj));
                remap.push(None);
            }
            _ => {
                remap.push(Some(mesh_jobs.len()));
                object_types.push(obj.object_type.clone());
                mesh_jobs.push(blend_i);
            }
        }
    }
    // Triangulation + normals are independent per object.
    use rayon::prelude::*;
    // The saved 3D view resolves `Scene.camera` against the objects, so read it
    // before the conversion consumes them.
    let ui = super::ui::ui_from_blend(&blend.props.ui, &raw);
    // Collections and selection name objects by index — also read before the take.
    let collections = super::collection::collections_from_blend(blend, &raw, &remap);
    let selection = super::collection::selection_from_blend(blend, &raw);
    // `into_par_iter` hands each object to the closure by value, so its raw
    // vertices, faces and loop data are freed as the conversion walks on.
    let wanted: std::collections::HashSet<usize> = mesh_jobs.iter().copied().collect();
    let mut objects: Vec<SceneObject> = raw
        .into_par_iter()
        .enumerate()
        .filter(|(i, _)| wanted.contains(i))
        .map(|(i, obj)| evaluated_object(&obj, blend.props.evaluated.get(&i)))
        .collect();
    let p = &blend.props;
    let missing = super::texture::attach(&mut objects, p, source_path);
    let report = super::report::SceneReadReport {
        scene: blend.name.clone(),
        file_version: p.file_version.clone(),
        duration_ms: 0,
        objects: object_count,
        verts: objects.iter().map(|o| o.mesh.vertices.len()).sum(),
        faces: face_count,
        tris: objects.iter().map(|o| o.mesh.indices.len() / 3).sum(),
        cameras: cameras.len(),
        lights: lights.len(),
        empties: empties.len(),
        warnings: missing.iter().map(|k| format!("Image \"{k}\" not found")).collect(),
    };
    SceneModel {
        report,
        objects,
        source_path: Some(source_path.to_string()),
        timeline: SceneTimeline {
            frame_start: p.frame_start,
            frame_end: p.frame_end,
            current_frame: p.frame_current,
            fps: p.fps,
        },
        world: SceneWorld {
            horizon_color: p.world_color,
        },
        render: SceneRender {
            resolution_x: p.resolution_x,
            resolution_y: p.resolution_y,
            resolution_percent: p.resolution_percent,
            engine: p.engine.clone(),
        },
        cameras,
        lights,
        actions: Vec::<SceneAction>::new(),
        collections,
        selection,
        object_types,
        empties,
        ui,
    }
}
}

use super::object::evaluated_object;
