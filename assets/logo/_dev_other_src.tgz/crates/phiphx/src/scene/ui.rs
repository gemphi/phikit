//! "Load UI" (#28): the workspace and 3D view a `.blend` restores, reduced
//! to what the viewport consumes. Blender ref: `RegionView3D` — the view
//! looks down `-viewinv[2]` at the pivot `-ofs`, `dist` away; `persp` 0 =
//! ortho, 1 = perspective, 2 = through `Scene.camera`.

use crate::blend::{BlendSceneObject, BlendUiState, RV3D_CAMOB, RV3D_ORTHO};

/// Blender viewport sensor (`DEFAULT_SENSOR_WIDTH`) × initial zoom (2) over
/// the default lens (50 mm): visible width ≈ `VIEW_WIDTH_PER_DIST * dist`
/// (`BKE_camera_params_from_view3d`, `CAMERA_PARAM_ZOOM_INIT_PERSP`).
pub const VIEW_WIDTH_PER_DIST: f32 = 36.0 * 2.0 / 50.0;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct SceneView {
    /// Azimuth about world Z, degrees `[0, 360)`; 0 looks along +Y.
    pub yaw_deg: f32,
    /// Elevation, degrees; positive looks down.
    pub pitch_deg: f32,
    pub perspective: bool,
    /// The file was saved looking through the scene camera.
    pub camera_view: bool,
    /// World-space point the view orbits (`-RegionView3D.ofs`).
    pub pivot: [f32; 3],
    /// Visible width in Blender units at the pivot.
    pub width: f32,
    /// Perspective spread: visible width per unit of distance from the eye.
    pub fov: f32,
    /// Saved shading: `"wireframe"`, `"solid"`, `"material"`, `"rendered"`, or empty.
    pub shading: &'static str,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct SceneUi {
    /// Active workspace name ("Layout", "Shading", …); empty when unknown.
    pub workspace: String,
    pub view: Option<SceneView>,
}

impl SceneView {
    /// Yaw / pitch of a view whose back axis (`m[2]`, Blender layout) is `z`.
    pub fn angles(z: [f32; 3]) -> (f32, f32) {
        let len = (z[0] * z[0] + z[1] * z[1] + z[2] * z[2]).sqrt().max(1e-9);
        let yaw = (-z[0]).atan2(-z[1]).to_degrees().rem_euclid(360.0);
        let pitch = (z[2] / len).clamp(-1.0, 1.0).asin().to_degrees();
        (yaw, pitch)
    }
}

/// Reduce the reader's UI state; `objects` resolves `Scene.camera`.
pub(super) fn ui_from_blend(ui: &BlendUiState, objects: &[BlendSceneObject]) -> SceneUi {
    let view = ui.view3d.as_ref().map(|v| {
        let cam = objects.iter().find(|o| ui.camera != 0 && o.block_address == ui.camera);
        let camera_view = v.persp == RV3D_CAMOB && cam.is_some();
        let lens = if v.lens > 0.0 { v.lens } else { 50.0 };
        let mut fov = 72.0 / lens;
        let (z, mut perspective, mut width) = (v.view_inv[2], v.persp != RV3D_ORTHO, v.dist * fov);
        let mut pivot = [-v.ofs[0], -v.ofs[1], -v.ofs[2]];
        let z = match (camera_view, cam) {
            (true, Some(c)) => {
                // Looking through the camera: its position is the eye and its
                // lens the field of view (frame fitted to the viewport width).
                let bz = c.matrix_world[2];
                let n = (bz[0] * bz[0] + bz[1] * bz[1] + bz[2] * bz[2]).sqrt().max(1e-9);
                let eye = c.matrix_world[3];
                if let crate::blend::BlendObjectData::Camera(d) = &c.data {
                    perspective = d.kind != 1;
                    fov = d.sensor_x.max(1e-3) / d.lens.max(1e-3);
                    width = if perspective { v.dist * fov } else { d.ortho_scale };
                }
                pivot = std::array::from_fn(|k| eye[k] - bz[k] / n * v.dist);
                bz
            }
            _ => z,
        };
        let (yaw_deg, pitch_deg) = SceneView::angles([z[0], z[1], z[2]]);
        SceneView {
            yaw_deg,
            pitch_deg,
            perspective,
            camera_view,
            pivot,
            width: width.max(1e-3),
            fov,
            shading: match v.shading { 2 => "wireframe", 3 => "solid", 4 => "material", 5 => "rendered", _ => "" },
        }
    });
    SceneUi { workspace: ui.workspace.clone(), view }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn front_view_looks_along_plus_y_level() {
        // Numpad 1: back axis −Y.
        let (yaw, pitch) = SceneView::angles([0.0, -1.0, 0.0]);
        assert!(yaw.abs() < 1e-3 && pitch.abs() < 1e-3, "{yaw} {pitch}");
    }

    #[test]
    fn top_view_pitches_straight_down() {
        let (_, pitch) = SceneView::angles([0.0, 0.0, 1.0]);
        assert!((pitch - 90.0).abs() < 1e-3);
    }

    #[test]
    fn right_view_yaws_a_quarter_turn() {
        // Numpad 3 looks along −X: back axis +X.
        let (yaw, _) = SceneView::angles([1.0, 0.0, 0.0]);
        assert!((yaw - 270.0).abs() < 1e-3, "{yaw}");
    }
}
