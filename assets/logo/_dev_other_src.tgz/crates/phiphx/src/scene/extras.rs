//! Non-mesh objects the viewport overlay draws: cameras, lights, empties.
//! Field names follow Blender's DNA (`Camera`, `Light`, `Object.empty_*`).

/// A camera object — Blender `Camera` DNA plus the owning object's transform.
#[derive(Clone, Debug, PartialEq)]
pub struct SceneCamera {
    pub name: String,
    /// Owning Object's location (kept for panels).
    pub location: [f32; 3],
    /// World matrix (Blender `m[col][row]` layout).
    pub matrix_world: [[f32; 4]; 4],
    /// `"PERSP"`, `"ORTHO"` or `"PANO"`.
    pub kind: String,
    /// Focal length in millimetres (`Camera.lens`).
    pub focal_length_mm: f32,
    pub sensor_width: f32,
    pub ortho_scale: f32,
    /// Near / far clip distances.
    pub clip_start: f32,
    pub clip_end: f32,
    /// Viewport display size (`Camera.drawsize`).
    pub display_size: f32,
}

/// A light object — Blender `Light` DNA plus the owning object's transform.
#[derive(Clone, Debug, PartialEq)]
pub struct SceneLight {
    pub name: String,
    pub location: [f32; 3],
    pub matrix_world: [[f32; 4]; 4],
    pub color: [f32; 3],
    /// Blender's `Light.energy`. Watts for POINT/SPOT/AREA, unitless for SUN.
    pub energy: f32,
    /// `"POINT"`, `"SUN"`, `"SPOT"`, `"AREA"`.
    pub kind: String,
    /// Spot cone angle in radians (`Light.spotsize`).
    pub spot_size: f32,
    /// Point / spot radius, or area edge length.
    pub size: f32,
}

/// An empty — Blender `Object.empty_drawtype` / `empty_drawsize`.
#[derive(Clone, Debug, PartialEq)]
pub struct SceneEmpty {
    pub name: String,
    pub matrix_world: [[f32; 4]; 4],
    /// `"PLAIN_AXES"`, `"ARROWS"`, `"SINGLE_ARROW"`, `"CIRCLE"`, `"CUBE"`,
    /// `"SPHERE"`, `"CONE"`, `"IMAGE"`.
    pub display_type: String,
    pub display_size: f32,
}
