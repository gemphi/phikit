//! One `BlendSceneObject` → renderable [`SceneObject`]: Blender-style
//! triangulation, bounds-safe indices, normals, UVs and material slots.

use super::geometry::{build_normals, per_vertex_uvs};
use super::SceneCorners;
use super::material::materials_from_blend;
use super::polyfill::triangulate;
use super::{SceneMesh, SceneObject};
use crate::blend::BlendSceneObject;

/// Convert one `BlendSceneObject`, drawing the modifier-evaluated mesh when
/// given; saved split normals describe the rest mesh, so an evaluated mesh
/// recomputes its normals.
pub(super) fn evaluated_object(src: &BlendSceneObject, eval: Option<&crate::blend::BlendEvalMesh>) -> SceneObject {
    let owned;
    let obj = match eval {
        Some(e) => {
            owned = BlendSceneObject {
                vertices: e.vertices.clone(),
                faces: e.faces.clone(),
                loop_uvs: e.loop_uvs.clone(),
                face_materials: e.face_materials.clone(),
                face_smooth: e.face_smooth.clone(),
                loop_normals: Vec::new(),
                ..src.clone()
            };
            &owned
        }
        None => src,
    };
    let vertices = obj.vertices.clone();
    let loop_normals: &[[f32; 3]] = &obj.loop_normals;
    let vert_count = vertices.len();
    let mut indices: Vec<u32> = Vec::new();
    let mut tri_loop_starts: Vec<usize> = Vec::new();
    let mut tri_loops: Vec<[usize; 3]> = Vec::new();
    let mut material_indices: Vec<u16> = Vec::new();
    let mut tri_smooth: Vec<bool> = Vec::new();
    let mut loop_base = 0usize;
    for (face_i, face) in obj.faces.iter().enumerate() {
        let len = face.len();
        if len < 3 {
            loop_base += len;
            continue;
        }
        let slot = obj.face_materials.get(face_i).copied().unwrap_or(0);
        let smooth = obj.face_smooth.get(face_i).copied().unwrap_or(false);
        // Skip faces referencing missing vertices outright.
        if face.iter().any(|&v| (v as usize) >= vert_count) {
            loop_base += len;
            continue;
        }
        let pts: Vec<[f32; 3]> = face.iter().map(|&v| vertices[v as usize]).collect();
        for [i, j, k] in triangulate(&pts) {
            let (a, b, c) = (face[i], face[j], face[k]);
            if (a as usize) >= vert_count
                || (b as usize) >= vert_count
                || (c as usize) >= vert_count
            {
                continue;
            }
            indices.push(a);
            indices.push(b);
            indices.push(c);
            tri_loop_starts.push(loop_base);
            tri_loops.push([loop_base + i, loop_base + j, loop_base + k]);
            material_indices.push(slot);
            tri_smooth.push(smooth);
        }
        loop_base += len;
    }
    // Only keep per-triangle slots when the mesh really is multi-material.
    if material_indices.iter().all(|&m| m == 0) {
        material_indices.clear();
    }
    let tri_count = indices.len() / 3;
    let normals = build_normals(
        &vertices,
        &indices,
        loop_normals,
        &tri_loop_starts,
        tri_count,
        &tri_smooth,
    );
    let corners = SceneCorners::build(&vertices, &indices, loop_normals, &tri_loops, &tri_smooth);
    let uvs = per_vertex_uvs(&obj.faces, &obj.loop_uvs, vert_count);
    let materials = materials_from_blend(obj);
    SceneObject {
        name: obj.name.clone(),
        mesh: SceneMesh {
            vertices,
            indices,
            normals,
            corners,
        }.into(),
        location: obj.location,
        scale: obj.scale,
        matrix_world: obj.matrix_world,
        materials,
        material_indices: material_indices.into(),
        uvs: uvs.into(),
    }
}

