//! `BCard` — Blender's `Panel` (`editors/interface/interface_panel.cc`,
//! `PanelType` in `blenkernel/BKE_screen.hh`): a heading strip and the
//! content under it, with the behaviours a panel can have declared as
//! traits rather than as separate view kinds.
//!
//! What maps to what:
//!
//! | Blender                                  | `BCard`                         |
//! |------------------------------------------|---------------------------------|
//! | `PanelType.label`, `.icon`               | `head.title`, `head.icon`       |
//! | `PanelType.draw_header`                  | `head.controls`                 |
//! | `PanelType.draw_header_preset`           | `head.preset`                   |
//! | `PanelType.draw`                         | `body`                          |
//! | `PNL_CLOSED`, `PANEL_TYPE_DEFAULT_CLOSED`| `fold` (the key holds open/closed) |
//! | `PANEL_TYPE_NO_HEADER`                   | `head: None`                    |
//! | `PanelType.parent` (a sub-panel)         | `BCardKind::Sub`                |
//! | `TH_PANEL_ACTIVE` outline (`active_property`) | `active`                   |
//! | the grip at the header's right (`ICON_GRIP`)   | drawn for `Panel` cards    |
//!
//! Blender's panels have no footer — actions sit in a footer *region*
//! (`RGN_TYPE_FOOTER`) — but dialogs built from cards need one, so `foot`
//! is the strip under the body, drawn only when it holds something.

use super::action::BAction;
use crate::v2::state::BPath;
use crate::v2::state::val::{V_FALSE, V_TRUE};
use crate::v2::view::BView;

/// Which kind of panel a card is — decides its backdrop and border the way
/// `panel_draw_aligned_backdrop` / `panel_draw_border` do.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BCardKind {
    /// A top-level panel: header backdrop (`TH_PANEL_HEADER`), body
    /// backdrop (`TH_PANEL_BACK`), outline (`TH_PANEL_OUTLINE`), a grip.
    Panel,
    /// A sub-panel: indented by 0.7 of a unit, its own backdrop
    /// (`TH_PANEL_SUB_BACK`), no outline, no grip.
    Sub,
    /// A card with no surface of its own — content grouped under a heading
    /// on whatever it sits on (a floating region's panel, `RGN_ALIGN_FLOAT`).
    Bare,
}

/// The heading strip — `PNL_HEADER` tall (1.25 units).
#[derive(Clone, Debug)]
pub struct BCardHead {
    pub title: String,
    pub icon: Option<String>,
    /// `draw_header`: controls before the title (a checkbox that enables the
    /// whole panel, as Motion Blur's does).
    pub controls: Vec<BView>,
    /// `draw_header_preset`: controls pushed to the right, before the grip.
    pub preset: Vec<BView>,
}

/// Open or closed, and the key that says which (`PNL_CLOSED`).
#[derive(Clone, Debug)]
pub struct BFold {
    pub key: BPath,
    pub open: bool,
}

impl BFold {
    /// What clicking the header does: write the other state explicitly, so
    /// a panel that is open because its key is absent closes on the first
    /// click rather than being "toggled" to open.
    pub fn flip(&self) -> BAction {
        BAction::Set(self.key.clone(), if self.open { V_FALSE } else { V_TRUE }.to_string())
    }
}

#[derive(Clone, Debug)]
pub struct BCard {
    pub kind: BCardKind,
    /// `None` is `PANEL_TYPE_NO_HEADER`: the body with no strip above it.
    pub head: Option<BCardHead>,
    pub body: Vec<BView>,
    pub foot: Vec<BView>,
    /// Collapsible when set. A closed card draws its header only.
    pub fold: Option<BFold>,
    /// The panel's data is the active one — its outline is lit.
    pub active: bool,
}

impl BCard {
    /// A top-level panel headed `title`.
    pub fn panel(title: impl Into<String>) -> Self {
        Self {
            kind: BCardKind::Panel,
            head: Some(BCardHead {
                title: title.into(),
                icon: None,
                controls: Vec::new(),
                preset: Vec::new(),
            }),
            body: Vec::new(),
            foot: Vec::new(),
            fold: None,
            active: false,
        }
    }

    /// A panel with no heading (`PANEL_TYPE_NO_HEADER`).
    pub fn headless() -> Self {
        Self { head: None, ..Self::panel("") }
    }

    pub fn sub(mut self) -> Self {
        self.kind = BCardKind::Sub;
        self
    }

    pub fn bare(mut self) -> Self {
        self.kind = BCardKind::Bare;
        self
    }

    pub fn icon(mut self, icon: impl Into<String>) -> Self {
        if let Some(head) = &mut self.head {
            head.icon = Some(icon.into());
        }
        self
    }

    pub fn controls(mut self, views: Vec<BView>) -> Self {
        if let Some(head) = &mut self.head {
            head.controls = views;
        }
        self
    }

    pub fn preset(mut self, views: Vec<BView>) -> Self {
        if let Some(head) = &mut self.head {
            head.preset = views;
        }
        self
    }

    pub fn body(mut self, views: Vec<BView>) -> Self {
        self.body = views;
        self
    }

    pub fn foot(mut self, views: Vec<BView>) -> Self {
        self.foot = views;
        self
    }

    /// Collapsible, open or closed as `key` says.
    pub fn fold(mut self, key: BPath, open: bool) -> Self {
        self.fold = Some(BFold { key, open });
        self
    }

    pub fn active(mut self, active: bool) -> Self {
        self.active = active;
        self
    }

    /// Whether the body is drawn: an unfoldable card always is.
    pub fn is_open(&self) -> bool {
        self.fold.as_ref().is_none_or(|f| f.open)
    }

    pub fn title(&self) -> Option<&str> {
        self.head.as_ref().map(|h| h.title.as_str())
    }
}

impl From<BCard> for BView {
    fn from(card: BCard) -> Self {
        BView::Card(Box::new(card))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::state::BKey as _;

    #[test]
    fn a_closed_card_flips_open_and_an_open_one_closed() {
        let key = crate::v2::state::ButsKey::Value("sampling").path();
        let open = BCard::panel("Sampling").fold(key.clone(), true);
        let BAction::Set(path, value) = open.fold.as_ref().unwrap().flip() else { panic!() };
        assert_eq!((path, value.as_str()), (key.clone(), V_FALSE));
        let closed = BCard::panel("Sampling").fold(key, false);
        assert!(!closed.is_open());
        let BAction::Set(_, value) = closed.fold.unwrap().flip() else { panic!() };
        assert_eq!(value, V_TRUE);
    }

    #[test]
    fn an_unfoldable_card_is_always_open() {
        assert!(BCard::panel("About").is_open());
        assert!(BCard::headless().head.is_none());
    }
}
