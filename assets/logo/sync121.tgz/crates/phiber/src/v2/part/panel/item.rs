//! `BPanelItem` — one Properties panel: a `BCard` headed by the section's
//! title, its body one prop row per `BPropSpec`, then its sub-panels.
//! Blender ref: a `bpy.types.Panel` in `properties_*.py` (and Cycles'
//! `addon/ui.py`), drawn by `interface_panel.cc`.
//!
//! What the declaration says, the card does: `DEFAULT_CLOSED` panels start
//! closed, `HIDE_HEADER` ones have no header and never fold, `draw_header`
//! properties sit in the header before the title, and sub-panels
//! (`bl_parent_id`) are `Sub` cards at the foot of their parent's body.

use super::prop_view::{header_ctrl, prop_row};
use super::set::BSectionSpec;
use crate::v2::host::{BHostType, host_slug};
use crate::v2::state::val::{V_FALSE, V_TRUE};
use crate::v2::state::{BPath, BState};
use crate::v2::view::prim::BCard;
use crate::v2::view::{BView, BViewItem};
use std::collections::HashMap;
use std::sync::Mutex;

#[derive(Clone, Copy, Debug)]
pub struct BPanelItem {
    pub host: BHostType,
    pub tab: &'static str,
    pub spec: BSectionSpec,
    pub expanded: bool,
}

impl BPanelItem {
    pub fn new(host: BHostType, tab: &'static str, spec: BSectionSpec, expanded: bool) -> Self {
        Self {
            host,
            tab,
            spec,
            expanded,
        }
    }

    /// State key for this section's expanded flag:
    /// `ctx.<host>.<tab>.<section>.expanded`. Including the active tab avoids
    /// collisions between common section names such as Surface and Preview.
    /// A sub-panel's `title` is its path from the top panel
    /// (`"Sampling Render Denoise"`), so the two Denoise panels differ.
    pub fn expand_key(host: BHostType, tab: &str, title: &str) -> BPath {
        BPath::owned(vec![host_slug(host), slug(tab), slug(title), "expanded"])
    }

    /// Whether a panel is open: what the user last chose, or — until they
    /// choose — Blender's default for it (`DEFAULT_CLOSED` or not).
    pub fn is_open(s: &BState, key: &BPath, closed_by_default: bool) -> bool {
        match s.get(key) {
            Some(V_FALSE) => false,
            Some(V_TRUE) => true,
            _ => !closed_by_default,
        }
    }

    fn card(&self, spec: &BSectionSpec, path: &str, open: bool, s: &BState) -> BCard {
        let mut body: Vec<BView> = Vec::new();
        if open || spec.headless {
            body.extend(spec.props.iter().map(|p| prop_row(p, s)));
            for child in spec.children {
                let child_path = format!("{path} {}", child.title);
                let key = Self::expand_key(self.host, self.tab, &child_path);
                let child_open = Self::is_open(s, &key, child.closed);
                body.push(self.card(child, &child_path, child_open, s).sub().into());
            }
        }
        if spec.headless {
            return BCard::headless().body(body);
        }
        let key = Self::expand_key(self.host, self.tab, path);
        BCard::panel(spec.title)
            .fold(key, open)
            .controls(spec.header.iter().map(|p| header_ctrl(p, s)).collect())
            .body(body)
    }
}

/// A title or tab as a lowercase path segment, interned: the same name always
/// yields the same `&'static str`, and each distinct name is allocated once.
/// (Leaking a fresh string on every build grew memory every frame.)
fn slug(title: &str) -> &'static str {
    static POOL: Mutex<Option<HashMap<String, &'static str>>> = Mutex::new(None);
    let mut guard = POOL.lock().unwrap_or_else(|e| e.into_inner());
    let pool = guard.get_or_insert_with(HashMap::new);
    if let Some(&interned) = pool.get(title) {
        return interned;
    }
    let made: &'static str = Box::leak(title.to_ascii_lowercase().replace(' ', "_").into_boxed_str());
    pool.insert(title.to_string(), made);
    made
}

impl BViewItem for BPanelItem {
    fn build(&self, s: &BState) -> BView {
        self.card(&self.spec, self.spec.title, self.expanded, s).into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::part::panel::prop::BPropSpec;
    use crate::v2::part::panel::set::sec;

    static EMPTY: &[BPropSpec] = &[];

    #[test]
    fn initially_expanded_header_first_click_sets_false() {
        use crate::v2::state::val::V_FALSE;
        use crate::v2::view::prim::BAction;
        let spec = sec("Surface", EMPTY);
        let BView::Card(card) = BPanelItem::new(BHostType::Buts, "Material", spec, true).build(&BState::new())
        else {
            panic!()
        };
        let BAction::Set(_, value) = card.fold.as_ref().unwrap().flip() else { panic!() };
        assert_eq!(value, V_FALSE);
        assert_eq!(card.title(), Some("Surface"));
    }
}
