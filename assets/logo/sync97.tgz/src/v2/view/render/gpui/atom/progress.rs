//! Progress-bar atom — a determinate bar with a leading status label.
//!
//! Blender's file-read job paints a thin progress bar in the status bar with
//! a short label; this atom mirrors that. It resolves all geometry and colour
//! from the render-pass style (no design literals): the track uses the recessed
//! panel tone, the fill uses the accent, and the label uses the dim text tone.

use super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::host::BHostType;
use crate::v2::theme::BStyleRole;
use gpui::prelude::*;
use gpui::{AnyElement, SharedString, div, px};

/// Render a `[====      ] label` progress row. `fraction` is clamped to
/// `0.0..=1.0`. The bar is a fixed-width track whose accent fill grows with
/// `fraction`; `relative(fraction)` lets the fill track the resolved track
/// width without a hardcoded pixel span.
///
/// In the **status bar** the bar comes first and the stage label sits in a
/// fixed-width box after it. A stage label changes on every tick — "Reading
/// file", then "Reading objects 431/2104 Cube.003" — so a label that sized
/// itself dragged the bar sideways with every object read. There the bar
/// holds one position for the whole load and only the text inside the box
/// changes.
///
/// Anywhere else — the Opening-File modal — the row has a width of its own to
/// fill, so the bar spans it and the label sits on its own line beneath,
/// also full width. Nothing is boxed to a borrowed dimension there, and the
/// label still ellipsises rather than reflowing the card as the stage changes.
pub fn view(fraction: f32, label: &str, c: &BRenderCtx) -> AnyElement {
    let frac = fraction.clamp(0.0, 1.0);
    let in_statusbar = c.host == BHostType::Statusbar;
    let bar_width = c.style.dimensions.channels_width; // reuse a resolved medium width
    let bar_height = c.style.typography.body;
    let radius = px(c.style.radius_for(BStyleRole::Button));

    let track_id = if in_statusbar {
        "statusbar-progress-track"
    } else {
        "modal-progress-track"
    };
    let mut track = div()
        .id(track_id)
        .debug_selector(move || track_id.to_string())
        .h(px(bar_height))
        .rounded(radius)
        .overflow_hidden()
        .bg(to_hsla(c.style.colors.bg_panel))
        .child(
            div()
                .h_full()
                .w(gpui::relative(frac))
                .bg(to_hsla(c.style.colors.accent)),
        );
    track = if in_statusbar {
        track.flex_shrink_0().w(px(bar_width))
    } else {
        track.w_full()
    };

    let mut stage = div()
        .overflow_hidden()
        .whitespace_nowrap()
        .text_ellipsis()
        .child(SharedString::from(label.to_string()));
    stage = if in_statusbar {
        stage.w(px(c.style.dimensions.panel_width)).flex_shrink_0()
    } else {
        stage.w_full().min_w_0()
    };

    let wrap = div()
        .text_color(to_hsla(c.style.colors.text_dim))
        .text_size(px(c.style.typography.body))
        .gap(px(c.style.spacing.gap_sm))
        .flex();
    if in_statusbar {
        wrap.flex_row()
            .items_center()
            .flex_shrink_0()
            .child(track)
            .child(stage)
            .into_any_element()
    } else {
        wrap.flex_col()
            .items_stretch()
            .w_full()
            .min_w_0()
            .child(track)
            .child(stage)
            .into_any_element()
    }
}
