//! Modal set — one `BModalSpec` per `BModalType`.

use super::{BModalSpec, BModalType};

// Order MUST match `BModalType` variant order.
pub static SET: &[BModalSpec] = &[
    BModalSpec {
        kind: BModalType::Settings,
        label: "Preferences",
        icon: "settings",
        width: 960.0,
        height: 640.0,
    },
    BModalSpec {
        kind: BModalType::Help,
        label: "Help",
        icon: "help",
        width: 900.0,
        height: 640.0,
    },
    BModalSpec {
        kind: BModalType::Profile,
        label: "Profile",
        icon: "profile",
        width: 480.0,
        height: 520.0,
    },
    BModalSpec {
        kind: BModalType::Command,
        label: "Command Palette",
        icon: "command",
        width: 640.0,
        height: 420.0,
    },
    BModalSpec {
        kind: BModalType::Splash,
        label: "Welcome to Phiber",
        icon: "phiber",
        width: 880.0,
        height: 560.0,
    },
    BModalSpec {
        kind: BModalType::About,
        label: "About Phiber",
        icon: "about",
        width: 640.0,
        height: 480.0,
    },
    BModalSpec {
        kind: BModalType::FileBrowser,
        label: "Phiber File View",
        icon: "folder",
        width: 1024.0,
        height: 640.0,
    },
    // Blender titles this window "Blender Render".
    BModalSpec {
        kind: BModalType::Render,
        label: "Phiber Render",
        icon: "render",
        width: 1100.0,
        height: 720.0,
    },
    BModalSpec {
        kind: BModalType::Spaces,
        label: "Spaces",
        icon: "grid",
        width: 560.0,
        height: 420.0,
    },
    BModalSpec {
        kind: BModalType::Collab,
        label: "Collaboration",
        icon: "chat",
        width: 640.0,
        height: 520.0,
    },
    BModalSpec {
        kind: BModalType::Progress,
        label: "Opening File",
        icon: "folder_open",
        // Twice the old 420: the bar and its stage label both run the full
        // card width now, and a stage line ("Reading objects 431/2104
        // Cube.003") needs the room before it ellipsises.
        width: 840.0,
        height: 200.0,
    },
];
