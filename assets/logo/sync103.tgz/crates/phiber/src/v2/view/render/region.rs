//! Region-level layout: `BRegionType` decodes into orientation and placement.
//! Its size, padding and surface are `BFlex` decisions (`gpui/region.rs`).
//!
//! Blender ref: `ARegion` alignment flags (`RGN_ALIGN_TOP` / `BOTTOM` /
//! `LEFT` / `RIGHT`) plus header/footer heights.

use super::{BAxis, BPlacement, BRegionLayout};
use crate::v2::region::BRegionType;

impl BRegionLayout for BRegionType {
    fn axis(&self) -> BAxis {
        match self {
            // NavBar / Tools are vertical strips — icons stack top-to-bottom.
            BRegionType::NavBar | BRegionType::Tools => BAxis::Column,
            // Center / Flex regions must not force items_center so that a
            // Canvas child can fill the full height of the region.
            _ => BAxis::Row,
        }
    }

    fn placement(&self) -> BPlacement {
        match self {
            BRegionType::Header
            | BRegionType::ToolHeader
            | BRegionType::HUD
            | BRegionType::Scrubbing => BPlacement::Top,
            // The shelf header is the strip along the shelf's top edge, so it
            // sits at the foot of the host with the shelf beneath it — not as
            // a second band at the top, which is where it had drifted.
            BRegionType::AssetShelfHeader
            | BRegionType::Footer
            | BRegionType::Execute
            | BRegionType::AssetShelf => BPlacement::Bottom,
            BRegionType::Tools | BRegionType::NavBar => BPlacement::Left,
            BRegionType::UI | BRegionType::ToolProps | BRegionType::Channels => BPlacement::Right,
            _ => BPlacement::Flex,
        }
    }
}
