//! Focused centered body layout for the viewport-filling Phiber Welcome form.

use super::super::flex::BFlexed;
use super::super::{ctx::BRenderCtx, walk};
use super::BModalPart;
use crate::v2::modal::BModalType;
use crate::v2::view::BView;
use gpui::prelude::*;
use gpui::AnyElement;

pub struct BWelcome<'a>(pub &'a BView);

impl BWelcome<'_> {
    fn action_columns(&self, view: &BView, c: &BRenderCtx) -> AnyElement {
        let BView::Row { children } = view else {
            return walk(view, c);
        };
        let mut row = BModalPart::WelcomeRow.flex(c).div(c);
        for child in children {
            row = row.child(BModalPart::WelcomeCell.flex(c).div(c).child(walk(child, c)));
        }
        row.into_any_element()
    }

    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let children = match self.0 {
            BView::Column { children } => children.as_slice(),
            _ => std::slice::from_ref(self.0),
        };
        let mut column = BModalPart::WelcomeColumn {
            max_width: BModalType::Splash.spec().width,
        }
        .flex(c)
        .div(c)
        .id("welcome-content-column")
        .debug_selector(|| "welcome-content-column".to_string());
        for (index, child) in children.iter().enumerate() {
            let rendered = if index == 2 {
                self.action_columns(child, c)
            } else {
                walk(child, c)
            };
            column = column.child(rendered);
        }
        BModalPart::WelcomeLayout
            .flex(c)
            .div(c)
            .id("welcome-centered-layout")
            .debug_selector(|| "welcome-centered-layout".to_string())
            .child(column)
            .into_any_element()
    }
}
