//! Viewport-filling Splash/Welcome and About modal form.

use super::super::flex::BFlexed;
use super::super::{ctx::BRenderCtx, walk};
use super::{BModalPart, title::BTitle, welcome::BWelcome};
use crate::v2::modal::BModalType;
use crate::v2::view::BView;
use gpui::prelude::*;
use gpui::AnyElement;

pub struct BFullscreen<'a> {
    pub kind: BModalType,
    pub body: &'a BView,
}

impl BFullscreen<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let maximized = super::is_maximized(c);
        BModalPart::Fullscreen
            .flex(c)
            .div(c)
            .child(
                BTitle {
                    kind: self.kind,
                    maximized,
                    rounded: false,
                }
                .render(c),
            )
            .child(if self.kind == BModalType::Splash {
                BWelcome(self.body).render(c)
            } else {
                BModalPart::FullscreenBody
                    .flex(c)
                    .div(c)
                    .child(walk(self.body, c))
                    .into_any_element()
            })
            .into_any_element()
    }
}

use super::super::prim::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BFullscreen<'_> {
    fn render(&self, c: &super::super::ctx::BRenderCtx) -> gpui::AnyElement {
        BFullscreen::render(self, c)
    }
}
