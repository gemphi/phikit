//! Region walker — orientation + fixed size from resolved UI style. Painted
//! header/strip regions receive explicit host-corner ownership; ordinary
//! layout regions are transparent so their pane or specialized content owns
//! the visible surface.

use super::flex::{
    BAlign, BDim, BFill, BFlex, BFlexed, BJustify, BLen, BPlace, BRadius, BSpace,
};
use super::{
    ctx::BRenderCtx,
    surface::{BChildCornerSupport, BSurfaceOpacity, child_surface_plan, compatible_inner_radius},
    walk,
};
use crate::v2::host::BHostType;
use crate::v2::part::strip;
use crate::v2::region::BRegionType;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::render::{BAxis, BPlacement, BRegionLayout};
use gpui::prelude::*;
use gpui::AnyElement;

pub(super) const fn surface_opacity(kind: BRegionType, host: BHostType) -> BSurfaceOpacity {
    match kind {
        BRegionType::Header | BRegionType::ToolHeader if !matches!(host, BHostType::Topbar) => {
            BSurfaceOpacity::Opaque
        }
        BRegionType::NavBar
        | BRegionType::Channels
        | BRegionType::Scrubbing
        | BRegionType::AssetShelfHeader => BSurfaceOpacity::Opaque,
        // A content region paints nothing of its own, but in a content-fill
        // host it holds the canvas — and the canvas is opaque and reaches the
        // host's corners. Corner ownership has to follow what actually paints
        // there, not what the region's own background is: reading the region
        // as transparent handed the canvas no corners at all, so it squared
        // off the zone it sits in however carefully the canvas rounded itself.
        BRegionType::Center if host.fills_content() => BSurfaceOpacity::Opaque,
        _ => BSurfaceOpacity::Transparent,
    }
}

fn region_fill(kind: BRegionType) -> BFill {
    match kind {
        // All vertical icon rails (Properties navbar, activity bar, other
        // navbars) are transparent. Only hovered/active items carry paint so
        // the strip reads as part of the enclosing host area, not a separate
        // chrome piece.
        BRegionType::NavBar => BFill::Clear,
        BRegionType::Channels | BRegionType::Scrubbing | BRegionType::AssetShelfHeader => {
            BFill::HostStrip
        }
        BRegionType::Header | BRegionType::ToolHeader => BFill::HostHeader,
        _ => BFill::Clear,
    }
}

/// True when a region's content is a vertical rail. Rails are laid out the
/// same way wherever they appear — the Activity bar, the tool strip, the
/// Properties navbar and the editor side rail are one element, not four.
fn rail_region(kind: BRegionType, host: BHostType) -> bool {
    matches!(kind, BRegionType::NavBar | BRegionType::Tools)
        || (kind == BRegionType::Center && host == BHostType::Activity)
}

/// A region as drawn. Its layout follows from its kind, the host it sits in
/// (`c.host`), whether its rail is expanded, and which of the host's corners
/// it owns (`c.corners`).
struct BRegionFrame {
    kind: BRegionType,
}

impl BFlexed for BRegionFrame {
    fn flex(&self, c: &BRenderCtx) -> BFlex {
        let kind = self.kind;
        let axis = kind.axis();
        let flex = match (axis, kind.placement()) {
            // Header rows: the three panes sit at the start, the centre and
            // the end. `Between` states that directly rather than relying on
            // the Center pane's growth to push the other two apart — a host
            // with nothing in its middle paints no Center pane at all, which
            // left its right-hand controls stranded mid-row.
            (BAxis::Row, BPlacement::Top | BPlacement::Bottom) => {
                BFlex::row().align(BAlign::Center).justify(BJustify::Between)
            }
            (BAxis::Row, _) => BFlex::row(),
            (BAxis::Column, _) => BFlex::column().align(BAlign::Stretch),
        }
        .fill(region_fill(kind))
        .gap(BSpace::GapXs);

        // Every vertical strip is the topbar turned on its side, so every rail
        // is flush horizontally — the cap owns the gap on its outer edge and
        // runs into the pane on the other (`atom::tab::cap`). Its vertical
        // padding matches the content region beside it, so the first icon
        // sits level with the first accordion header. Header strips stay
        // vertically centred in their fixed height.
        let flex = if rail_region(kind, c.host) {
            flex.pad_top(BSpace::RailLead)
                .pad_bottom(BSpace::PadSm)
                .gap(BSpace::None)
        } else if matches!(kind, BRegionType::Header | BRegionType::ToolHeader) {
            flex.pad_x(BSpace::PadMd)
        } else if c.host == BHostType::Buts && kind == BRegionType::Center {
            // Properties content: a small top/bottom pad so the first and last
            // accordion don't touch the edges, and a right gutter so the last
            // property row doesn't butt against the border.
            flex.pad_y(BSpace::PadSm).pad_right(BSpace::PadSm)
        } else if kind == BRegionType::Center && c.host.fills_content() {
            // Content-fill hosts (3D viewport, node graphs, image / UV / seq /
            // clip, timelines) paint wall to wall: the viewport's clear and the
            // graph's grid must reach every edge. Their overlays are absolute,
            // so they need no padded parent.
            flex
        } else {
            flex.pad(BSpace::PadMd)
        };

        let expanded = |key| strip::is_expanded(c.s, c.host, key);
        let fixed = match kind {
            BRegionType::Header | BRegionType::ToolHeader | BRegionType::AssetShelfHeader => {
                Some(BDim::HeaderHeight)
            }
            BRegionType::Footer | BRegionType::Execute => Some(BDim::FooterHeight),
            BRegionType::Scrubbing => Some(BDim::ScrubbingHeight),
            BRegionType::AssetShelf => Some(BDim::AssetShelfHeight),
            // The tool rail and every navbar share the strip-expand keys:
            // widened to show labels when expanded (Blender's toolbar
            // flyout), a rail wide when collapsed.
            BRegionType::Tools if expanded("tool") => Some(BDim::SidebarMinWidth),
            BRegionType::Tools => Some(BDim::ToolbarWidth),
            BRegionType::NavBar if expanded("navbar") => Some(BDim::SidebarMinWidth),
            BRegionType::NavBar => Some(BDim::NavbarWidth),
            BRegionType::UI => Some(BDim::PanelWidth),
            BRegionType::Channels => Some(BDim::ChannelsWidth),
            BRegionType::ToolProps => Some(BDim::ToolPropsWidth),
            _ => None,
        };
        let flex = match (fixed, axis) {
            (Some(dim), BAxis::Row) => flex.height(BLen::Dim(dim)).width(BLen::Full),
            (Some(dim), BAxis::Column)
                if matches!(kind, BRegionType::NavBar | BRegionType::Tools) =>
            {
                flex.width(BLen::Dim(dim))
                    .keeps_size()
                    .height(BLen::Full)
                    .min_height(BLen::Zero)
            }
            (Some(dim), BAxis::Column) => flex
                .min_width(BLen::Dim(dim))
                .width(BLen::Full)
                .height(BLen::Full)
                .min_height(BLen::Zero),
            (None, _) => {
                let flex = flex.fills().min_height(BLen::Zero).full();
                // A floating-side-panel host's centre is the anchor its
                // absolute toolbar and sidebar position against; without it
                // they fell through to the window root.
                if kind == BRegionType::Center && c.host.floats_side_panels() {
                    flex.place(BPlace::Anchor)
                } else {
                    flex
                }
            }
        };

        let area_inner_radius =
            compatible_inner_radius(c.style.radius_for(BStyleRole::Area), c.style.strokes.border);
        let host_radius = c.style.radius_for(BStyleRole::Host).min(area_inner_radius);
        let plan = child_surface_plan(
            c.corners,
            surface_opacity(kind, c.host),
            BChildCornerSupport::Propagated,
            host_radius,
            0.0,
        );
        if plan.corners.any() {
            flex.radius(BRadius::Corners {
                tl: plan.corners.tl,
                tr: plan.corners.tr,
                bl: plan.corners.bl,
                br: plan.corners.br,
                radius: c.style.radius_for(BStyleRole::Region).min(plan.radius),
            })
        } else {
            flex
        }
    }
}

pub fn view(kind: BRegionType, children: &[BView], c: &BRenderCtx) -> AnyElement {
    let el = BRegionFrame { kind }.flex(c).div(c);

    let dbg = format!("region-{:?}-{:?}", kind, c.host);
    let mut el = el
        .id(gpui::SharedString::from(dbg.clone()))
        .debug_selector(move || dbg.clone());
    // Tag the context with this region kind so pane children can distinguish
    // a header pane (content hugs, Left/Center/Right tri-cell) from a
    // content-region Center pane (stretches to fill).
    let child_ctx = c.with_region(kind);
    // The canvas fills the region, so a floating rail or sidebar has to be
    // painted after it — otherwise the viewport covers its own chrome.
    // Paint order, and only for the region whose panes actually float: the
    // canvas fills the Center region, so a floating rail has to be painted
    // after it. A header's side panes are ordinary strip content
    // (`pane::is_floating_pane`).
    let floats = c.host.floats_side_panels() && kind == BRegionType::Center;
    let floating = |ch: &BView| {
        floats
            && matches!(ch, BView::Pane { kind, .. } if matches!(kind, crate::v2::pane::BPaneType::Left | crate::v2::pane::BPaneType::Right))
    };
    let ordered: Vec<&BView> = children
        .iter()
        .filter(|ch| !floating(ch))
        .chain(children.iter().filter(|ch| floating(ch)))
        .collect();
    for ch in ordered {
        el = el.child(walk(ch, &child_ctx));
    }
    el.into_any_element()
}

#[cfg(test)]
mod tests;
