//! `BFlex` itself: the record of one container's layout decisions, and the
//! builder the levels describe themselves with.

use super::token::{
    BAlign, BBasis, BEdge, BFill, BJustify, BLen, BOverflow, BPlace, BRadius, BSpace, BType,
};
// (`BEdge`, `BFill`, `BRadius`, `BType` are the record's field types; their
// builder methods live in `surface.rs`.)
use crate::v2::view::render::BAxis;

/// The complete description of one container. Fields left `None` are not
/// decided here and fall to the defaults.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BFlex {
    pub axis: Option<BAxis>,
    pub grow: Option<f32>,
    pub shrink: Option<f32>,
    pub basis: Option<BBasis>,
    pub width: Option<BLen>,
    pub height: Option<BLen>,
    pub min_width: Option<BLen>,
    pub min_height: Option<BLen>,
    pub max_width: Option<BLen>,
    pub align: Option<BAlign>,
    pub justify: Option<BJustify>,
    pub gap: Option<BSpace>,
    pub pad_top: Option<BSpace>,
    pub pad_right: Option<BSpace>,
    pub pad_bottom: Option<BSpace>,
    pub pad_left: Option<BSpace>,
    pub margin_left: Option<BSpace>,
    /// Drawn higher than where its parent's alignment puts it, by this much
    /// of its own margin (a centred item moves by half of it).
    pub raised_by: Option<BSpace>,
    pub fill: Option<BFill>,
    pub border: Option<BEdge>,
    pub radius: Option<BRadius>,
    /// Lifted off the surface beneath: the theme's surface shadow, if any.
    pub lifted: bool,
    pub ink: bool,
    pub type_size: Option<BType>,
    pub place: BPlace,
    pub overflow: BOverflow,
    /// Swallows pointer events so what lies beneath does not see them.
    pub occludes: bool,
}

impl BFlex {
    /// A flex container laid out along `axis`, deciding nothing else yet.
    pub const fn along(axis: BAxis) -> Self {
        Self {
            axis: Some(axis),
            ..Self::NOTHING
        }
    }

    /// A row.
    pub const fn row() -> Self {
        Self::along(BAxis::Row)
    }

    /// A column.
    pub const fn column() -> Self {
        Self::along(BAxis::Column)
    }

    /// A plain box: no flex container of its own, only its own size and place.
    pub const fn cell() -> Self {
        Self::NOTHING
    }

    const NOTHING: Self = Self {
        axis: None,
        grow: None,
        shrink: None,
        basis: None,
        width: None,
        height: None,
        min_width: None,
        min_height: None,
        max_width: None,
        align: None,
        justify: None,
        gap: None,
        pad_top: None,
        pad_right: None,
        pad_bottom: None,
        pad_left: None,
        margin_left: None,
        raised_by: None,
        fill: None,
        border: None,
        radius: None,
        lifted: false,
        ink: false,
        type_size: None,
        place: BPlace::Flow,
        overflow: BOverflow::Visible,
        occludes: false,
    };

    // ── How it takes space in its parent ────────────────────────────────

    /// Takes the free space along its parent's axis, and may shrink below its
    /// content (`flex_1`).
    pub const fn fills(self) -> Self {
        self.shares(1.0)
    }

    /// Takes `fraction` of the free space along its parent's axis.
    pub const fn shares(mut self, fraction: f32) -> Self {
        self.grow = Some(fraction);
        self.shrink = Some(1.0);
        self.basis = Some(BBasis::NoShare);
        self
    }

    /// One of a set of equal cells that divide the row by grow alone.
    pub const fn equal_cell(mut self) -> Self {
        self.grow = Some(1.0);
        self.basis = Some(BBasis::NoPixels);
        self
    }

    /// Keeps its size: never shrinks below it.
    pub const fn keeps_size(mut self) -> Self {
        self.shrink = Some(0.0);
        self
    }

    /// May shrink below its share.
    pub const fn yields(mut self) -> Self {
        self.shrink = Some(1.0);
        self
    }

    pub const fn width(mut self, len: BLen) -> Self {
        self.width = Some(len);
        self
    }

    pub const fn height(mut self, len: BLen) -> Self {
        self.height = Some(len);
        self
    }

    /// The whole of the parent on both axes.
    pub const fn full(self) -> Self {
        self.width(BLen::Full).height(BLen::Full)
    }

    pub const fn min_width(mut self, len: BLen) -> Self {
        self.min_width = Some(len);
        self
    }

    pub const fn min_height(mut self, len: BLen) -> Self {
        self.min_height = Some(len);
        self
    }

    pub const fn max_width(mut self, len: BLen) -> Self {
        self.max_width = Some(len);
        self
    }

    /// May shrink below its content on both axes.
    pub const fn unclamped(self) -> Self {
        self.min_width(BLen::Zero).min_height(BLen::Zero)
    }

    // ── How it arranges its children ────────────────────────────────────

    pub const fn align(mut self, align: BAlign) -> Self {
        self.align = Some(align);
        self
    }

    pub const fn justify(mut self, justify: BJustify) -> Self {
        self.justify = Some(justify);
        self
    }

    pub const fn gap(mut self, space: BSpace) -> Self {
        self.gap = Some(space);
        self
    }

    pub const fn pad(self, space: BSpace) -> Self {
        self.pad_x(space).pad_y(space)
    }

    pub const fn pad_x(mut self, space: BSpace) -> Self {
        self.pad_left = Some(space);
        self.pad_right = Some(space);
        self
    }

    pub const fn pad_y(mut self, space: BSpace) -> Self {
        self.pad_top = Some(space);
        self.pad_bottom = Some(space);
        self
    }

    pub const fn pad_top(mut self, space: BSpace) -> Self {
        self.pad_top = Some(space);
        self
    }

    pub const fn pad_right(mut self, space: BSpace) -> Self {
        self.pad_right = Some(space);
        self
    }

    pub const fn pad_bottom(mut self, space: BSpace) -> Self {
        self.pad_bottom = Some(space);
        self
    }

    pub const fn margin_left(mut self, space: BSpace) -> Self {
        self.margin_left = Some(space);
        self
    }

    pub const fn raised_by(mut self, space: BSpace) -> Self {
        self.raised_by = Some(space);
        self
    }
}
