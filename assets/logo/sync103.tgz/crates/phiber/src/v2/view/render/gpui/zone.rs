//! Zone layout and focused area-boundary seam composition.

mod seam;

use super::flex::{BDim, BFill, BFlex, BFlexed, BLen, BRadius, BSpace};
use super::{ctx::BRenderCtx, walk};
use crate::v2::space::BSpaceType;
use crate::v2::state::{area_fraction, key::K_SPACE};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::render::{BAxis, BZoneLayout};
use crate::v2::zone::BZoneType;
use gpui::prelude::*;
use gpui::{AnyElement, Bounds, Pixels};
pub use seam::AreaDrag;
use seam::BSeam;
use std::sync::{Arc, Mutex};

/// A zone as drawn: its kind, and the two facts that change how much room it
/// takes — a width the user dragged, and whether all it holds is a fixed strip.
struct BZoneFrame {
    kind: BZoneType,
    dragged: Option<f32>,
    fixed_strip: bool,
}

impl BFlexed for BZoneFrame {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        use BZoneType::*;
        let base = BFlex::along(self.kind.axis())
            .fill(BFill::Clear)
            .radius(BRadius::Role(BStyleRole::Zone))
            .gap(BSpace::Seam);
        let sized = match self.kind {
            Top => base.height(BLen::Dim(BDim::HeaderHeight)).width(BLen::Full),
            Bottom => base.height(BLen::Dim(BDim::BottomStripHeight)).width(BLen::Full),
            Center | Full => base.fills().height(BLen::Full).min_height(BLen::Zero),
            Left | Right => base.height(BLen::Full).min_height(BLen::Zero),
        };
        match (self.dragged, self.kind) {
            (Some(size), Left | Right) => sized.width(BLen::Measured(size)).keeps_size(),
            (Some(size), Bottom) => sized.height(BLen::Measured(size)).keeps_size(),
            (Some(_), _) => sized,
            // A zone whose only content is a fixed-width strip hugs it. Giving
            // it the side-column default left a wide empty band beside the
            // Activity rail, which is not a column anyone can put anything in.
            (None, _) if self.fixed_strip => sized.keeps_size(),
            // No dragged width: pin a side column to a default instead of
            // letting it size to content. Content-sizing let a greedy host
            // (File Browser, Image editor) expand to fill the window and
            // starve the Center zone; a default keeps Center's share intact
            // and matches Blender's saved editor column widths.
            (None, Left | Right) => sized.width(BLen::Dim(BDim::SideZoneDefaultWidth)).keeps_size(),
            (None, _) => sized,
        }
    }
}

/// One area's slot in a zone: its share of the zone's length.
struct BZoneSlot {
    share: f32,
}

impl BFlexed for BZoneSlot {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        BFlex::column().unclamped().shares(self.share)
    }
}

/// True when every area in this zone hosts a fixed-width strip, so the zone
/// has no width of its own to give away and no boundary to drag.
pub(super) fn fixed_strip_zone(children: &[BView]) -> bool {
    let mut any = false;
    for child in children.iter().filter(|child| !child.is_empty()) {
        any = true;
        let BView::Area { child, .. } = child else {
            return false;
        };
        let BView::Host { kind, .. } = child.as_ref() else {
            return false;
        };
        if !kind.is_fixed_strip() {
            return false;
        }
    }
    any
}

pub fn view(kind: BZoneType, children: &[BView], c: &BRenderCtx) -> AnyElement {
    let vertical = matches!(kind.axis(), BAxis::Row);
    let space =
        c.s.get(&K_SPACE)
            .and_then(BSpaceType::from_slug)
            .unwrap_or(BSpaceType::Layout);
    let frame = BZoneFrame {
        kind,
        dragged: crate::v2::state::zone_size(c.s, space, kind),
        fixed_strip: fixed_strip_zone(children),
    };
    let mut element = frame.flex(c).div(c);
    // The top zone is the window's title bar (the native one is hidden):
    // empty space in it drags the window.
    if kind == BZoneType::Top {
        element = element.window_control_area(gpui::WindowControlArea::Drag);
    }

    let child_count = children.iter().filter(|child| !child.is_empty()).count();

    let zone_extent: Arc<Mutex<Option<f32>>> = Arc::new(Mutex::new(None));
    if child_count > 1 {
        let extent = zone_extent.clone();
        element =
            element.on_children_prepainted(move |bounds: Vec<Bounds<Pixels>>, _window, _app| {
                if bounds.is_empty() {
                    return;
                }
                let mut start = f32::INFINITY;
                let mut end = f32::NEG_INFINITY;
                for bound in &bounds {
                    let (low, high) = if vertical {
                        (
                            f32::from(bound.origin.x),
                            f32::from(bound.origin.x + bound.size.width),
                        )
                    } else {
                        (
                            f32::from(bound.origin.y),
                            f32::from(bound.origin.y + bound.size.height),
                        )
                    };
                    start = start.min(low);
                    end = end.max(high);
                }
                if end - start > 1.0 {
                    *extent.lock().unwrap() = Some(end - start);
                }
            });
    }

    let mut area_index = 0usize;
    for child in children {
        if child.is_empty() {
            continue;
        }
        let fraction = area_fraction(c.s, space, kind, area_index);
        let selector = format!("slot-{}-{area_index}", kind.slug());
        let mut slot = BZoneSlot { share: fraction }
            .flex(c)
            .div(c)
            .id(gpui::SharedString::from(selector.clone()))
            .debug_selector(move || selector.clone())
            .child(walk(child, c));
        if area_index > 0 && child_count > 1 {
            slot = slot.child(
                BSeam {
                    kind,
                    index: area_index - 1,
                    space,
                    extent: zone_extent.clone(),
                }
                .render(c),
            );
        }
        element = element.child(slot);
        area_index += 1;
    }
    element.into_any_element()
}
