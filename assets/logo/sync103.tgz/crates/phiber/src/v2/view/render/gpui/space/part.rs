//! The space level's layout: the window root, the middle band, and the centre
//! zone's cell — and the one `BFlexed` impl that answers how each is laid out.

use super::super::ctx::BRenderCtx;
use super::super::flex::{BFill, BFlex, BFlexed, BLen, BRadius, BSpace};
use crate::v2::theme::BStyleRole;

/// The pieces the space is built from.
pub(super) enum BSpacePart {
    /// The window: a column of zone bands on the gutter colour. No padding —
    /// zones tile to the window edge as Blender's editors do; the gap between
    /// them is the resize seam.
    Root,
    /// The middle band: the side columns and the centre, side by side.
    Middle,
    /// The centre zone's cell in the middle band.
    Centre { lead: bool },
}

impl BFlexed for BSpacePart {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        match *self {
            Self::Root => BFlex::column()
                .full()
                .fill(BFill::Gutter)
                .ink()
                .radius(BRadius::Role(BStyleRole::Workspace))
                .gap(BSpace::Seam),
            Self::Middle => BFlex::row().fills().min_height(BLen::Zero).width(BLen::Full),
            Self::Centre { lead } => {
                let cell = BFlex::cell().fills().height(BLen::Full).unclamped();
                // Every zone boundary keeps the same gutter — that rhythm is
                // what makes the zones read as separate editors.
                if lead {
                    cell.margin_left(BSpace::Seam)
                } else {
                    cell
                }
            }
        }
    }
}

