//! Area walker — fixed side-column widths come from `BAreaLayout::size()`;
//! the enclosing Zone owns variable-axis fractions and height allocation.
//! Left/Right areas scroll vertically and all hosts fill their assigned slot.

use super::flex::{BEdge, BFill, BFlex, BFlexed, BLen, BRadius};
use super::{ctx::BRenderCtx, surface::BCorners, walk};
use crate::v2::area::BAreaType;
use crate::v2::host::{BHostType, host_slug};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::render::BAreaLayout;
use gpui::prelude::*;
use gpui::{AnyElement, SharedString};

fn child_host(v: &BView) -> BHostType {
    if let BView::Host { kind, .. } = v {
        *kind
    } else {
        BHostType::Empty
    }
}

/// The card an area draws its host on. Full-bleed hosts fill their slot flush,
/// with no card chrome, so the host paints the whole area directly (the set is
/// `BHostType::fills_content`); Properties is flush too but keeps its own
/// recessed surface.
fn card(flex: BFlex, c: &BRenderCtx) -> BFlex {
    if c.host == BHostType::Buts || c.host.fills_content() {
        flex
    } else {
        flex.fill(BFill::Workspace)
            .border(BEdge::All)
            .radius(BRadius::Role(BStyleRole::Area))
    }
}

/// An area as drawn: its kind, and the host it holds.
struct BAreaFrame {
    kind: BAreaType,
    host: BHostType,
}

impl BFlexed for BAreaFrame {
    fn flex(&self, c: &BRenderCtx) -> BFlex {
        // The Activity rail is a fixed strip, one rail wide and never
        // dragged, but still a zone of the workspace, so it carries the same
        // card as every other area. One rail wide normally; rail plus a panel
        // while a primary icon's secondary strip is open.
        if self.host == BHostType::Activity {
            let width = c.style.dimensions.activity_width
                + match crate::v2::part::activity::options::open_group(c.s) {
                    Some(_) => c.style.dimensions.panel_width,
                    None => 0.0,
                };
            return card(
                BFlex::row()
                    .width(BLen::Measured(width))
                    .height(BLen::Full)
                    .min_height(BLen::Zero)
                    .keeps_size(),
                c,
            );
        }
        // The zone owns the variable-axis split; an area only fixes a side
        // column's width. Applying Top/Bottom heights here made nested hosts
        // overflow or collapse instead of filling their allotted slot.
        let flex = BFlex::column().fills().min_height(BLen::Zero);
        let flex = match self.kind.size().width {
            Some(w) => flex.width(BLen::Measured(w)),
            None => flex.width(BLen::Full).min_width(BLen::Zero),
        };
        card(flex, c)
    }
}

/// The scroller a side area wraps a stacking host in.
struct BAreaScroll;

impl BFlexed for BAreaScroll {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        BFlex::column().fills().full().unclamped()
    }
}

pub fn view(kind: BAreaType, child: &BView, c: &BRenderCtx) -> AnyElement {
    let host = child_host(child);

    let frame = BAreaFrame { kind, host };
    if host == BHostType::Activity {
        // No clipping: an area's opaque child paints its own matching corners
        // (`semantic_hierarchy_surfaces`).
        return frame.flex(c).div(c).child(walk(child, c)).into_any_element();
    }
    let el = frame.flex(c).div(c);

    // The host is the opaque descendant that reaches every area corner. Give
    // it explicit ownership so it can paint a compatible inner arc; clipping
    // with `overflow_hidden` is intentionally avoided because GPUI's mask is
    // rectangular rather than radius-aware.
    let child_context = c.with_corners(BCorners::ALL);
    // A side area scrolls only when its host *stacks* content that can run
    // taller than the slot — properties, an outliner, a file list. A
    // content-fill host is an editor canvas: it fills the area. Scrolling one
    // let its canvas take its natural height and left a dead band between the
    // canvas and the area's bottom edge, which is the gap under the Image
    // Editor in the Texture Paint workspace.
    if kind.is_scrollable() && !host.fills_content() {
        let id = SharedString::from(format!("area-{:?}-{}", kind, host_slug(host)));
        let scroller = BAreaScroll
            .flex(c)
            .scroller(id, c)
            .child(walk(child, &child_context));
        return el.child(scroller).into_any_element();
    }
    el.child(walk(child, &child_context)).into_any_element()
}
