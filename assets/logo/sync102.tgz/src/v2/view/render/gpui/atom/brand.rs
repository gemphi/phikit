//! The brand: the Phiber mark and the PHIBER wordmark.
//!
//! These are the only icons that are not one square glyph in the text colour.
//! The mark is two tones, and GPUI flattens an SVG to an alpha mask painted in
//! one colour, so it is two files stacked (`phiber_warm` + `phiber_cool`) —
//! the split follows the colourway, not the geometry. The wordmark is wide,
//! so it is sized by height and keeps its own aspect.
//!
//! Every brand slug is resolved here so a view says `BView::icon("phiber")`
//! like any other icon and never knows about layers or aspect ratios.

use super::super::{color::to_hsla, ctx::BRenderCtx};
use super::icon_path;
use gpui::prelude::*;
use gpui::{AnyElement, div, px, svg};

/// The mark at header scale (menubar anchor, modal title).
pub const MARK: &str = "phiber";
/// The mark at splash/about scale.
pub const MARK_LARGE: &str = "phiber_splash";
/// The PHIBER letterforms, one colour, sized by height.
pub const WORDMARK: &str = "phiber_wordmark";
/// The wordmark at splash/about scale, set to the large mark's letter height.
pub const WORDMARK_LARGE: &str = "phiber_wordmark_large";

/// The wordmark is wide, so it lives outside the square icon set.
pub const WORDMARK_PATH: &str = "brand/phiber_wordmark.svg";
/// `WORDMARK_PATH` viewBox is 42.832 × 15.6: cropped to the letters, so the
/// element's height is the letters' height.
const WORDMARK_ASPECT: f32 = 42.832 / 15.6;
/// The Welcome / About mark, as a multiple of the header mark: 64 px against
/// the header's 28. The banner is a greeting, not a poster — at three header
/// marks (84 px) it dominated the screen it was introducing.
const LARGE_SCALE: f32 = 64.0 / 28.0;
/// Beside the large mark the wordmark is set to this share of its height, so
/// the letters stand exactly as tall as the mark's silhouette — the lockup on
/// the brand page. Both assets are cropped to their art: the mark's art is
/// 0.950 of its box, the letters 0.987 of theirs, and 0.950 / 0.987 = 0.96.
const WORDMARK_LARGE_SCALE: f32 = 0.96;

/// True for the slugs this module draws itself (they have no square icon).
pub fn is_brand(name: &str) -> bool {
    matches!(name, MARK | MARK_LARGE | WORDMARK | WORDMARK_LARGE)
}

/// Renders a brand slug, or `None` when `name` is an ordinary icon.
pub fn view(name: &str, c: &BRenderCtx) -> Option<AnyElement> {
    let brand = c.style.dimensions.brand_size;
    match name {
        MARK => Some(mark(brand, c)),
        MARK_LARGE => Some(mark(brand * LARGE_SCALE, c)),
        WORDMARK => Some(wordmark(brand, c)),
        WORDMARK_LARGE => Some(wordmark(brand * LARGE_SCALE * WORDMARK_LARGE_SCALE, c)),
        _ => None,
    }
}

/// The two-tone mark, `size` px square.
pub fn mark(size: f32, c: &BRenderCtx) -> AnyElement {
    let layer = |name: &str, tint| {
        svg()
            .path(icon_path(name))
            .absolute()
            .inset_0()
            .size(px(size))
            .text_color(to_hsla(tint))
    };
    div()
        .relative()
        .size(px(size))
        .flex_shrink_0()
        .child(layer("phiber_warm", c.style.colors.brand_warm))
        .child(layer("phiber_cool", c.style.colors.brand_cool))
        .into_any_element()
}

/// The wordmark, `height` px tall, in the text colour.
pub fn wordmark(height: f32, c: &BRenderCtx) -> AnyElement {
    svg()
        .path(WORDMARK_PATH)
        .h(px(height))
        .w(px(height * WORDMARK_ASPECT))
        .flex_shrink_0()
        .text_color(to_hsla(c.style.colors.text))
        .into_any_element()
}
