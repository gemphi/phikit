//! The loaded scene's keys — what is being read and how far it has got,
//! under `ctx.scene.*`.

use super::BKey;
use crate::v2::state::BPath;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum SceneKey {
    /// `"true"` while a .blend is being read; absent otherwise.
    Loading,
    /// The stage label the progress screen shows.
    LoadStage,
    /// 0..1, the progress bar.
    LoadProgress,
    /// The Cancel intent, consumed by the loader.
    LoadCancel,
    /// The last load error, if any.
    Error,
    /// The path of the file on screen.
    LoadedPath,
}

impl BKey for SceneKey {
    fn path(&self) -> BPath {
        let tail: &'static str = match self {
            Self::Loading => "loading",
            Self::LoadStage => "load_stage",
            Self::LoadProgress => "load_progress",
            Self::LoadCancel => "load_cancel",
            Self::Error => "error",
            Self::LoadedPath => "loaded_path",
        };
        BPath::owned(vec!["scene", tail])
    }
}
