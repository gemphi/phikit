//! The 3D viewport's keys — `RegionView3D` and `View3DShading`, under
//! `ctx.view3d.*`.

use super::BKey;
use crate::v2::state::BPath;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum View3dKey {
    /// Orbit yaw, degrees.
    Yaw,
    /// Orbit pitch, degrees, clamped to ±90.
    Pitch,
    /// Dolly factor, 1 = the framed distance.
    Zoom,
    /// `"false"` for orthographic.
    Perspective,
    PanX,
    PanY,
    /// `View3DShading::type` (Wireframe, Solid, Material, Rendered).
    Shading,
    /// A named viewpoint request (front, top, …), consumed by `follow`.
    View,
    /// The orbit pivot, three floats.
    Pivot,
    /// The camera's field of view, degrees.
    Fov,
    /// Which corner the navigation gizmo sits in.
    GizmoCorner,
}

impl BKey for View3dKey {
    fn path(&self) -> BPath {
        let tail: &'static str = match self {
            Self::Yaw => "yaw",
            Self::Pitch => "pitch",
            Self::Zoom => "zoom",
            Self::Perspective => "perspective",
            Self::PanX => return BPath::owned(vec!["view3d", "pan", "x"]),
            Self::PanY => return BPath::owned(vec!["view3d", "pan", "y"]),
            Self::Shading => "shading",
            Self::View => "view",
            Self::Pivot => "pivot",
            Self::Fov => "fov",
            Self::GizmoCorner => return BPath::owned(vec!["view3d", "gizmo", "corner"]),
        };
        BPath::owned(vec!["view3d", tail])
    }
}
