//! Keys are spelt once. A domain that has moved to `state/keys/` is never
//! addressed by a hand-written path anywhere else: no `vec!["file", …]`, no
//! `"ctx.file.…"` string, outside `state/keys/file.rs`. The list of moved
//! domains grows as `structure.md` §5 proceeds; each one added here stays
//! moved.

use std::path::{Path, PathBuf};

/// Domains whose keys live in `state/keys/<domain>.rs`.
const MOVED: &[&str] = &["file", "outliner", "buts", "view3d", "scene"];

fn rust_files(dir: &Path, out: &mut Vec<PathBuf>) {
    for entry in std::fs::read_dir(dir).expect("dir").flatten() {
        let path = entry.path();
        if path.is_dir() {
            rust_files(&path, out);
        } else if path.extension().and_then(|e| e.to_str()) == Some("rs") {
            out.push(path);
        }
    }
}

#[test]
fn a_moved_domains_keys_are_spelt_only_in_its_keys_file() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("src/v2");
    let mut files = Vec::new();
    rust_files(&root, &mut files);
    let mut violations = Vec::new();
    for file in files {
        let rel = file.strip_prefix(&root).unwrap().to_string_lossy().replace('\\', "/");
        let src = std::fs::read_to_string(&file).unwrap();
        for domain in MOVED {
            if rel == format!("state/keys/{domain}.rs") {
                continue;
            }
            for (n, line) in src.lines().enumerate() {
                let spelt = line.contains(&format!("vec![\"{domain}\",")) || line.contains(&format!("\"ctx.{domain}."));
                if spelt {
                    violations.push(format!("{rel}:{}: {}", n + 1, line.trim()));
                }
            }
        }
    }
    assert!(
        violations.is_empty(),
        "keys spelt outside state/keys — use the domain's BKey enum:\n  {}",
        violations.join("\n  ")
    );
}

#[test]
fn every_file_key_round_trips_through_its_path() {
    use phiber::v2::state::{BKey, FileKey};
    for key in [FileKey::Path, FileKey::Selected, FileKey::Filter("filter_blender"), FileKey::SidebarExpanded("Bookmarks"), FileKey::Bookmark("3")] {
        let path = key.path();
        assert!(path.encode().starts_with("ctx.file."), "{key:?} → {}", path.encode());
    }
    assert_eq!(FileKey::SidebarExpanded("Recent").path().encode(), "ctx.file.sidebar.Recent.expanded");
}
