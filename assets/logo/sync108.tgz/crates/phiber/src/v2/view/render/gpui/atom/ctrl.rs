//! The one renderer for controls (`BView::Ctrl`): a widget per
//! `BCtrlKind`, every edit a `Set` of the control's key.
//!
//! A control composes the atoms that already exist — a button for a
//! checkbox or a step, a tab for a radio option, the field shell for typed
//! text, a popover for a dropdown — so a checkbox in a property panel is
//! the same checkbox as in a filter menu, and a number in the render panel
//! steps the way a frame number does.

use super::super::flex::{BAlign, BEdge, BFill, BFlex, BFlexed, BJustify, BLen, BRadius, BSpace};
use super::super::{ctx::BRenderCtx, walk};
use super::{button, search, tab};
use crate::v2::state::val::BValue;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BControl, BCtrl, BCtrlKind, BPopoverSide};
use gpui::prelude::*;
use gpui::AnyElement;

enum BCtrlPart {
    /// A row of the control's pieces: steps around a number, options of a radio.
    Row,
    /// The number's read-out between its steps, and the bar of a slider.
    Value,
    /// A slider's filled part, `share` of the bar.
    Bar { share: f32 },
    /// A colour's swatch, filled with the value.
    Swatch([f32; 4]),
}

impl BFlexed for BCtrlPart {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        match self {
            Self::Row => BFlex::row().align(BAlign::Center).gap(BSpace::GapXs).min_width(BLen::Zero),
            Self::Value => BFlex::row()
                .fills()
                .min_width(BLen::Zero)
                .align(BAlign::Center)
                .justify(BJustify::Center)
                .height(BLen::Dim(super::super::flex::BDim::ButtonHeight))
                .radius(BRadius::Role(BStyleRole::Field))
                .border(BEdge::All)
                .overflow(super::super::flex::BOverflow::Clip),
            Self::Bar { share } => BFlex::cell()
                .width(BLen::Share(*share))
                .height(BLen::Full)
                .fill(BFill::Tone(crate::v2::theme::BSurfaceTone::Header)),
            Self::Swatch(rgba) => BFlex::cell()
                .width(BLen::Dim(super::super::flex::BDim::ButtonHeight))
                .height(BLen::Dim(super::super::flex::BDim::ButtonHeight))
                .keeps_size()
                .radius(BRadius::Role(BStyleRole::Field))
                .border(BEdge::All)
                .fill(BFill::Swatch(*rgba)),
        }
    }
}

fn check(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let on = matches!(ctrl.value, BValue::Bool(true));
    let mut ctl = BControl::new()
        .with_icon(if on { "check_square" } else { "square" })
        .with_active(on)
        .with_action(ctrl.flip());
    if let Some(label) = &ctrl.label {
        ctl = ctl.with_label(label.clone());
    }
    button::view(&ctl, c)
}

fn toggle(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let on = matches!(ctrl.value, BValue::Bool(true));
    let mut ctl = BControl::new().with_active(on).with_action(ctrl.flip());
    if let Some(label) = &ctrl.label {
        ctl = ctl.with_label(label.clone());
    }
    tab::view(&ctl, c)
}

fn radio(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let chosen = ctrl.chosen().map(|o| o.key.clone()).unwrap_or_default();
    let mut row = BCtrlPart::Row.flex(c).div(c);
    for option in &ctrl.options {
        let mut ctl = BControl::new()
            .with_label(option.label.clone())
            .with_active(option.key == chosen)
            .with_action(ctrl.set(BValue::Enum(option.key.clone())));
        if !option.icon.is_empty() {
            ctl = ctl.with_icon(option.icon.clone());
        }
        row = row.child(tab::view(&ctl, c));
    }
    row.into_any_element()
}

fn select(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let chosen = ctrl.chosen();
    let shown = chosen
        .map(|o| o.label.clone())
        .or_else(|| ctrl.label.clone())
        .unwrap_or_else(|| "—".to_string());
    let Some(open_key) = ctrl.open_key.clone() else {
        return button::view(&BControl::new().with_label(shown), c);
    };
    let anchor = BView::MenuAnchor(
        BControl::new()
            .with_icon("chevron_down")
            .with_label(shown)
            .with_active(ctrl.open)
            .with_action(BAction::Toggle(open_key.clone())),
    );
    let body = ctrl
        .options
        .iter()
        .map(|o| {
            let on = chosen.is_some_and(|ch| ch.key == o.key);
            BView::MenuItem(
                BControl::new()
                    .with_icon(if on { "check" } else if o.icon.is_empty() { "" } else { o.icon.as_str() })
                    .with_label(o.label.clone())
                    .with_active(on)
                    .with_action(ctrl.set(BValue::Enum(o.key.clone()))),
            )
        })
        .collect();
    walk(&BView::popover(anchor, body, ctrl.open, BAction::Reset(open_key), BPopoverSide::Below), c)
}

fn number(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let step = |icon: &str, steps: f32| {
        let mut ctl = BControl::new().with_icon(icon);
        if let Some(action) = ctrl.nudge(steps) {
            ctl = ctl.with_action(action);
        }
        button::view(&ctl, c)
    };
    let shown = ctrl.value.display();
    let field = search::view(&shown, if ctrl.editing { &shown } else { "" }, ctrl.editing, &ctrl.set(ctrl.value.clone()), c);
    BCtrlPart::Row
        .flex(c)
        .div(c)
        .child(step("chevron_left", -1.0))
        .child(field)
        .child(step("chevron_right", 1.0))
        .into_any_element()
}

fn slider(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let BCtrlKind::Slider { min, max } = ctrl.kind else { return number(ctrl, c) };
    let now = match ctrl.value {
        BValue::Float(v) => v,
        BValue::Int(v) => v as f32,
        _ => min,
    };
    let share = if max > min { ((now - min) / (max - min)).clamp(0.0, 1.0) } else { 0.0 };
    let bar = BCtrlPart::Value
        .flex(c)
        .div(c)
        .child(BCtrlPart::Bar { share }.flex(c).div(c))
        .child(gpui::SharedString::from(ctrl.value.display()));
    let step = |icon: &str, steps: f32| {
        let mut ctl = BControl::new().with_icon(icon);
        if let Some(action) = ctrl.nudge(steps) {
            ctl = ctl.with_action(action);
        }
        button::view(&ctl, c)
    };
    BCtrlPart::Row
        .flex(c)
        .div(c)
        .child(step("chevron_left", -1.0))
        .child(bar)
        .child(step("chevron_right", 1.0))
        .into_any_element()
}

fn text(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let placeholder = ctrl.label.clone().unwrap_or_default();
    let shown = ctrl.value.display();
    search::view(&placeholder, &shown, ctrl.editing, &ctrl.set(ctrl.value.clone()), c)
}

fn color(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    let rgba = match ctrl.value {
        BValue::Color(rgba) => rgba,
        _ => [0.0, 0.0, 0.0, 1.0],
    };
    BCtrlPart::Row
        .flex(c)
        .div(c)
        .child(BCtrlPart::Swatch(rgba).flex(c).div(c))
        .child(text(ctrl, c))
        .into_any_element()
}

pub fn view(ctrl: &BCtrl, c: &BRenderCtx) -> AnyElement {
    match ctrl.kind {
        BCtrlKind::Check => check(ctrl, c),
        BCtrlKind::Toggle => toggle(ctrl, c),
        BCtrlKind::Radio => radio(ctrl, c),
        BCtrlKind::Select => select(ctrl, c),
        BCtrlKind::Int { .. } | BCtrlKind::Number { .. } => number(ctrl, c),
        BCtrlKind::Slider { .. } => slider(ctrl, c),
        BCtrlKind::Text | BCtrlKind::Search | BCtrlKind::Path => text(ctrl, c),
        BCtrlKind::Color => color(ctrl, c),
    }
}
