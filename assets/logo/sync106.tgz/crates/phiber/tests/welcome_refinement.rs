//! Focused regressions for viewport-filling Welcome and current modal forms.
//!
//! Validates: Requirements 3.4, 4.4, 4.5, 10.1, 11.1, 11.5-11.7, 12.7, 14.7-14.12

use phiber::v2::{
    modal::{BModalType, splash::BSplashModal},
    state::{
        BState,
        key::{K_MODAL, K_SPACE},
        val::V_MODAL_FILE_BROWSER,
    },
    view::{BAction, BPanelRole, BView, BViewItem},
};
use std::{fs, path::PathBuf};

fn crate_path(relative: &str) -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(relative)
}

fn source(relative: &str) -> String {
    let path = crate_path(relative);
    fs::read_to_string(&path).unwrap_or_else(|error| panic!("{}: {error}", path.display()))
}

fn visit<'a>(
    view: &'a BView,
    strings: &mut Vec<&'a str>,
    icons: &mut Vec<&'a str>,
    actions: &mut Vec<&'a BAction>,
) {
    match view {
        BView::Label { text } | BView::VLabel { text } | BView::Field { text } => {
            strings.push(text)
        }
        BView::Icon { name } => icons.push(name),
        BView::Button(ctl) => {
            if let Some(icon) = &ctl.icon {
                icons.push(icon);
            }
            if let Some(label) = &ctl.label {
                strings.push(label);
            }
            if let Some(action) = &ctl.action {
                actions.push(action);
            }
        }
        BView::Row { children }
        | BView::Column { children }
        | BView::ListRow { children, .. }
        | BView::Panel { children, .. } => {
            for child in children {
                visit(child, strings, icons, actions);
            }
        }
        _ => {}
    }
}

#[test]
fn welcome_uses_phiber_brand_icon_and_one_aligned_content_header() {
    let view = BSplashModal.build(&BState::new());
    let BView::Column { children } = &view else {
        panic!("Welcome body must be one column")
    };
    // Blender `WM_MT_splash`: banner, then two splits (New File | Recent
    // Files / Getting Started) and (Open… + Recover | What's New + support).
    assert_eq!(children.len(), 3);
    assert!(matches!(
        &children[0],
        BView::Panel { role: BPanelRole::Header, children }
            if matches!(children.as_slice(), [BView::Icon { name }, BView::Icon { name: word }, _, BView::Label { .. }]
                if name == "phiber_banner" && word == "phiber_wordmark_banner")
    ));
    for split in &children[1..] {
        let BView::Row { children: cards } = split else { panic!("splash splits are rows") };
        assert_eq!(cards.len(), 2, "each split has two cards");
        assert!(cards.iter().all(|c| matches!(c, BView::Panel { role: BPanelRole::Card, .. })),
            "every splash block is one rounded Card");
    }

    let mut strings = Vec::new();
    let mut icons = Vec::new();
    let mut actions = Vec::new();
    visit(&view, &mut strings, &mut icons, &mut actions);
    assert!(
        strings
            .iter()
            .all(|text| !text.to_ascii_lowercase().contains("blender"))
    );
    // The banner sets the mark and the name at the banner's own size, so they
    // stand together inside the strip instead of spilling out of it.
    assert!(icons.contains(&"phiber_banner") && icons.contains(&"phiber_wordmark_banner"));
    assert_eq!(BModalType::Splash.spec().label, "Welcome to Phiber");
    assert_eq!(BModalType::Splash.spec().icon, "phiber");
    for asset in ["phiber", "phiber_splash", "phiber_warm", "phiber_cool"] {
        assert!(crate_path(&format!("assets/icons/{asset}.svg")).is_file(), "{asset}");
    }
    assert!(crate_path("assets/brand/phiber_wordmark.svg").is_file());
}

#[test]
fn welcome_preserves_template_open_and_link_actions() {
    let view = BSplashModal.build(&BState::new());
    let mut strings = Vec::new();
    let mut icons = Vec::new();
    let mut actions = Vec::new();
    visit(&view, &mut strings, &mut icons, &mut actions);

    for target in [
        "Layout",
        "Shading",
        "UvEditing",
        "Animation",
        "Rendering",
        "Compositing",
        "GeometryNodes",
        "Scripting",
    ] {
        assert!(
            actions.iter().copied().any(|action| matches!(
                action, BAction::Set(path, value) if path == &K_SPACE && value == target
            )),
            "missing template action for {target}"
        );
    }
    assert!(actions.iter().copied().any(|action| matches!(
        action,
        BAction::Set(path, value) if path == &K_MODAL && value == V_MODAL_FILE_BROWSER
    )));
    // Empty recents ⇒ "Getting Started" (5 links) + What's New / Support (2).
    // Every one but the Phiber website reads in the app: it opens a document
    // in the reader (`ctx.reader.doc`); only Phiber's own site leaves it.
    let entries: Vec<_> = phiber::v2::modal::splash::GETTING_STARTED
        .iter()
        .chain(phiber::v2::modal::splash::FOOT_LINKS)
        .collect();
    let leaving = entries.iter().filter(|e| e.target.starts_with("https://phiace.dev")).count();
    assert_eq!(
        actions
            .iter()
            .copied()
            .filter(|action| matches!(action, BAction::Set(path, _) if path.encode() == "ctx.link"))
            .count(),
        leaving
    );
    assert_eq!(
        actions
            .iter()
            .copied()
            .filter(|action| matches!(action, BAction::Set(path, _) if path.encode() == "ctx.reader.doc"))
            .count(),
        entries.len() - leaving
    );
}

#[test]
fn welcome_renderer_is_centered_bounded_resolved_and_fullscreen() {
    let welcome = source("src/v2/view/render/gpui/modal/welcome.rs");
    let modal = source("src/v2/view/render/gpui/modal/mod.rs");
    let fullscreen = source("src/v2/view/render/gpui/modal/fullscreen.rs");
    let title = source("src/v2/view/render/gpui/modal/title.rs");

    // The Welcome form's containers are `BModalPart` decisions: centred on
    // both axes and padded, a column bounded by the Splash spec's width, cards
    // spaced by the large gap.
    let part = source("src/v2/view/render/gpui/modal/part.rs");
    let layout = part
        .split("Self::WelcomeLayout =>")
        .nth(1)
        .expect("welcome layout")
        .split("Self::WelcomeColumn")
        .next()
        .expect("welcome layout end");
    assert!(welcome.contains("pub struct BWelcome"));
    assert!(welcome.contains("welcome-centered-layout"));
    assert!(welcome.contains("welcome-content-column"));
    assert!(layout.contains(".align(BAlign::Center)"));
    assert!(layout.contains(".justify(BJustify::Center)"));
    assert!(layout.contains(".pad(BSpace::PadLg)"));
    assert!(welcome.contains("max_width: BModalType::Splash.spec().width"));
    assert!(part.contains(".max_width(BLen::Measured(max_width))"));
    assert!(part.contains(".gap(BSpace::GapLg)"));
    assert!(modal.contains("BModalType::Splash | BModalType::About"));
    assert!(modal.contains("fullscreen::BFullscreen { kind, body }.render(c)"));
    assert!(fullscreen.contains("BWelcome(self.body).render(c)"));
    // Fullscreen covers the window: an overlay at full size.
    let full = part
        .split("Self::Fullscreen =>")
        .nth(1)
        .expect("fullscreen part")
        .split("Self::FullscreenBody")
        .next()
        .expect("fullscreen part end");
    assert!(full.contains(".place(BPlace::Overlay)"));
    assert!(full.contains(".full()"));
    // The title bar reads its icon and label through the modal's heading,
    // so the reader can show its document's title.
    assert!(title.contains("self.kind.heading(c.s)"));
}

#[test]
fn modal_popover_and_canvas_decomposition_is_thin_and_resolved() {
    let modal = source("src/v2/view/render/gpui/modal/mod.rs");
    let card = source("src/v2/view/render/gpui/modal/card.rs");
    let popover = source("src/v2/view/render/gpui/popover.rs");
    let canvas = source("src/v2/view/render/gpui/atom/canvas/mod.rs");
    let fallback = source("src/v2/view/render/gpui/atom/canvas/fallback.rs");

    for dispatcher in [&modal, &canvas] {
        assert!(!dispatcher.contains("div("));
        assert!(!dispatcher.contains("svg("));
        assert!(!dispatcher.contains(".child("));
    }
    // The card's surface is a `BModalPart` decision: the Modal radius role,
    // lifted (the theme's surface shadow, drawn only when it is ExtraLarge),
    // on the Modal surface tone.
    let part = source("src/v2/view/render/gpui/modal/part.rs");
    let apply = source("src/v2/view/render/gpui/flex/apply.rs");
    let tokens = source("src/v2/view/render/gpui/flex/token.rs");
    assert!(card.contains("pub struct BCard"));
    assert!(card.contains("BModalPart::Card {"));
    assert!(part.contains(".radius(BRadius::Role(BStyleRole::Modal))"));
    assert!(part.contains(".lifted()"));
    assert!(apply.contains("self.lifted && c.style.surface_shadow() == BShadowStyle::ExtraLarge"));
    assert!(part.contains(".fill(BFill::Tone(BSurfaceTone::Modal))"));
    assert!(tokens.contains("Self::Tone(tone) => resolved_gradient(c.style.surface(tone))"));
    assert!(card.contains("modal-backdrop-"));
    assert!(popover.contains("pub struct BPopover"));
    assert!(popover.contains("BStyleRole::Popover"));
    assert!(popover.contains("c.style.surface(BSurfaceTone::Card)"));
    assert!(canvas.contains("view3d::BView3d.render(c)"));
    assert!(canvas.contains("fallback::BFallback(host).render(c)"));
    assert!(fallback.contains("c.style.viewport_surface()"));

    for renderer in [card, popover, fallback] {
        assert!(!renderer.contains("c.p."));
        assert!(!renderer.contains("METRICS"));
        assert!(!renderer.contains("render_impl"));
    }
    assert!(!modal.contains("BView::Space"));
    assert!(!modal.contains("BSpaceType"));
}
