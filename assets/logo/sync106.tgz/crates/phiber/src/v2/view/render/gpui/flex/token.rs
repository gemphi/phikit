//! The tokens a `BFlex` is written in. Every number the element uses is one of
//! these, resolved against the render pass's style — so no layout decision
//! carries a literal.

use super::super::{
    color::{resolved_gradient, to_hsla},
    ctx::BRenderCtx,
};
use crate::v2::theme::{BStyleRole, BSurfaceTone};
use gpui::Background;

/// A spacing token: a gap, a padding or a margin, resolved from the theme.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BSpace {
    None,
    GapXs,
    GapSm,
    GapMd,
    GapLg,
    PadXs,
    PadSm,
    PadMd,
    PadLg,
    /// The gutter between resizable zones — the width of a resize seam.
    Seam,
    /// The lead above a vertical rail's first icon, level with the first
    /// accordion header beside it.
    RailLead,
    /// The gap a menu cap leaves above itself in its strip.
    MenuTopGap,
}

impl BSpace {
    pub(super) fn px(self, c: &BRenderCtx) -> f32 {
        let s = &c.style.spacing;
        match self {
            Self::None => s.gap_none,
            Self::GapXs => s.gap_xs,
            Self::GapSm => s.gap_sm,
            Self::GapMd => s.gap_md,
            Self::GapLg => s.gap_lg,
            Self::PadXs => s.pad_xs,
            Self::PadSm => s.pad_sm,
            Self::PadMd => s.pad_md,
            Self::PadLg => s.pad_lg,
            Self::Seam => c.style.resize.gap,
            Self::RailLead => c.style.rail_lead(),
            Self::MenuTopGap => c.style.dimensions.menu_top_gap,
        }
    }
}

/// A named dimension from the theme.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BDim {
    HeaderHeight,
    FooterHeight,
    ScrubbingHeight,
    AssetShelfHeight,
    BottomStripHeight,
    StatusLogHeight,
    ToolbarWidth,
    NavbarWidth,
    SidebarMinWidth,
    PanelWidth,
    ChannelsWidth,
    ToolPropsWidth,
    SideZoneDefaultWidth,
}

impl BDim {
    pub(super) fn px(self, c: &BRenderCtx) -> f32 {
        let d = &c.style.dimensions;
        match self {
            Self::HeaderHeight => d.header_height,
            Self::FooterHeight => d.footer_height,
            Self::ScrubbingHeight => d.scrubbing_height,
            Self::AssetShelfHeight => d.asset_shelf_height,
            Self::BottomStripHeight => d.bottom_strip_height,
            Self::StatusLogHeight => d.status_log_height,
            Self::ToolbarWidth => d.toolbar_width,
            Self::NavbarWidth => d.navbar_width,
            Self::SidebarMinWidth => d.sidebar_min_width,
            Self::PanelWidth => d.panel_width,
            Self::ChannelsWidth => d.channels_width,
            Self::ToolPropsWidth => d.tool_props_width,
            Self::SideZoneDefaultWidth => d.side_zone_default_width,
        }
    }
}

/// A length on one axis.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BLen {
    /// The whole of the parent.
    Full,
    /// Zero — as a minimum, what lets a flex child shrink below its content.
    Zero,
    /// A theme dimension.
    Dim(BDim),
    /// A share of the parent — a reading sheet two thirds of the window wide.
    Share(f32),
    /// A length that comes from elsewhere — a dragged zone size, a sum of
    /// theme dimensions, a size a modal's spec declares. Never a literal in a
    /// walker: the number is computed from the theme or state, or declared in
    /// the one spec that owns it.
    Measured(f32),
}

/// The flex basis a growing child starts from.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BBasis {
    /// 0% of the parent — `flex_1`'s basis, so free space splits by grow alone.
    NoShare,
    /// 0 px — the pinned header cells, which divide the row by grow alone.
    NoPixels,
}

/// How children line up across the axis.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BAlign {
    Start,
    Center,
    End,
    Stretch,
}

/// How children spread along the axis.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BJustify {
    Start,
    Center,
    End,
    Between,
}

/// What a container paints behind its children.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BFill {
    /// Explicitly nothing.
    Clear,
    /// The gutter showing between zones.
    Gutter,
    /// The workspace surface an area card sits on.
    Workspace,
    /// A semantic surface tone (modal, header, …).
    Tone(BSurfaceTone),
    /// The current host's header surface.
    HostHeader,
    /// The current host's strip gradient.
    HostStrip,
    /// Chrome floating over a canvas: the panel colour, translucent enough
    /// for the canvas to show through (Blender's floating panels).
    Floating,
    /// The dim laid over the workspace behind a modal.
    ModalDim,
}

impl BFill {
    pub(super) fn background(self, c: &BRenderCtx) -> Background {
        match self {
            Self::Clear => gpui::transparent_black().into(),
            Self::Gutter => to_hsla(c.style.resize_gutter_background()).into(),
            Self::Workspace => to_hsla(c.style.workspace_background()).into(),
            Self::Tone(tone) => resolved_gradient(c.style.surface(tone)),
            Self::HostHeader => resolved_gradient(c.style.host_header_surface(c.host)),
            Self::HostStrip => resolved_gradient(c.style.strip_gradient(c.host)),
            Self::ModalDim => to_hsla(c.style.colors.bg_modal_dim).into(),
            Self::Floating => {
                let base = to_hsla(c.style.colors.bg_panel);
                gpui::hsla(base.h, base.s, base.l, c.style.effects.floating_alpha).into()
            }
        }
    }
}

/// Which edges a border runs along.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BEdge {
    All,
    Bottom,
}

/// Which corners are rounded, and by how much.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BRadius {
    /// Every corner, at a role's radius.
    Role(BStyleRole),
    /// Every corner, at a radius computed from roles by the caller (an inner
    /// arc compatible with the surface around it).
    All(f32),
    /// The top two corners.
    Top(f32),
    /// A chosen set of corners — the ones this element owns on its host's
    /// surface.
    Corners { tl: bool, tr: bool, bl: bool, br: bool, radius: f32 },
}

/// Where a container sits.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BPlace {
    /// In the flow, positioning nothing.
    Flow,
    /// In the flow, and the anchor its absolute children position against.
    Anchor,
    /// Over its parent, covering it edge to edge.
    Overlay,
    /// Floating over its parent against one side, inset from that side and
    /// from the top and bottom — the viewport's toolbar and sidebar.
    Float { side: BSide, inset: BSpace },
    /// Floating directly above its anchor, flush with the anchor's left and
    /// right edges — the action log's drawer over the status bar.
    Drawer,
}

/// A side of the parent.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BSide {
    Left,
    Right,
}

/// What happens to content that does not fit. Scrolling is not an overflow
/// mode here: a scroller keeps state, so it is built by [`BFlex::scroller`].
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BOverflow {
    Visible,
    Clip,
}

/// Text defaults for everything inside.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BType {
    Header,
    Caption,
}

/// The text colour inside.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BInk {
    /// The theme's text.
    Text,
    /// The theme's dim text.
    Dim,
    /// Dim text faded further: `step` steps of a 16th toward nothing, floored
    /// so the last step is still legible — the action log's older lines.
    Faded(u8),
}

