//! Modal title bar with existing minimize, maximize/restore, and close actions.

use super::super::flex::BFlexed;
use super::super::{color::to_hsla, ctx::BRenderCtx, surface::compatible_inner_radius};
use super::BModalPart;
use crate::v2::modal::BModalType;
use crate::v2::state::{
    key::{K_MODAL, K_MODAL_MAXIMIZED, K_MODAL_MINIMIZED},
    val::V_EMPTY,
};
use crate::v2::theme::BStyleRole;
use crate::v2::view::prim::BAction;
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, px, svg};
use std::rc::Rc;

pub struct BTitle {
    pub kind: BModalType,
    pub maximized: bool,
    pub rounded: bool,
}

impl BTitle {
    /// A modal's window control — the same button the OS caption draws, with
    /// the modal's own action attached.
    fn button(&self, slug: &str, icon: &str, action: BAction, c: &BRenderCtx) -> gpui::Stateful<gpui::Div> {
        let handler = c.h.clone();
        let dispatched = action.clone();
        super::super::atom::caption::control(
            SharedString::from(format!("modal-{slug}")),
            icon,
            slug == "close",
            c,
        )
        .on_click(move |_e: &ClickEvent, w: &mut gpui::Window, cx: &mut gpui::App| {
            (Rc::clone(&handler))(&dispatched, w, cx);
        })
    }

    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let (icon, label) = self.kind.heading(c.s);
        let title_row = BModalPart::TitleGroup
            .flex(c)
            .div(c)
            .child(
                svg()
                    .path(format!("icons/{icon}.svg"))
                    .size(px(c.style.dimensions.icon_size))
                    .flex_shrink_0()
                    .text_color(to_hsla(c.style.colors.text)),
            )
            .child(SharedString::from(label.to_string()));
        // A card modal's bar rounds its top corners to sit inside the card's
        // border; a fullscreen modal's bar is square to the window.
        let top_radius = self.rounded.then(|| {
            compatible_inner_radius(c.style.radius_for(BStyleRole::Modal), c.style.strokes.border)
        });
        BModalPart::TitleBar { top_radius }
            .flex(c)
            .div(c)
            .child(title_row)
            .child({
                let mut controls = BModalPart::TitleControls.flex(c).div(c);
                for ctl in super::super::atom::caption::WINDOW_CONTROLS {
                    let action = match ctl.slug {
                        "min" => BAction::Toggle(K_MODAL_MINIMIZED),
                        "max" => BAction::Toggle(K_MODAL_MAXIMIZED),
                        _ => BAction::Set(K_MODAL, V_EMPTY.to_string()),
                    };
                    controls = controls.child(self.button(
                        ctl.slug,
                        ctl.icon(self.maximized),
                        action,
                        c,
                    ));
                }
                controls
            })
            .into_any_element()
    }
}
