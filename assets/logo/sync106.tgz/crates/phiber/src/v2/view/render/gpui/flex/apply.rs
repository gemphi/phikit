//! Turning a `BFlex` into a GPUI element — the only place in the renderer that
//! calls GPUI's style builders. Everything above this reads as decisions;
//! this is the mechanics.

use super::element::BFlex;
use super::token::{BAlign, BBasis, BEdge, BInk, BJustify, BLen, BOverflow, BPlace, BRadius, BSide, BType};
use super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::theme::BShadowStyle;
use crate::v2::view::render::BAxis;
use gpui::prelude::*;
use gpui::{Div, div, px};

impl BFlex {
    /// The container, styled. The only place in the renderer that turns a
    /// layout decision into GPUI style.
    pub fn div(&self, c: &BRenderCtx) -> Div {
        let len = |l: BLen| -> gpui::Length {
            match l {
                BLen::Full => gpui::relative(1.).into(),
                BLen::Zero => gpui::Pixels::ZERO.into(),
                BLen::Dim(d) => px(d.px(c)).into(),
                BLen::Share(f) => gpui::relative(f).into(),
                BLen::Measured(v) => px(v).into(),
            }
        };
        let mut el = div();
        if let Some(axis) = self.axis {
            el = el.flex();
            el = match axis {
                BAxis::Row => el.flex_row(),
                BAxis::Column => el.flex_col(),
            };
        }
        {
            let style = el.style();
            if let Some(g) = self.grow {
                style.flex_grow = Some(g);
            }
            if let Some(s) = self.shrink {
                style.flex_shrink = Some(s);
            }
            if let Some(b) = self.basis {
                style.flex_basis = Some(match b {
                    BBasis::NoShare => gpui::relative(0.).into(),
                    BBasis::NoPixels => gpui::Pixels::ZERO.into(),
                });
            }
            if let Some(w) = self.width {
                style.size.width = Some(len(w));
            }
            if let Some(h) = self.height {
                style.size.height = Some(len(h));
            }
            if let Some(w) = self.min_width {
                style.min_size.width = Some(len(w));
            }
            if let Some(h) = self.min_height {
                style.min_size.height = Some(len(h));
            }
            if let Some(w) = self.max_width {
                style.max_size.width = Some(len(w));
            }
        }
        el = match self.align {
            Some(BAlign::Start) => el.items_start(),
            Some(BAlign::Center) => el.items_center(),
            Some(BAlign::End) => el.items_end(),
            Some(BAlign::Stretch) => el.items_stretch(),
            None => el,
        };
        el = match self.justify {
            Some(BJustify::Start) => el.justify_start(),
            Some(BJustify::Center) => el.justify_center(),
            Some(BJustify::End) => el.justify_end(),
            Some(BJustify::Between) => el.justify_between(),
            None => el,
        };
        if let Some(g) = self.gap {
            el = el.gap(px(g.px(c)));
        }
        if let Some(p) = self.pad_top {
            el = el.pt(px(p.px(c)));
        }
        if let Some(p) = self.pad_right {
            el = el.pr(px(p.px(c)));
        }
        if let Some(p) = self.pad_bottom {
            el = el.pb(px(p.px(c)));
        }
        if let Some(p) = self.pad_left {
            el = el.pl(px(p.px(c)));
        }
        if let Some(m) = self.margin_left {
            el = el.ml(px(m.px(c)));
        }
        if let Some(r) = self.raised_by {
            el = el.mt(px(-r.px(c)));
        }
        if let Some(fill) = self.fill {
            el = el.bg(fill.background(c));
        }
        match self.border {
            Some(BEdge::All) => {
                el = el
                    .border(px(c.style.strokes.border))
                    .border_color(to_hsla(c.style.colors.border))
            }
            Some(BEdge::Bottom) => {
                el = el
                    .border_b(px(c.style.strokes.border))
                    .border_color(to_hsla(c.style.colors.border))
            }
            None => {}
        }
        match self.radius {
            Some(BRadius::Role(role)) => el = el.rounded(px(c.style.radius_for(role))),
            Some(BRadius::All(r)) => el = el.rounded(px(r)),
            Some(BRadius::Top(r)) => el = el.rounded_t(px(r)),
            Some(BRadius::Corners { tl, tr, bl, br, radius }) => {
                let r = px(radius);
                if tl {
                    el = el.rounded_tl(r);
                }
                if tr {
                    el = el.rounded_tr(r);
                }
                if bl {
                    el = el.rounded_bl(r);
                }
                if br {
                    el = el.rounded_br(r);
                }
            }
            None => {}
        }
        if self.lifted && c.style.surface_shadow() == BShadowStyle::ExtraLarge {
            el = el.shadow_xl();
        }
        match self.ink {
            Some(BInk::Text) => el = el.text_color(to_hsla(c.style.colors.text)),
            Some(BInk::Dim) => el = el.text_color(to_hsla(c.style.colors.text_dim)),
            Some(BInk::Faded(step)) => {
                let dim = to_hsla(c.style.colors.text_dim);
                let fade = (1.0 - f32::from(step) / 16.0).max(0.45);
                el = el.text_color(gpui::Hsla { a: dim.a * fade, ..dim });
            }
            None => {}
        }
        match self.type_size {
            Some(BType::Header) => el = el.text_size(px(c.style.typography.header)),
            Some(BType::Caption) => el = el.text_size(px(c.style.typography.caption)),
            None => {}
        }
        el = match self.place {
            BPlace::Flow => el,
            BPlace::Anchor => el.relative(),
            BPlace::Overlay => el.absolute().inset_0(),
            BPlace::Drawer => el
                .absolute()
                .bottom(gpui::relative(1.0))
                .left(gpui::Pixels::ZERO)
                .right(gpui::Pixels::ZERO),
            BPlace::Float { side, inset } => {
                let d = px(inset.px(c));
                let el = el.absolute().top(d).bottom(d);
                match side {
                    BSide::Left => el.left(d),
                    BSide::Right => el.right(d),
                }
            }
        };
        el = match self.overflow {
            BOverflow::Visible => el,
            BOverflow::Clip => el.overflow_hidden(),
        };
        if self.occludes {
            el = el.occlude();
        }
        el
    }

    /// The container unfolding: drawn at no height the first frame, growing
    /// to its declared height over the theme's motion duration, once. The
    /// drawer the action log opens over the status bar. With reduced motion
    /// it is drawn at full height from the first frame.
    pub fn div_unfolding(
        &self,
        id: impl Into<gpui::ElementId>,
        c: &BRenderCtx,
    ) -> gpui::AnimationElement<Div> {
        use gpui::AnimationExt as _;
        let full = match self.height {
            Some(BLen::Dim(d)) => d.px(c),
            Some(BLen::Measured(v)) => v,
            _ => 0.0,
        };
        let motion = std::time::Duration::from_secs_f32(c.style.effects.motion_ms.max(0.0) / 1000.0);
        let animation = gpui::Animation::new(motion).with_easing(gpui::ease_out_quint());
        self.div(c).with_animation(id, animation, move |el, t| el.h(px(full * t)))
    }

    /// The container as a vertical scroller. Scrolling keeps state (the
    /// offset), so GPUI needs an id to hold it by — which is why this is the
    /// one constructor that takes one.
    pub fn scroller(&self, id: impl Into<gpui::ElementId>, c: &BRenderCtx) -> gpui::Stateful<Div> {
        self.div(c).id(id).overflow_y_scroll()
    }
}
