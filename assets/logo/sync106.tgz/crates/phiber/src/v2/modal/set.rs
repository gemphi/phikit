//! Modal set — one `BModalSpec` per `BModalType`.

use super::{BModalSpec, BModalType, spec::BModalShape};

// Order MUST match `BModalType` variant order.
pub static SET: &[BModalSpec] = &[
    BModalSpec {
        kind: BModalType::Settings,
        label: "Preferences",
        icon: "settings",
        width: 960.0,
        height: 640.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Help,
        label: "Help",
        icon: "help",
        width: 900.0,
        height: 640.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Profile,
        label: "Profile",
        icon: "profile",
        width: 480.0,
        height: 520.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Command,
        label: "Command Palette",
        icon: "command",
        width: 640.0,
        height: 420.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Splash,
        label: "Welcome to Phiber",
        icon: "phiber",
        width: 880.0,
        height: 560.0,
        shape: BModalShape::Fullscreen,
    },
    BModalSpec {
        kind: BModalType::About,
        label: "About Phiber",
        icon: "about",
        width: 640.0,
        height: 480.0,
        shape: BModalShape::Fullscreen,
    },
    BModalSpec {
        kind: BModalType::FileBrowser,
        label: "Phiber File View",
        icon: "folder",
        width: 1024.0,
        height: 640.0,
        shape: BModalShape::Card,
    },
    // Blender titles this window "Blender Render".
    BModalSpec {
        kind: BModalType::Render,
        label: "Phiber Render",
        icon: "render",
        width: 1100.0,
        height: 720.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Spaces,
        label: "Spaces",
        icon: "grid",
        width: 560.0,
        height: 420.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Collab,
        label: "Collaboration",
        icon: "chat",
        width: 640.0,
        height: 520.0,
        shape: BModalShape::Card,
    },
    BModalSpec {
        kind: BModalType::Progress,
        label: "Opening File",
        icon: "folder_open",
        // Twice the old 420: the bar and its stage label both run the full
        // card width now, and a stage line ("Reading objects 431/2104
        // Cube.003") needs the room before it ellipsises.
        width: 840.0,
        height: 200.0,
        shape: BModalShape::Card,
    },
    // A page to read: two thirds of the window wide, the whole height, so a
    // manual page or the release notes read at a column width instead of
    // a browser's.
    BModalSpec {
        kind: BModalType::Reader,
        label: "Reader",
        icon: "manual",
        width: 0.0,
        height: 0.0,
        shape: BModalShape::Sheet { share: 2.0 / 3.0 },
    },
];
