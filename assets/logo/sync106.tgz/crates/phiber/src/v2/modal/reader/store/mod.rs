//! The reader's store — every document, one file each. `DOCS` is the order
//! the store lists them in; the first is the manual's front page, which is
//! what the reader shows when no document is named.

use super::set::BReaderDoc;

mod about;
mod community;
mod credits;
mod get_involved;
mod help_system;
mod license;
mod release_notes;
mod report_bug;
mod support;
mod tutorials;
mod whats_new;

pub static DOCS: &[&BReaderDoc] = &[
    &about::DOC,
    &help_system::DOC,
    &tutorials::DOC,
    &support::DOC,
    &community::DOC,
    &get_involved::DOC,
    &whats_new::DOC,
    &release_notes::DOC,
    &report_bug::DOC,
    &license::DOC,
    &credits::DOC,
];
