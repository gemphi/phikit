//! `BModalType` — every overlay dialog that can be opened.
//! Opens by writing its slug to `ctx.modal`; closes by clearing the key.
//!
//! `FileBrowser` is the same underlying widget as the `File` host — Blender
//! reuses `space_file` for both the workspace editor and the modal dialog
//! (Open / Save As / Import / Export). The overlay flavour reads
//! `ctx.file.purpose` for its title (Open Blender File / Save As / …).

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BModalType {
    Settings,
    Help,
    Profile,
    Command,
    Splash,
    About,
    FileBrowser,
    /// Blender's render window — an Image Editor in its own window
    /// (`WM_OT_render` with `render_display_type == 'WINDOW'`).
    Render,
    /// Workspace picker (Activity ▸ Spaces).
    Spaces,
    /// Collaboration: chat / stream sessions (Activity ▸ Chat, Stream).
    Collab,
    /// Reading a file: what is being opened and how far it has got.
    Progress,
    /// Reading a document from the store: the manual, the release notes.
    Reader,
}

impl BModalType {
    pub const ALL: &'static [BModalType] = &[
        Self::Settings,
        Self::Help,
        Self::Profile,
        Self::Command,
        Self::Splash,
        Self::About,
        Self::FileBrowser,
        Self::Render,
        Self::Spaces,
        Self::Collab,
        Self::Progress,
        Self::Reader,
    ];

    pub fn slug(self) -> &'static str {
        match self {
            Self::Settings => "settings",
            Self::Help => "help",
            Self::Profile => "profile",
            Self::Command => "command",
            Self::Splash => "splash",
            Self::About => "about",
            Self::FileBrowser => "file_browser",
            Self::Render => "render",
            Self::Spaces => "spaces",
            Self::Collab => "collab",
            Self::Progress => "progress",
            Self::Reader => "reader",
        }
    }

    pub fn from_slug(s: &str) -> Option<Self> {
        Self::ALL.iter().copied().find(|m| m.slug() == s)
    }

    pub fn spec(self) -> &'static super::BModalSpec {
        &super::SET[self as usize]
    }
    pub fn label(self) -> &'static str {
        self.spec().label
    }
    pub fn icon(self) -> &'static str {
        self.spec().icon
    }

    /// What the title bar shows: the spec's icon and label, except for the
    /// reader, whose title is the document's.
    pub fn heading(self, s: &crate::v2::state::BState) -> (&'static str, &'static str) {
        match self {
            Self::Reader => {
                let doc = super::reader::current(s);
                (doc.icon, doc.title)
            }
            _ => (self.icon(), self.label()),
        }
    }
}
