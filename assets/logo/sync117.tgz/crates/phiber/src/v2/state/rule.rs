//! Rules: what else changes when a key is set.
//!
//! A `Set` writes one key. Some keys mean more than their value — a named
//! viewpoint is two angles, a frame step is a new frame, a path typed into
//! the file browser is a trip through its history. Each of those meanings
//! is a [`BRule`] that lives with the level it belongs to (the viewpoint
//! with the scene, the step with the timeline, the history with the file
//! browser), and this file is only the table that runs them.
//!
//! Rules run once per `Set`, in table order, after the value is stored.
//! What a rule writes does not trigger other rules: a rule that needs a
//! follow-on writes it itself, so the chain is readable in one place.

use super::{BPath, BState};

/// One follow-up of a `Set`.
pub trait BRule: Sync {
    /// Whether this rule runs when `path` is set.
    fn wants(&self, path: &BPath) -> bool;
    /// Runs after `path` was set to `value`.
    fn after(&self, path: &BPath, value: &str, s: &mut BState);
}

/// Every rule in the app, in the order they run.
fn table() -> &'static [&'static dyn BRule] {
    use crate::v2::modal::{reader::back, spaces::pick};
    use crate::v2::part::activity::choose;
    use crate::v2::part::custom::{file::ops, time::step};
    use crate::v2::scene::viewpoint;
    &[
        &viewpoint::BViewpointRule,
        &choose::BActivityTabRule,
        &choose::BActivityPickRule,
        &step::BFrameStepRule,
        &back::BReaderOpenRule,
        &back::BReaderCloseRule,
        &pick::BSpacePickedRule,
        &ops::BSortRule,
        &ops::BNavRule,
        &ops::BPurposeRule,
        &ops::BBookmarkAddRule,
        &ops::BSelectRule,
    ]
}

/// Run every rule that wants `path`.
pub fn after_set(state: &mut BState, path: &BPath, value: &str) {
    for rule in table() {
        if rule.wants(path) {
            rule.after(path, value, state);
        }
    }
}
