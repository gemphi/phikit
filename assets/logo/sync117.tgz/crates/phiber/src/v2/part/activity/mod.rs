//! Activity Bar — Phiber-native leftmost vertical navigation.

pub mod choose;
pub mod list;
pub mod options;
pub mod set;

use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::{BView, BViewItem};

pub use list::BActivityList;
pub use set::{BActivityEntry, BActivityGroup, BActivityOptions};

#[derive(Clone, Copy, Debug)]
pub struct BActivity {
    pub host: BHostType,
}

impl BActivity {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewItem for BActivity {
    fn build(&self, s: &BState) -> BView {
        BActivityList::new().rail(s)
    }
}
