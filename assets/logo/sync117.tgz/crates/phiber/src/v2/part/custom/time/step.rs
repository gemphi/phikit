//! Transport — Blender's `screen.frame_offset` / `screen.frame_jump`.
//!
//! The timeline's buttons write a step intent (`"+1"`, `"-1"`, `"start"`,
//! `"end"`); [`BFrameStepRule`] moves the current frame inside the scene
//! range, wrapping like Blender's looping playback, and clears the intent.

use crate::v2::state::key::int_or;
use crate::v2::state::{BKey, BPath, BState, CtxKey, rule::BRule};

/// Blender's factory range, until a file sets its own.
const FACTORY_START: i32 = 1;
const FACTORY_END: i32 = 250;

/// The frame `step` lands on from `cur` inside `start..=end`.
pub fn stepped(cur: i32, start: i32, end: i32, step: &str) -> i32 {
    match step {
        "start" => start,
        "end" => end,
        d => match d.parse::<i32>() {
            Ok(d) if cur + d > end => start,
            Ok(d) if cur + d < start => end,
            Ok(d) => cur + d,
            Err(_) => cur,
        },
    }
}

/// `frame_step` → `frame`.
pub struct BFrameStepRule;

impl BRule for BFrameStepRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == CtxKey::FrameStep.path()
    }
    fn after(&self, _: &BPath, step: &str, s: &mut BState) {
        let start = int_or(s, CtxKey::FrameStart, FACTORY_START);
        let end = int_or(s, CtxKey::FrameEnd, FACTORY_END).max(start);
        let cur = int_or(s, CtxKey::Frame, start);
        s.set(CtxKey::Frame, stepped(cur, start, end, step).to_string());
        s.remove(CtxKey::FrameStep);
    }
}
