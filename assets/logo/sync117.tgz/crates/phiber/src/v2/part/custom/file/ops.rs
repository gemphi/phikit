//! File-browser operators — the reducer half of the file browser.
//! Blender ref: `space_file/file_ops.cc`.
//!
//! The view writes intents (`file.nav = "file.parent"`, `file.path =
//! "<dir>"`, `file.bookmark_add`, …); the rules here turn them into state
//! transitions. Each one is a [`BRule`], run by `state::rule` after the
//! intent is stored, and each is pure over `BState`, so it is testable
//! without GPUI.

use std::path::Path;

use super::{history, listing, sidebar};
use crate::v2::modal::splash::recent;
use crate::v2::state::val::{V_EMPTY, V_FALSE, V_MODAL_FILE_BROWSER};
use crate::v2::state::{BKey, BPath, BState, FileKey, ModalKey, rule::BRule};

/// Operator names written into `file.nav` by the nav buttons.
pub const NAV_PREVIOUS: &str = "file.previous";
pub const NAV_NEXT: &str = "file.next";
pub const NAV_PARENT: &str = "file.parent";
pub const NAV_REFRESH: &str = "file.refresh";

/// `file.sort` → the new column starts ascending (`FILE_OT_sort_column_ui_context`).
/// A repeated click uses the dedicated direction toggle instead.
pub struct BSortRule;

impl BRule for BSortRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == FileKey::Sort.path()
    }
    fn after(&self, _: &BPath, _: &str, s: &mut BState) {
        s.set(FileKey::SortInvert, V_FALSE);
    }
}

/// `file.nav` and `file.path` → the folder history (`FILE_OT_previous`,
/// `_next`, `_parent`, `_refresh`, and a typed or clicked path).
///
/// `file.path` is a navigation *request*: it records history and, when the
/// target is a file rather than a directory, promotes it to a selection
/// instead of a directory change (this is what makes clicking a `.blend`
/// row in the list open it).
pub struct BNavRule;

impl BRule for BNavRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == FileKey::Nav.path() || *path == FileKey::Path.path()
    }
    fn after(&self, path: &BPath, value: &str, s: &mut BState) {
        if *path == FileKey::Nav.path() {
            nav(s, value);
        } else {
            goto(s, value);
        }
    }
}

fn nav(s: &mut BState, op: &str) {
    match op {
        NAV_PREVIOUS => history::go_back(s),
        NAV_NEXT => history::go_forward(s),
        NAV_PARENT => {
            let current = listing::current_dir(s);
            if let Some(parent) = listing::parent_of(&current) {
                history::goto(s, &parent);
            }
        }
        // Listings are read fresh every frame, so a refresh only needs to
        // clear any stale error banner.
        NAV_REFRESH => s.set(FileKey::Error, V_EMPTY),
        _ => {}
    }
    s.set(FileKey::Nav, V_EMPTY);
}

fn goto(s: &mut BState, target: &str) {
    if target.is_empty() {
        return;
    }
    if Path::new(target).is_file() {
        // A file, not a folder: select it rather than trying to enter it.
        s.set(FileKey::Selected, target.to_string());
        s.set(FileKey::Filename, file_name_of(target));
        return;
    }
    history::goto(s, target);
    // Entering a directory clears the pending filename, as Blender does.
    s.set(FileKey::Filename, V_EMPTY);
}

fn file_name_of(path: &str) -> String {
    path.rsplit(['/', '\\']).next().unwrap_or(path).to_string()
}

/// `file.purpose` → raise the browser when no modal is up. A job requested
/// from a menu (Open…, Save As…, Import ▸ …) invokes the browser window,
/// as Blender's `WM_OT_open_mainfile` does.
pub struct BPurposeRule;

impl BRule for BPurposeRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == FileKey::Purpose.path()
    }
    fn after(&self, _: &BPath, value: &str, s: &mut BState) {
        if !value.is_empty() && s.get(ModalKey::Open).filter(|m| !m.is_empty()).is_none() {
            s.set(ModalKey::Open, V_MODAL_FILE_BROWSER);
        }
    }
}

/// `file.bookmark_add` → store the current directory in the next free slot
/// (`FILE_OT_bookmark_add`), then clear the intent.
pub struct BBookmarkAddRule;

impl BRule for BBookmarkAddRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == FileKey::BookmarkAdd.path()
    }
    fn after(&self, path: &BPath, _: &str, s: &mut BState) {
        let dir = listing::current_dir(s);
        sidebar::add_bookmark(s, &dir);
        s.remove(path);
    }
}

/// `file.selected` → a commit: record it in the welcome window's recent
/// list and dismiss whatever picker was on screen (the file browser modal,
/// or the splash itself).
pub struct BSelectRule;

impl BRule for BSelectRule {
    fn wants(&self, path: &BPath) -> bool {
        *path == FileKey::Selected.path()
    }
    fn after(&self, _: &BPath, value: &str, s: &mut BState) {
        if value.is_empty() {
            return;
        }
        recent::push_recent(s, value);
        s.set(ModalKey::Open, V_EMPTY);
    }
}
