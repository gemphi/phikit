//! File browser widget — shared by the `File` host and the modal
//! Open / Save As / Import / Export dialog.
//!
//! Split along Blender's own seams:
//!   `set`      — static tables (categories, columns, display modes, filters)
//!   keys — `state::keys::FileKey`: every `ctx.file.*` key, one variant each
//!   `kind`     — `FILE_TYPE_*` classification by extension
//!   `listing`  — real `read_dir` + sort + filter + formatting
//!   `fsmenu`   — runtime volumes and system bookmarks
//!   `history`  — the back/forward folder stacks
//!   `purpose`  — what the browser was opened for (execute-button label)
//!   `header`   — View / Select (+ Library / Catalog) menus   ┐ shared by the
//!   `path_bar` — nav · directory · search · display · filter │ modal dialog
//!   `sidebar`  — Volumes / System / Bookmarks / Recent panels│ and the hosts
//!   `execute`  — filename + Cancel / <Execute>               ┘

pub mod asset_sidebar;
pub mod execute;
pub mod fsmenu;
pub mod header;
pub mod history;
pub mod item;
pub mod kind;
pub mod list;
pub mod listing;
pub mod ops;
pub mod options;
pub mod path_bar;
pub mod preview;
pub mod purpose;
pub mod set;
pub mod sidebar;
pub mod table;
pub mod thumbs;

pub use item::BFileItem;
pub use kind::BFileKind;
pub use list::BFileList;
pub use listing::{BFileRow, BFileSort};
pub use purpose::BFilePurpose;
