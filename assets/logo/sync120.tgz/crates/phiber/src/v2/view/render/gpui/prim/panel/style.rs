//! Panel-family semantic surface and spacing helpers.
//! Used only within the `prim/panel` family.

use super::super::super::{color::resolved_gradient, ctx::BRenderCtx};
use crate::v2::theme::BSurfaceTone;
use crate::v2::view::prim::BPanelRole;
use gpui::Background;

/// Resolve the role-specific panel surface from the render-pass style.
/// (A card's own surfaces are chosen by `prim::card`.)
pub(in super::super) fn panel_bg(role: BPanelRole, c: &BRenderCtx) -> Background {
    let tone = match role {
        BPanelRole::Header | BPanelRole::Banner | BPanelRole::Toolbar => {
            BSurfaceTone::Header
        }
        // Top and bottom strips are the same chrome, so a dialog reads as one
        // surface with a strip at each end rather than four unrelated bands.
        BPanelRole::Footer => BSurfaceTone::Header,
        // A sidebar holds cards, and a card already carries its own surface.
        // Giving the column a darker tone of its own put a second background
        // behind them, which is the "dark parent" a clean space never shows.
        BPanelRole::Sidebar | BPanelRole::Body => BSurfaceTone::Body,
        BPanelRole::Viewport => BSurfaceTone::Viewport,
        BPanelRole::Modal => BSurfaceTone::Modal,
        BPanelRole::Section => BSurfaceTone::Section,
    };
    resolved_gradient(c.style.surface(tone))
}

/// Panel edge to contained controls.
pub(super) fn surface_gutter(c: &BRenderCtx) -> f32 {
    c.style.spacing.pad_md
}

/// A row's own text inset. Every row a card holds carries it, so
/// `content_inset + row_inset == surface_gutter` and a row's text lands in the
/// same column as the heading title above it (`tests/layout_gutters.rs`).
pub(crate) fn row_inset(c: &BRenderCtx) -> f32 {
    c.style.spacing.pad_sm
}

/// Card edge to the rows it holds — the gutter that, with `row_inset`, puts
/// row text under the heading title.
pub(crate) fn content_inset(c: &BRenderCtx) -> f32 {
    surface_gutter(c) - row_inset(c)
}
