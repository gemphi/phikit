//! Pane walker — tri-cell horizontal slot inside a region. Left hugs left,
//! Center flexes, Right hugs right. Uses `items_stretch` (default) so a
//! Canvas child in the Center pane can fill the full pane height; button
//! rows keep their own `h(h_button)` and still align cleanly.
//!
//! In every **canvas host** (View3D + node graphs + image/UV/seq/clip) the
//! Toolbar (Left) and Sidebar (Right) panes are rendered as absolute
//! overlays on top of the content so the canvas fills the full host area
//! (Blender's floating panel behaviour).

use super::flex::{
    BAlign, BFill, BFlex, BFlexed, BJustify, BLen, BOverflow, BPlace, BRadius, BSide, BSpace,
};
use super::{color::to_hsla, ctx::BRenderCtx, walk};
use crate::v2::pane::BPaneType;
use crate::v2::view::BView;
use crate::v2::view::render::BPaneLayout;
use gpui::prelude::*;
use gpui::{AnyElement, Hsla, hsla};

/// True when this pane lives inside a floating-side-panel host's center
/// region and should be rendered as a floating absolute overlay instead of a
/// flex slot. The host set is owned by [`BHostType::floats_side_panels`] (the
/// viewport + graphs + image/uv/seq/clip) — timelines fill content but keep
/// their docked Channels list, so they are excluded.
fn is_floating_pane(kind: BPaneType, c: &BRenderCtx) -> bool {
    // Only the CONTENT region's side panes float over the canvas. A header's
    // Left / Right panes are part of the strip: floating them turned the
    // viewport's menu bar into an absolute column stacked over the canvas,
    // which is what made the menus look detached and overlapping.
    c.host.floats_side_panels()
        && c.region == Some(crate::v2::region::BRegionType::Center)
        && matches!(kind, BPaneType::Left | BPaneType::Right)
}

/// The fill every piece of floating chrome shares — the toolbar, the sidebar
/// and the navigation gizmos. Slightly translucent so the canvas shows
/// through, matching Blender's floating panels. (`BFill::Floating` is the
/// same colour for containers built through `BFlex`.)
pub fn floating_bg(c: &BRenderCtx) -> Hsla {
    let base = to_hsla(c.style.colors.bg_panel);
    hsla(base.h, base.s, base.l, c.style.effects.floating_alpha)
}

/// How much room a floating side strip takes, including its inset from the
/// canvas edge. Overlays that sit in the same corner read this so they keep
/// their distance from the strip instead of colliding with it.
pub fn floating_strip_room(is_right: bool, c: &BRenderCtx) -> f32 {
    if !c.host.floats_side_panels() {
        return 0.0;
    }
    strip_width(is_right, c) + 3.0 * c.style.spacing.pad_sm
}

/// The content width of a floating side strip.
///
/// Collapsed it is one button wide, so the icon in it is square — a floating
/// strip is not part of the docked header grid, so sizing it by the grid
/// module left each icon in a 36x26 slot. Expanded it takes a panel's width
/// and shows its labels.
fn strip_width(is_right: bool, c: &BRenderCtx) -> f32 {
    let key = if is_right { "sidebar" } else { "tool" };
    if crate::v2::part::strip::is_expanded(c.s, c.host, key) {
        c.style.dimensions.panel_width
    } else {
        c.style.dimensions.button_height
    }
}

/// A floor for a pinned header cell that must not clip: one icon slot per
/// control it holds, plus the gaps between them.
///
/// A flex cell with a zero basis has no content size of its own to fall back
/// on, so a narrow window shrank the top bar's right-hand cell straight
/// through its icons. Counting the controls gives that cell a real minimum
/// without measuring text — everything in it is a square icon button.
fn control_floor(children: &[BView], c: &BRenderCtx) -> f32 {
    fn count(v: &BView) -> usize {
        match v {
            BView::Button(_) | BView::MenuAnchor(_) | BView::Icon { .. } => 1,
            BView::Row { children } | BView::Column { children } => {
                children.iter().map(count).sum()
            }
            BView::Panel { children, .. } => children.iter().map(count).sum(),
            BView::Card(card) => card.body.iter().chain(&card.foot).map(count).sum(),
            BView::Part { body, .. } => count(body),
            BView::Popover { anchor, .. } => count(anchor),
            BView::ZoneToggleGroup { controls } => controls.len(),
            BView::WindowControls { .. } => {
                super::atom::caption::WINDOW_CONTROLS.len()
            }
            _ => 0,
        }
    }
    let n: usize = children.iter().map(count).sum();
    if n == 0 {
        return 0.0;
    }
    let slot = c.style.dimensions.button_height;
    let gap = c.style.spacing.gap_xs;
    n as f32 * slot + (n.saturating_sub(1)) as f32 * gap
}

/// A floating side strip: the viewport's toolbar or sidebar.
struct BPaneFloat {
    side: BSide,
    /// The strip's content width (`strip_width`).
    strip: f32,
}

impl BFlexed for BPaneFloat {
    fn flex(&self, c: &BRenderCtx) -> BFlex {
        BFlex::column()
            .place(BPlace::Float { side: self.side, inset: BSpace::PadSm })
            .gap(BSpace::GapXs)
            .pad(BSpace::PadSm)
            .width(BLen::Measured(self.strip + 2.0 * c.style.spacing.pad_sm))
            .fill(BFill::Floating)
            .radius(BRadius::Role(crate::v2::theme::BStyleRole::Panel))
    }
}

/// A docked pane: a cell of its region's row.
struct BPaneCell {
    kind: BPaneType,
    in_header: bool,
    /// The header divides its width into three equal cells (the top bar).
    pinned: bool,
    /// The least width the right cell's controls fit in (`control_floor`).
    floor: f32,
    /// The pane holds a typed field (a directory, a search): it takes the
    /// strip's slack so the field can stretch, instead of hugging.
    fielded: bool,
}

impl BFlexed for BPaneCell {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        let (kind, in_header) = (self.kind, self.in_header);
        let base = BFlex::row().gap(BSpace::GapXs);
        // A strip centres its controls on its line — a button, a field, a
        // read-out all sit at the same height in every header, tool bar and
        // footer. Caps (menus, tabs) are the one exception: they run the full
        // strip height and pin themselves to its bottom edge (`self_end` in
        // the cap atoms), so the popover or pane below continues the same
        // surface. Aligning the whole pane to the end for their sake left
        // every field and icon button sitting on the baseline with nothing
        // beneath it.
        let base = if in_header {
            base.align(BAlign::Center).height(BLen::Full)
        } else {
            base.align(BAlign::Center)
        };
        let center = kind.is_center();
        if self.pinned {
            // A pinned header divides its width into three equal cells, so its
            // centre group sits on the window's centre line however wide the
            // menus beside it are.
            let cell = base.equal_cell().height(BLen::Full).min_height(BLen::Zero);
            if center {
                // Its width is purely its share of the free space, so a window
                // with none leaves it nothing and it clips.
                cell.yields()
                    .min_width(BLen::Zero)
                    .overflow(BOverflow::Clip)
                    .justify(BJustify::Center)
            } else if kind.is_right() {
                // The right cell gives nothing up: the zone toggles and window
                // controls must be reachable at any width.
                cell.keeps_size()
                    .min_width(BLen::Measured(self.floor))
                    .justify(BJustify::End)
            } else {
                // Once the centre is down to nothing the menus clip, rather
                // than pushing the right-hand controls off the screen.
                cell.yields()
                    .min_width(BLen::Zero)
                    .overflow(BOverflow::Clip)
                    .justify(BJustify::Start)
            }
        } else if center {
            // Center takes the slot so Left/Right sit at the ends; in a header
            // it centres its hugging content instead of stretching it.
            let cell = base.fills().height(BLen::Full).unclamped();
            if in_header {
                cell.justify(BJustify::Center)
            } else {
                cell
            }
        } else if kind.is_right() {
            base.keeps_size().justify(BJustify::End)
        } else if self.fielded {
            // A left pane with a field in it (the file browser's path strip)
            // is the strip's body: it grows, and the field grows with it.
            base.fills().min_width(BLen::Zero)
        } else {
            // Left pane: shrink-to-fit, never expand.
            base.keeps_size()
        }
    }
}

/// The slot a content-region Center gives each child: the whole of it.
struct BPaneStretch;

impl BFlexed for BPaneStretch {
    fn flex(&self, _c: &BRenderCtx) -> BFlex {
        BFlex::row().fills().unclamped().height(BLen::Full)
    }
}

pub fn view(kind: BPaneType, children: &[BView], c: &BRenderCtx) -> AnyElement {
    // Canvas-host Toolbar / Sidebar: an overlay on the canvas, not a flex slot.
    if is_floating_pane(kind, c) {
        let is_right = kind == BPaneType::Right;
        let side = if is_right { BSide::Right } else { BSide::Left };
        let id = format!("pane-floating-{:?}-{:?}", kind, c.host);
        let mut outer = BPaneFloat { side, strip: strip_width(is_right, c) }
            .flex(c)
            .div(c)
            .id(gpui::SharedString::from(id.clone()))
            .debug_selector(move || id.clone());
        // Everything inside a floating pane is floating chrome: it connects
        // to nothing, so its controls round fully instead of capping into an
        // edge (`atom::tab::cap`).
        let c = &c.floating();
        for ch in children {
            outer = outer.child(walk(ch, c));
        }
        return outer.into_any_element();
    }

    // A header row lays out its three panes tri-cell: Left hugs left, Center
    // takes the gap (so Left/Right land at opposite ends) but its children hug
    // and centre rather than stretch, and Right hugs right. Only a
    // content-region Center stretches its child to fill (canvas / accordion
    // stack) — the split that stops header content ballooning into full-width
    // pills or overflowing the pane.
    let in_header = matches!(
        c.region,
        Some(crate::v2::region::BRegionType::Header)
            | Some(crate::v2::region::BRegionType::ToolHeader)
    );
    let pinned = in_header && c.host.pins_header_cells();
    let floor = if pinned && kind.is_right() { control_floor(children, c) } else { 0.0 };
    let center = kind.is_center();
    let dbg = format!("pane-{:?}-{:?}", kind, c.host);
    let fielded = in_header && children.iter().any(holds_field);
    let mut el = BPaneCell { kind, in_header, pinned, floor, fielded }
        .flex(c)
        .div(c)
        .id(gpui::SharedString::from(dbg.clone()))
        .debug_selector(move || dbg.clone());
    // Only a content-region Center stretches its child to fill the slot (a
    // property stack or a canvas). A header Center hugs its content so menus
    // and the mode dropdown keep their natural width.
    let stretch_child = center && !in_header;
    for ch in children {
        if stretch_child {
            el = el.child(BPaneStretch.flex(c).div(c).child(walk(ch, c)));
        } else {
            el = el.child(walk(ch, c));
        }
    }
    el.into_any_element()
}

/// Whether a view holds a typed field somewhere in it.
fn holds_field(view: &BView) -> bool {
    match view {
        BView::SearchField { .. } => true,
        BView::Ctrl(ctrl) => matches!(
            ctrl.kind,
            crate::v2::view::prim::BCtrlKind::Text
                | crate::v2::view::prim::BCtrlKind::Search
                | crate::v2::view::prim::BCtrlKind::Path
        ),
        BView::Part { body, .. } => holds_field(body),
        BView::Row { children } | BView::Column { children } => children.iter().any(holds_field),
        _ => false,
    }
}
