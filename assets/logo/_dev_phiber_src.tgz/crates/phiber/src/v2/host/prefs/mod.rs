//! Preferences host. Blender ref: `space_userpref/space_userpref.cc:419-`.
//! Regions: WINDOW, HEADER, UI (NAV_BAR wrapping), EXECUTE.

use crate::v2::host::header;
use crate::v2::pane::{BPaneSpec, BPaneType};
use crate::v2::part::BPartType;
use crate::v2::region::{BRegionSpec, BRegionType};

// Blender declares the Preferences category list as `RGN_TYPE_NAV_BAR`, the
// same region kind Properties uses. Modelling it as a Left *pane* of the
// Center region instead gave it the pane treatment — no rail fill, Row axis,
// content-width — so the one thing that looks identical in Blender looked
// different here. It is a NavBar region, like Properties'.
static NAVBAR_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::NavBar],
}];
static CENTER_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::Panel],
}];
static EXECUTE_PANES: &[BPaneSpec] = &[BPaneSpec {
    kind: BPaneType::Center,
    parts: &[BPartType::Execute],
}];

pub static REGIONS: &[BRegionSpec] = &[
    BRegionSpec {
        kind: BRegionType::Header,
        panes: header::EDITOR,
    },
    BRegionSpec {
        kind: BRegionType::NavBar,
        panes: NAVBAR_PANES,
    },
    BRegionSpec {
        kind: BRegionType::Center,
        panes: CENTER_PANES,
    },
    BRegionSpec {
        kind: BRegionType::Execute,
        panes: EXECUTE_PANES,
    },
];
