//! Rendering workspace — one full-width Image Editor showing the render.
//!
//! Blender ref: `startup.blend`'s `Rendering` workspace, which is a single
//! `SPACE_IMAGE` area on Render Result. Splitting it into a viewport beside a
//! preview was a different workspace's shape: the point of Rendering is to
//! look at the frame, at the size it was rendered.

use crate::v2::area::{BAreaSpec, BAreaType};
use crate::v2::host::BHostType;
use crate::v2::zone::BZoneType;

pub const LABEL: &str = "Rendering";
pub const ICON: &str = "camera";

pub static AREAS: &[BAreaSpec] = &[
    BAreaSpec {
        kind: BAreaType::Top,
        zone: BZoneType::Top,
        default_host: BHostType::Topbar,
        hosts: &[BHostType::Topbar],
    },
    BAreaSpec {
        kind: BAreaType::Center,
        zone: BZoneType::Center,
        default_host: BHostType::Image,
        hosts: BHostType::SWITCHABLE,
    },
    BAreaSpec {
        kind: BAreaType::Bottom,
        zone: BZoneType::Bottom,
        default_host: BHostType::Statusbar,
        hosts: &[BHostType::Statusbar],
    },
];
