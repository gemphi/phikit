# Jobs — `phiber/v2/state`

| State | Open | Done |
|---|---|---|
| 🟡 in progress | 3 | 2 |

## Todo

- [ ] A handful of verbs: `get`, `has`, `set`, `remove` — fold `set_encoded`, `get_encoded`, `iter_keys` into them
- [ ] All keys in `state/key.rs` (move `scene/keys.rs`, `part/custom/file/keys.rs`, `part/custom/outliner/keys.rs`); add a test that rejects `BPath` literals outside `state/`
- [ ] Persistence (see `app` jobs): transient-key list lives here

## Done

- [x] `follow.rs`: declarative "when X is set, also do Y" rules (activity → modal, space picked → close picker, frame step)
- [x] Keys for view pivot / lens, frame range / fps, links, command query, collaboration

Format: one line per job, `- [ ]` open / `- [x]` done; move a line from Todo to Done when it lands, with its test.
