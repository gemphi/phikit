//! Declarative follow-ups of a `Set`: when one key changes, these rules
//! write the keys that must change with it. Each rule is a row.

use super::key::{
    K_ACTIVITY_GROUP, K_ACTIVITY_PICK, K_ACTIVITY_TAB, K_FRAME, K_FRAME_END, K_FRAME_START,
    K_FRAME_STEP, K_MODAL, K_SPACE, K_VIEW3D_VIEW, int_or,
};
use super::val::{V_EMPTY, V_MODAL_SETTINGS, V_MODAL_SPACES};
use super::{BPath, BState};

type Rule = fn(&mut BState, &str);

/// `(trigger key, rule)`.
const RULES: &[(BPath, Rule)] = &[
    // A named viewpoint is the pair of angles that define it. Clicking the
    // compass's Z cap has to change the pitch, not the yaw, so the axis caps
    // write the viewpoint and this rule turns it into both angles.
    (K_VIEW3D_VIEW, |s, name| {
        let Some((yaw, pitch)) = view_angles(name) else {
            return;
        };
        s.set(&crate::v2::scene::yaw_key(), yaw.to_string());
        s.set(&crate::v2::scene::pitch_key(), pitch.to_string());
        s.remove(&K_VIEW3D_VIEW);
    }),
    // Activity entry chosen. A grouping opens its secondary strip beside the
    // rail — clicking the same icon again closes it; everything else goes
    // straight to its declared destination.
    (K_ACTIVITY_TAB, |s, label| {
        use crate::v2::part::activity::options;
        if options::grouping_named(label).is_some() {
            if s.get(&K_ACTIVITY_GROUP) == Some(label) {
                s.remove(&K_ACTIVITY_GROUP);
            } else {
                s.set(&K_ACTIVITY_GROUP, label.to_string());
            }
            return;
        }
        s.remove(&K_ACTIVITY_GROUP);
        let entry = crate::v2::part::activity::set::ENTRIES.iter().find(|e| e.label == label);
        if let Some(modal) = entry.and_then(|e| e.modal) {
            s.set(&K_MODAL, modal);
        }
    }),
    // An option chosen from the secondary strip, as `"<entry>:<option>"`.
    (K_ACTIVITY_PICK, |s, pick| {
        use crate::v2::part::activity::{options, set::BActivityOptions};
        let Some((entry, option)) = pick.split_once(':') else { return };
        let Some(entry) = options::grouping_named(entry) else { return };
        match entry.options {
            BActivityOptions::Spaces => {
                if let Some(space) = crate::v2::space::BSpaceType::ALL
                    .iter()
                    .find(|sp| sp.label() == option)
                {
                    s.set(&K_SPACE, space.slug());
                }
            }
            // A category picked here selects the Preferences tab AND raises
            // the screen that shows it, so one click lands somewhere.
            BActivityOptions::Settings => {
                s.set(&options::prefs_tab_key(), option.to_string());
                s.set(&K_MODAL, V_MODAL_SETTINGS);
            }
            BActivityOptions::None => {}
        }
        s.remove(&K_ACTIVITY_PICK);
    }),
    // Transport: step / jump the current frame inside the scene range,
    // wrapping like Blender's looping playback.
    (K_FRAME_STEP, |s, step| {
        // Blender's factory range until a file sets its own.
        let a = int_or(s, &K_FRAME_START, 1);
        let b = int_or(s, &K_FRAME_END, 250).max(a);
        let cur = int_or(s, &K_FRAME, a);
        let next = match step {
            "start" => a,
            "end" => b,
            d => match d.parse::<i32>() {
                Ok(d) if cur + d > b => a,
                Ok(d) if cur + d < a => b,
                Ok(d) => cur + d,
                Err(_) => cur,
            },
        };
        s.set(&K_FRAME, next.to_string());
        s.remove(&K_FRAME_STEP);
    }),
    // A space picked from the Spaces dialog closes it.
    (K_SPACE, |s, _| {
        if s.get(&K_MODAL) == Some(V_MODAL_SPACES) {
            s.set(&K_MODAL, V_EMPTY);
        }
    }),
];

pub fn after_set(state: &mut BState, path: &BPath, value: &str) {
    for (key, rule) in RULES {
        if key == path {
            rule(state, value);
        }
    }
}

/// The yaw and pitch of each named viewpoint, in Blender's convention:
/// the front view looks along +Y, and the top view looks straight down.
pub fn view_angles(name: &str) -> Option<(f32, f32)> {
    Some(match name {
        "front" => (0.0, 0.0),
        "back" => (180.0, 0.0),
        "right" => (90.0, 0.0),
        "left" => (270.0, 0.0),
        "top" => (0.0, 90.0),
        "bottom" => (0.0, -90.0),
        _ => return None,
    })
}
