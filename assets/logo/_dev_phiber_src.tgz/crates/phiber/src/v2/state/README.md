# v2/state

State — a flat `HashMap<String, String>` keyed by encoded `BPath`.

Every key is `ctx.<seg>.<seg>...`. Host state naturally nests under the
host's slug: `ctx.<host>.<tail>`. Read via `state.host(host).get(tail)`.
Three-letter accessors: `get`, `set`, `has`.

## Files

| File | What it is |
|---|---|
| `action.rs` | Pure application of a rendered [`BAction`] to the single hierarchical state. |
| `area_resize.rs` | Area resize math — pure `BState` transforms. |
| `file_nav.rs` | File-browser operators — the reducer half of the file browser. |
| `follow.rs` | Declarative follow-ups of a `Set`: when one key changes, these rules write the keys that must change with it. |
| `key.rs` | Static `BPath` constants — every fixed state key in one table so raw string literals never leak into call sites. |
| `menu.rs` | Menu open/close handler — pure functions on `BState`. |
| `mod.rs` | State — a flat `HashMap<String, String>` keyed by encoded `BPath`. |
| `path.rs` | `BPath` — hierarchical state key. |
| `seed.rs` | Boot defaults — the initial state a fresh `BState` starts with. |
| `space_switch.rs` | Space switcher — pure function on `BState`. |
| `val.rs` | Static value constants — the strings written into `BState` for boolean flags, modal slugs, and Blender's factory defaults. |
| `zone_size.rs` | Zone resize math — pure `BState` transforms for zone-boundary seams. |

Status and next steps: [`jobs.md`](jobs.md).
