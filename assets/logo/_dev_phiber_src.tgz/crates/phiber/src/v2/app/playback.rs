//! Playback ticker (Blender `screen.animation_play`): while `K_PLAYING` is
//! true, advance `K_FRAME` by one at the scene's fps (looping through the
//! reducer's frame-step rule) and redraw. One ticker at a time.

use super::BPhiberApp;
use crate::v2::state::key::{K_FPS, K_FRAME_STEP, K_PLAYING, float_or};
use crate::v2::state::{action::apply_action, val::V_TRUE};
use crate::v2::view::prim::BAction;
use gpui::Context;
use std::time::Duration;

impl BPhiberApp {
    pub(crate) fn ensure_playback(&mut self, cx: &mut Context<Self>) {
        if self.playing_ticker || self.state.get(&K_PLAYING) != Some(V_TRUE) {
            return;
        }
        self.playing_ticker = true;
        let fps = float_or(&self.state, &K_FPS, 24.0).clamp(1.0, 240.0);
        let period = Duration::from_secs_f32(1.0 / fps);
        cx.spawn(async move |this, cx| loop {
            cx.background_executor().timer(period).await;
            let go_on = this
                .update(cx, |app, cx| {
                    if app.state.get(&K_PLAYING) != Some(V_TRUE) {
                        app.playing_ticker = false;
                        return false;
                    }
                    apply_action(&mut app.state, &BAction::Set(K_FRAME_STEP, "+1".into()));
                    cx.notify();
                    true
                })
                .unwrap_or(false);
            if !go_on {
                break;
            }
        })
        .detach();
    }
}
