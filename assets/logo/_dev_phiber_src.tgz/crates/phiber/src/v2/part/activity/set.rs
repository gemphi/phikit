//! Activity Bar set — global navigation entries (Phiber-native).
//! Vertical strip at the leftmost of the app.

use crate::v2::part::BPartType;
use crate::v2::spec::{BSpec, BSpecKind};

/// What an activity entry's secondary strip carries.
///
/// A primary icon is a *grouping*, so clicking it opens a second strip beside
/// the rail holding that group's options. The options are never invented
/// here: each variant names a table the app already keeps, so the strip and
/// the screen it stands for can never disagree.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BActivityOptions {
    /// The workspaces, as the space bar lists them.
    Spaces,
    /// The Preferences categories, as its nav bar lists them.
    Settings,
    /// No grouping: the entry goes straight to its destination.
    None,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BActivityEntry {
    pub icon: &'static str,
    pub label: &'static str,
    pub group: BActivityGroup,
    /// What this entry's secondary strip carries.
    pub options: BActivityOptions,
    /// When `Some`, clicking the entry opens the named modal via `K_MODAL`
    /// (values from `state::val::V_MODAL_*`). `None` entries track only the
    /// active tab state — reserved for entries whose destinations don't yet
    /// have a modal renderer wired.
    pub modal: Option<&'static str>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BActivityGroup {
    Top,
    Center,
    Bottom,
}

impl BSpec for BActivityEntry {
    fn kind(&self) -> BSpecKind {
        BSpecKind::Part(BPartType::Activity)
    }
    fn label(&self) -> &'static str {
        self.label
    }
    fn icon(&self) -> &'static str {
        self.icon
    }
}

const fn e(
    icon: &'static str,
    label: &'static str,
    group: BActivityGroup,
    modal: Option<&'static str>,
) -> BActivityEntry {
    BActivityEntry { icon, label, group, options: BActivityOptions::None, modal }
}

/// An entry that opens a secondary strip instead of going straight to a modal.
const fn grouping(
    icon: &'static str,
    label: &'static str,
    group: BActivityGroup,
    options: BActivityOptions,
) -> BActivityEntry {
    BActivityEntry { icon, label, group, options, modal: None }
}

use crate::v2::state::val::{V_MODAL_COLLAB, V_MODAL_PROFILE, V_MODAL_SPLASH};

pub static ENTRIES: &[BActivityEntry] = &[
    // Every entry opens its destination; the active tab also records which
    // entry was used (Chat / Stream share the Collaboration modal).
    e("home",     "Home",     BActivityGroup::Top,    Some(V_MODAL_SPLASH)),
    e("chat",     "Chat",     BActivityGroup::Top,    Some(V_MODAL_COLLAB)),
    grouping("grid", "Spaces", BActivityGroup::Top, BActivityOptions::Spaces),
    e("stream",   "Stream",   BActivityGroup::Center, Some(V_MODAL_COLLAB)),
    grouping("settings", "Settings", BActivityGroup::Bottom, BActivityOptions::Settings),
    e("user",     "Profile",  BActivityGroup::Bottom, Some(V_MODAL_PROFILE)),
];
