//! `BModebarList` — reads `modes_for(host)` + active mode from `ctx.mode`.

use super::set::{default_mode, mode_key, modes_for};
use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::prim::{BAction, BControl};
use crate::v2::view::{BView, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BModebarList {
    pub host: BHostType,
}

impl BModebarList {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewList for BModebarList {
    fn items(&self, s: &BState) -> Vec<BView> {
        let key = mode_key(self.host);
        let active = s.get(&key).unwrap_or_else(|| default_mode(self.host));
        modes_for(self.host)
            .iter()
            .map(|m| {
                BView::MenuItem(
                    BControl::new()
                        .with_icon(if m.label == active { "check" } else { m.icon })
                        .with_label(m.label)
                        .with_action(BAction::Set(key.clone(), m.label.to_string())),
                )
            })
            .collect()
    }
}
