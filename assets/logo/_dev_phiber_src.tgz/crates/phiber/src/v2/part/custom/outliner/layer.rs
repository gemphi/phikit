//! View Layer rows for a **loaded** `.blend` — the file's real collection
//! tree, as Blender's Outliner draws it (`tree_display_view_layer.cc`):
//!
//! ```text
//! Scene Collection
//!   ├ <child collections, recursively>   (collections before objects)
//!   └ <objects in this collection>        (sorted when SO_SKIP_SORT_ALPHA is off)
//!        └ <object data>                  (mesh rows, collapsed by default)
//! ```
//!
//! Search keeps a collection when any descendant matches and force-opens it,
//! matching `outliner_filter_tree` + `TSE_CHILDSEARCH`.

use super::type_set::BOutlineIcon;
use super::tree::{BOutlineRow, BRowKind, intern_name, is_expanded, is_expanded_or, sort_alpha};
use crate::phiphx::scene::{SceneCollection, SceneModel};
use crate::v2::state::BState;

struct Ctx<'a> {
    s: &'a BState,
    model: &'a SceneModel,
    query: &'a str,
    filtering: bool,
}

/// Every object name (mesh + extras) under `c`, recursively.
fn any_hit(c: &SceneCollection, cx: &Ctx) -> bool {
    names(c, cx).iter().any(|(n, _)| n.to_lowercase().contains(cx.query))
        || c.children.iter().any(|k| any_hit(k, cx))
}

/// `(name, icon)` of the objects directly in `c`.
fn names(c: &SceneCollection, cx: &Ctx) -> Vec<(String, &'static str)> {
    let mut out: Vec<(String, &'static str)> = c
        .object_indices
        .iter()
        .filter_map(|&i| {
            let o = cx.model.objects.get(i)?;
            let ty = cx.model.object_types.get(i).map(String::as_str).unwrap_or("MESH");
            Some((o.name.clone(), BOutlineIcon::for_object_type(ty)))
        })
        .collect();
    for n in &c.extra_names {
        let ty = if cx.model.cameras.iter().any(|k| &k.name == n) {
            "CAMERA"
        } else if cx.model.empties.iter().any(|k| &k.name == n) {
            "EMPTY"
        } else {
            "LIGHT"
        };
        let icon = BOutlineIcon::for_object_type(ty);
        out.push((n.clone(), icon));
    }
    if sort_alpha(cx.s) {
        out.sort_by_key(|(n, _)| n.to_lowercase());
    }
    out
}

/// The state id of a collection at `path` (names joined by `/` from the scene
/// collection down). The row's expansion, and its eye / camera toggles, key
/// on this — the same id `seed_view_layer` writes the file's flags to.
pub fn collection_id(path: &str) -> &'static str {
    intern_name(&format!("col/{path}"))
}

fn push_collection(rows: &mut Vec<BOutlineRow>, c: &SceneCollection, path: &str, depth: u16, cx: &Ctx) {
    if cx.filtering && !any_hit(c, cx) {
        return;
    }
    let id = collection_id(path);
    let open = cx.filtering || is_expanded(cx.s, id);
    rows.push(BOutlineRow {
        id,
        kind: if depth == 0 { BRowKind::SceneCollection } else { BRowKind::Collection },
        depth,
        icon: if depth == 0 { "scene" } else { "collection" },
        label: c.name.clone(),
        expanded: Some(open),
        // A collection row carries the eye and the camera too
        // (`outliner_draw_restrictbuts`, `TSE_LAYER_COLLECTION`): hiding it
        // hides every level under it. Toggles used to stop at the leaves.
        object: Some(id.to_string()),
        matched: false,
    });
    if !open {
        return;
    }
    for k in &c.children {
        push_collection(rows, k, &format!("{path}/{}", k.name), depth + 1, cx);
    }
    for (name, icon) in names(c, cx) {
        let hit = name.to_lowercase().contains(cx.query);
        if cx.filtering && !hit {
            continue;
        }
        let oid = intern_name(&name);
        let open = !cx.filtering && is_expanded_or(cx.s, oid, false);
        let has_data = icon == BOutlineIcon::for_object_type("MESH");
        rows.push(BOutlineRow {
            id: oid,
            kind: BRowKind::Object,
            depth: depth + 1,
            icon,
            label: name.clone(),
            expanded: has_data.then_some(open),
            object: Some(name.clone()),
            matched: cx.filtering && hit,
        });
        if has_data && open {
            rows.push(BOutlineRow {
                id: intern_name(&format!("{name}/data")),
                kind: BRowKind::Data,
                depth: depth + 2,
                icon: "mesh",
                label: name,
                expanded: None,
                object: None,
                matched: false,
            });
        }
    }
}

/// Rows for the loaded scene, or `None` when the model carries no tree
/// (e.g. a `.phx` scene) so the caller falls back to the flat list.
pub fn rows(s: &BState, model: &SceneModel, query: &str) -> Option<Vec<BOutlineRow>> {
    if model.collections.is_empty() {
        return None;
    }
    let cx = Ctx { s, model, query, filtering: !query.is_empty() };
    let mut out = Vec::new();
    for c in &model.collections {
        push_collection(&mut out, c, &c.name, 0, &cx);
    }
    Some(out)
}

/// Every object hidden by a collection above it — its own eye, or an
/// ancestor's — in the loaded model. `LAYER_COLLECTION_HIDE` inherits down the
/// tree, so this is the set the viewport subtracts before it draws.
pub fn hidden_by_collections(s: &BState, model: &SceneModel) -> std::collections::HashSet<String> {
    fn walk(c: &SceneCollection, path: &str, inherited: bool, s: &BState, model: &SceneModel, out: &mut std::collections::HashSet<String>) {
        let hidden = inherited || super::keys::is_hidden(s, collection_id(path));
        if hidden {
            out.extend(c.object_indices.iter().filter_map(|&i| model.objects.get(i)).map(|o| o.name.clone()));
            out.extend(c.extra_names.iter().cloned());
        }
        for k in &c.children {
            walk(k, &format!("{path}/{}", k.name), hidden, s, model, out);
        }
    }
    let mut out = std::collections::HashSet::new();
    for c in &model.collections {
        walk(c, &c.name, false, s, model, &mut out);
    }
    out
}
