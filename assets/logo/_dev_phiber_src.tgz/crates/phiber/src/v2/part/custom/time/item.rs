//! `BTimeItem` — the frame ruler + transport toolbar + channel body.
//!
//! Replaces the placeholder `BView::canvas(BHostType::Time)` with a real
//! declarative layout:
//!
//!   ┌─ ruler toolbar ────────────────────────────────────────────────┐
//!   │  |◀  ◀  ▶/⏸  ▶  ▶|   frame: 1                               │
//!   └────────────────────────────────────────────────────────────────┘
//!   ┌─ channel body ─────────────────────────────────────────────────┐
//!   │  Cube.location                                                  │
//!   │  Cube.rotation                                                  │
//!   │  Camera.location                                                │
//!   └────────────────────────────────────────────────────────────────┘
//!
//! State keys (global, `state::key`): `K_FRAME` (current frame),
//! `K_PLAYING` (the app's playback ticker advances `K_FRAME` while true),
//! `K_FRAME_STEP` (step / jump intent applied by the reducer).

use crate::v2::host::BHostType;
use crate::v2::part::channels::set::channels_for;
use crate::v2::state::key::{K_FRAME, K_FRAME_STEP, K_PLAYING};
use crate::v2::state::{BState, val::V_TRUE};
use crate::v2::view::{BAction, BControl, BPanelRole, BView, BViewItem};

#[derive(Clone, Copy, Debug, Default)]
pub struct BTimeItem;

impl BTimeItem {
    pub fn new() -> Self {
        Self
    }

    fn ruler_toolbar(s: &BState) -> BView {
        let playing = s.get(&K_PLAYING) == Some(V_TRUE);
        let frame_text = s.get(&K_FRAME).unwrap_or("1").to_string();

        // Transport buttons: skip-back, step-back, play/pause, step-fwd, skip-fwd.
        let skip_back = BView::Button(
            BControl::new()
                .with_icon("skip_back")
                .with_action(BAction::Set(K_FRAME_STEP, "start".into())),
        );
        let step_back = BView::Button(
            BControl::new()
                .with_icon("arrow_left")
                .with_action(BAction::Set(K_FRAME_STEP, "-1".into())),
        );
        let play_pause = BView::Button(
            BControl::new()
                .with_icon(if playing { "pause" } else { "play" })
                .with_action(BAction::Toggle(K_PLAYING)),
        );
        let step_fwd = BView::Button(
            BControl::new()
                .with_icon("arrow_right")
                .with_action(BAction::Set(K_FRAME_STEP, "+1".into())),
        );
        let skip_fwd = BView::Button(
            BControl::new()
                .with_icon("skip_forward")
                .with_action(BAction::Set(K_FRAME_STEP, "end".into())),
        );
        let frame_label = BView::label(frame_text);

        BView::panel(
            BPanelRole::Toolbar,
            vec![BView::row(vec![
                skip_back,
                step_back,
                play_pause,
                step_fwd,
                skip_fwd,
                frame_label,
            ])],
        )
    }

    fn channel_body(_s: &BState) -> BView {
        let channels = channels_for(BHostType::Time);
        let rows: Vec<BView> = channels.iter().map(|ch| BView::label(ch.label)).collect();
        BView::panel(BPanelRole::Body, rows)
    }
}

impl BViewItem for BTimeItem {
    fn build(&self, s: &BState) -> BView {
        BView::column(vec![Self::ruler_toolbar(s), Self::channel_body(s)])
    }
}

#[cfg(test)]
mod tests {
    use crate::v2::state::key::{K_FRAME, K_FRAME_STEP};
    use crate::v2::state::{BState, action::apply_action};
    use crate::v2::view::BAction;

    #[test]
    fn steps_wrap_inside_the_scene_range() {
        let mut s = BState::default();
        apply_action(&mut s, &BAction::Set(K_FRAME_STEP, "end".into()));
        assert_eq!(s.get(&K_FRAME), Some("250"));
        apply_action(&mut s, &BAction::Set(K_FRAME_STEP, "+1".into()));
        assert_eq!(s.get(&K_FRAME), Some("1"), "wraps to start");
        apply_action(&mut s, &BAction::Set(K_FRAME_STEP, "-1".into()));
        assert_eq!(s.get(&K_FRAME), Some("250"));
        assert_eq!(s.get(&K_FRAME_STEP), None);
    }
}
