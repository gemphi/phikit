//! Execute region — the filename field plus the Cancel / <Execute> pair.
//! Blender ref: `file_panels.cc:138` (`file_panel_execution_buttons_draw`).
//!
//! The execute button's label comes from the browser's purpose
//! (`FileSelectParams::title`) rather than being hardcoded to "Open", and the
//! button order follows the platform: Windows puts the affirmative action
//! first, everywhere else it comes last.

use super::{keys, listing, purpose::purpose};
use crate::v2::state::{BState, key::K_MODAL, val::V_EMPTY};
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BControl, BPanelRole};

fn filename(s: &BState) -> BView {
    let name = s
        .get(&keys::k_filename())
        .filter(|n| !n.is_empty())
        .map(str::to_string)
        .or_else(|| {
            s.get(&keys::k_selected())
                .map(|p| p.rsplit(['/', '\\']).next().unwrap_or(p).to_string())
        })
        .unwrap_or_default();
    // Typed, not a read-out: the user names the file here, and Return
    // commits it the same way the directory and search fields do.
    let key = keys::k_filename();
    let editing = crate::v2::state::edit::is_editing(s, &key);
    BView::text_field("File Name", name, editing, BAction::Set(key, String::new()))
}

/// Commit: resolve `<dir>/<filename>` and write it as the selection, which
/// the action reducer turns into an import + recent-list entry.
fn execute_btn(s: &BState) -> BView {
    let dir = listing::current_dir(s);
    let target = s
        .get(&keys::k_selected())
        .filter(|p| !p.is_empty())
        .map(str::to_string)
        .unwrap_or_else(|| {
            let name = s.get(&keys::k_filename()).unwrap_or("");
            if name.is_empty() {
                String::new()
            } else {
                listing::join(&dir, name)
            }
        });
    BView::Button(
        BControl::new()
            .with_icon("check")
            .with_label(purpose(s).exec_label())
            .with_action(BAction::Set(keys::k_selected(), target)),
    )
}

/// Where the execute region is hosted: the modal dialog (Cancel closes the
/// dialog) or an editor area (Cancel drops the purpose so the bar hides —
/// Blender's `file.cancel` in an area only clears `FileSelectParams`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BExecuteHost {
    Modal,
    Area,
}

fn cancel_btn(host: BExecuteHost) -> BView {
    let action = match host {
        BExecuteHost::Modal => BAction::Set(K_MODAL, V_EMPTY.to_string()),
        BExecuteHost::Area => BAction::Reset(keys::k_purpose()),
    };
    BView::Button(
        BControl::new()
            .with_icon("x")
            .with_label("Cancel")
            .with_action(action),
    )
}

pub fn view(s: &BState) -> BView {
    view_in(s, BExecuteHost::Modal)
}

pub fn view_in(s: &BState, host: BExecuteHost) -> BView {
    let mut children = vec![filename(s), BView::spacer()];
    if cfg!(windows) {
        children.push(execute_btn(s));
        children.push(cancel_btn(host));
    } else {
        children.push(cancel_btn(host));
        children.push(execute_btn(s));
    }
    BView::panel(BPanelRole::Footer, children)
}
