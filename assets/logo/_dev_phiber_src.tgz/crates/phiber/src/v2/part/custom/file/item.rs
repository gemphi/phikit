//! `BFileItem` — the File / Asset host body.
//!
//! Same building blocks as the modal Open / Save As dialog
//! (`modal::file_browser`), assembled in Blender's `space_file` region order:
//! ```text
//! ┌─ ui      path_bar: [← → ↑ ⟳] /dir/ [search]  [≡][⊞][⊠] [👁][⛛▾] ┐
//! ├─ tools ──────────┬─ window ──────────────────────────────────────┤
//! │ ▾ Volumes        │  Name            Modified Date          Size  │
//! │ ▾ System         │  … file rows …                                │
//! │ ▾ Bookmarks  [+] │                                               │
//! │ ▾ Recent         │                                               │
//! ├─ execute (only while a purpose is set) ──────────────────────────┤
//! │  [file name]                              [Cancel] [Open Phiber] │
//! └──────────────────────────────────────────────────────────────────┘
//! ```
//! The header (View / Select menus) is drawn by the host's Header region
//! (`part::menubar`, `FILE_HOST` / `ASSET` tables) — the modal draws its own
//! because it has no region frame.
//!
//! In the `Asset` host the tools column is the library / catalog tree and
//! the table lists assets (`BBrowseMode::Assets`).

use super::{execute, keys, path_bar, purpose, sidebar, table};
use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::{BPanelRole, BView, BViewItem};

#[derive(Clone, Copy, Debug)]
pub struct BFileItem {
    pub host: BHostType,
}

impl BFileItem {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }

    fn is_asset(&self) -> bool {
        matches!(self.host, BHostType::Asset)
    }
}

/// The execute bar is shown only while the browser is in a named-file mode
/// (Open, Save As, Import, Export) — Blender's `FILEBROWSER_PT_execute`.
fn show_execute(s: &BState) -> bool {
    s.get(&keys::k_purpose()).is_some()
        && matches!(
            purpose::purpose(s),
            purpose::BFilePurpose::Open
                | purpose::BFilePurpose::SaveAs
                | purpose::BFilePurpose::Import
                | purpose::BFilePurpose::Export
        )
}

impl BViewItem for BFileItem {
    fn build(&self, s: &BState) -> BView {
        let tools = if self.is_asset() { sidebar::asset_view(s) } else { sidebar::view(s) };
        let mut rows = vec![
            path_bar::view(s),
            BView::panel(BPanelRole::Body, vec![BView::row(vec![tools, table::view(s)])]),
        ];
        if !self.is_asset() && show_execute(s) {
            rows.push(execute::view_in(s, execute::BExecuteHost::Area));
        }
        BView::column(rows)
    }
}
