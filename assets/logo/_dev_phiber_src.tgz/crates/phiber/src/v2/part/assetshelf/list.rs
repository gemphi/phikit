//! `BAssetShelfList` — the brush tiles for the active host and mode.
//!
//! A tile is an operation: it makes its brush the active one, and reads as
//! active while it is. They used to be bare icons that did nothing.

use super::set::tiles_for;
use super::{active_brush, k_brush};
use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::prim::{BAction, BControl};
use crate::v2::view::{BView, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BAssetShelfList {
    pub host: BHostType,
}

impl BAssetShelfList {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewList for BAssetShelfList {
    fn items(&self, s: &BState) -> Vec<BView> {
        let mode = crate::v2::part::modebar::active_mode(s, self.host);
        let active = active_brush(s, self.host, mode);
        let key = k_brush(self.host);
        tiles_for(self.host, mode)
            .iter()
            .map(|t| {
                BView::Button(
                    BControl::new()
                        .with_icon(t.thumb)
                        .with_tooltip(t.label)
                        .with_active(t.label == active)
                        .with_action(BAction::Set(key.clone(), t.label.to_string())),
                )
            })
            .collect()
    }
}
