//! Outliner state keys and the small predicates that read them
//! (expansion, search, display mode, sort, per-object restrictions).

use super::set::BOutlineMode;
use super::tree::intern_name;
use crate::v2::state::{
    BPath, BState,
    val::{V_FALSE, V_TRUE},
};


pub fn k_expanded(id: &'static str) -> BPath {
    BPath::owned(vec!["outliner", "expanded", id])
}
pub fn k_search() -> BPath {
    BPath::owned(vec!["outliner", "search"])
}
pub fn k_display_mode() -> BPath {
    BPath::owned(vec!["outliner", "display_mode"])
}
pub fn k_sort_alpha() -> BPath {
    BPath::owned(vec!["outliner", "sort_alpha"])
}
/// Per-object restriction flag, e.g. `ctx.outliner.Cube.hide_render`.
pub fn k_restrict(object: &str, field: &'static str) -> BPath {
    BPath::owned(vec!["outliner", intern_name(object), field])
}

/// Whether a restriction COLUMN is shown, e.g. `ctx.outliner.col.hide_get`.
/// Blender's `show_restrict_column_*` flags, set from the Filter popover.
pub fn k_column(field: &'static str) -> BPath {
    BPath::owned(vec!["outliner", "col", field])
}

/// Open/closed state of the Outliner filter popover (OUTLINER_PT_filter).
pub fn k_filter_open() -> BPath {
    BPath::owned(vec!["outliner", "filter_open"])
}

/// Is `object` hidden in the viewport? Read by the 3D viewport, which is what
/// turns the eye icon from decoration into a working control.
pub fn is_hidden(s: &BState, object: &str) -> bool {
    s.get(&k_restrict(object, "hide_get")) == Some(V_TRUE)
        || s.get(&k_restrict(object, "hide_viewport")) == Some(V_TRUE)
}

/// What the viewport leaves out this frame: objects with their own eye
/// closed, plus everything under a closed collection. Built once per frame
/// and asked per object, so the walk over the collection tree is not repeated
/// for each of a few hundred objects.
pub struct BHidden(std::collections::HashSet<String>);

impl BHidden {
    pub fn now(s: &BState) -> Self {
        Self(crate::v2::scene::source::with_loaded(|m| {
            m.map(|m| super::layer::hidden_by_collections(s, m)).unwrap_or_default()
        }))
    }

    pub fn hides(&self, s: &BState, object: &str) -> bool {
        is_hidden(s, object) || self.0.contains(object)
    }
}

/// Expansion state with a per-row default.
///
/// Blender opens the Scene Collection and its collections but leaves objects
/// closed, so their data-blocks (mesh, materials, modifiers) stay out of the
/// way until asked for. A single "default open" rule would show a Mesh row
/// under every object on first paint.
pub fn is_expanded_or(s: &BState, id: &'static str, default_open: bool) -> bool {
    match s.get(&k_expanded(id)) {
        Some(V_FALSE) => false,
        Some(V_TRUE) => true,
        _ => default_open,
    }
}

/// Rows default to expanded; only an explicit `"false"` collapses one.
pub fn is_expanded(s: &BState, id: &'static str) -> bool {
    is_expanded_or(s, id, true)
}

pub fn search_text(s: &BState) -> String {
    s.get(&k_search()).unwrap_or("").trim().to_lowercase()
}

pub fn display_mode(s: &BState) -> BOutlineMode {
    s.get(&k_display_mode())
        .and_then(BOutlineMode::from_slug)
        .unwrap_or(BOutlineMode::ViewLayer)
}

/// Blender sorts alphabetically by default; the UI flag is the inverted
/// `SO_SKIP_SORT_ALPHA`, so only an explicit `"false"` turns sorting off.
pub fn sort_alpha(s: &BState) -> bool {
    s.get(&k_sort_alpha()) != Some(V_FALSE)
}

