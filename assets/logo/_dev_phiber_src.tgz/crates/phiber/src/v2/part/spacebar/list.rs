//! `BSpacebarList` — reads `set::spaces()` + `ctx.space`.

use super::set::spaces;
use crate::v2::space::BSpaceType;
use crate::v2::state::{BState, key::K_SPACE};
use crate::v2::view::prim::{BAction, BControl};
use crate::v2::view::{BView, BViewList};

#[derive(Clone, Copy, Debug, Default)]
pub struct BSpacebarList;

impl BSpacebarList {
    pub fn new() -> Self {
        Self
    }
}

impl BViewList for BSpacebarList {
    fn items(&self, s: &BState) -> Vec<BView> {
        let active = s
            .get(&K_SPACE)
            .and_then(BSpaceType::from_slug)
            .unwrap_or(BSpaceType::Layout);
        spaces()
            .iter()
            .map(|&sp| {
                // A labeled tab, not a flat button: the active workspace gets
                // the top-rounded gradient cap and the accent underline, and
                // hovering an inactive one previews the same cap.
                BView::Tab(
                    BControl::new()
                        .with_icon(sp.icon())
                        .with_label(sp.label())
                        .with_active(sp == active)
                        .with_action(BAction::Set(K_SPACE, sp.slug().to_string())),
                )
            })
            .collect()
    }
}
