//! `BSwitcherList` — two-column category/editor popup content.
//! Categories filter the host candidates declared by the current `BAreaSpec`;
//! host labels, icons, and actions continue to come from canonical metadata.

use super::set::{BHostCategory, category, category_key, hosts};
use crate::v2::host::{host_slug, BHostType};
use crate::v2::state::{BPath, BState, val::V_TRUE};
use crate::v2::view::prim::{BAction, BControl};
use crate::v2::view::{BView, BViewList};

#[derive(Clone, Debug)]
pub struct BSwitcherList {
    pub slot: BPath,
    pub switcher: BPath,
    pub candidates: &'static [BHostType],
    pub active: BHostType,
}

impl BSwitcherList {
    pub fn new(
        slot: BPath,
        switcher: BPath,
        candidates: &'static [BHostType],
        active: BHostType,
    ) -> Self {
        let candidates = if candidates.is_empty() {
            hosts()
        } else {
            candidates
        };
        Self {
            slot,
            switcher,
            candidates,
            active,
        }
    }

    fn has_category(&self, candidate: BHostCategory) -> bool {
        self.candidates
            .iter()
            .copied()
            .any(|host| category(host) == candidate)
    }

    fn selected_category(&self, state: &BState) -> BHostCategory {
        BHostCategory::ALL
            .iter()
            .copied()
            .find(|&candidate| {
                self.has_category(candidate)
                    && state.get(&category_key(&self.switcher, candidate)) == Some(V_TRUE)
            })
            .unwrap_or_else(|| category(self.active))
    }
}

impl BViewList for BSwitcherList {
    fn items(&self, state: &BState) -> Vec<BView> {
        let selected = self.selected_category(state);
        let categories = BHostCategory::ALL
            .iter()
            .copied()
            .filter(|&candidate| self.has_category(candidate))
            .map(|category| {
                BView::MenuItem(
                    BControl::new()
                        .with_icon(if category == selected {
                            "check"
                        } else {
                            category.icon()
                        })
                        .with_label(category.label())
                        .with_action(BAction::Open(category_key(&self.switcher, category))),
                )
            })
            .collect();
        let hosts = self
            .candidates
            .iter()
            .copied()
            .filter(|&host| category(host) == selected)
            .map(|host| {
                // The active editor type shows a check in place of its own
                // icon, matching how the mode dropdown marks its current
                // entry.
                BView::MenuItem(
                    BControl::new()
                        .with_icon(if host == self.active {
                            "check"
                        } else {
                            host.icon()
                        })
                        .with_label(host.label())
                        .with_action(BAction::Set(
                            self.slot.clone(),
                            host_slug(host).to_string(),
                        )),
                )
            })
            .collect();

        vec![BView::row(vec![
            BView::column(categories),
            BView::column(hosts),
        ])]
    }
}
