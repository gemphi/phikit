//! Operator options panel (Blender draws `WM_OT_open_mainfile`'s properties
//! in the file browser's tool-props region): **Load UI** for Open.
//! Declarative: each option is a `(label, key, default)` row.

use super::keys;
use super::purpose::{BFilePurpose, purpose};
use crate::v2::state::{BPath, BState, val::{V_FALSE, V_TRUE}};
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BControl};

pub struct BFileOption {
    pub label: &'static str,
    pub tooltip: &'static str,
    pub key: fn() -> BPath,
}

pub const OPEN_OPTIONS: &[BFileOption] = &[BFileOption {
    label: "Load UI",
    tooltip: "Load user interface setup in the .blend file",
    key: keys::k_load_ui,
}];

fn options_for(p: BFilePurpose) -> &'static [BFileOption] {
    match p {
        BFilePurpose::Open => OPEN_OPTIONS,
        _ => &[],
    }
}

/// Options default on; only an explicit `"false"` turns one off.
pub fn is_on(s: &BState, key: &BPath) -> bool {
    s.get(key) != Some(V_FALSE)
}

/// Whether opening a file should restore its workspace and 3D view.
pub fn load_ui(s: &BState) -> bool {
    is_on(s, &keys::k_load_ui())
}

fn row(s: &BState, o: &BFileOption) -> BView {
    let key = (o.key)();
    let on = is_on(s, &key);
    BView::Button(
        BControl::new()
            .with_icon(if on { "check_square" } else { "square" })
            .with_label(o.label)
            .with_tooltip(o.tooltip)
            .with_active(on)
            .with_action(BAction::Set(key, if on { V_FALSE } else { V_TRUE }.to_string())),
    )
}

/// The options panel for the current purpose, if it has any.
pub fn panel(s: &BState) -> Option<BView> {
    let p = purpose(s);
    let opts = options_for(p);
    (!opts.is_empty()).then(|| super::sidebar::panel(s, p.title(), opts.iter().map(|o| row(s, o)).collect()))
}
