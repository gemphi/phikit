use crate::v2::host::BHostType;
use crate::v2::modal::settings::{BSettingsCategory, CATEGORIES, category_for};
use crate::v2::part::panel::prefs::{BPreferenceControls, BPreferenceSection, SECTIONS};
use crate::v2::state::{BState, key::K_THEME};
use crate::v2::theme::{BPaletteName, BUiStyleDefaults, ui_style_defaults};
use crate::v2::view::{BPanelRole, BView, BViewItem};

#[derive(Clone, Copy, Debug, Default)]
pub struct BPrefsItem;

impl BPrefsItem {
    pub fn new() -> Self {
        Self
    }
}

impl BViewItem for BPrefsItem {
    fn build(&self, state: &BState) -> BView {
        let defaults = defaults_for(state);
        // The nav bar picks a category; the body shows that category's style
        // sections and nothing else. Stacking all eight at once was why the
        // sidebar selection appeared to do nothing.
        let category = active_category(state);
        let mut cards: Vec<BView> = Vec::new();
        // Themes leads with the palette itself: choosing one rewrites every
        // colour below it, so it belongs above the values it governs.
        if category.kind == BSettingsCategory::Themes {
            cards.push(palette_card(state));
        }
        let sections: Vec<BView> = SECTIONS
            .iter()
            .filter(|section| category.sections.contains(&section.title()))
            .map(|section| section_view(section, state, defaults))
            .collect();
        if !sections.is_empty() {
            cards.extend(sections);
            return BView::panel(BPanelRole::Body, cards);
        }
        if !cards.is_empty() {
            return BView::panel(BPanelRole::Body, cards);
        }
        if sections.is_empty() {
            return BView::panel(
                BPanelRole::Body,
                vec![BView::panel(
                    BPanelRole::Card,
                    vec![
                        BView::panel(
                            BPanelRole::CardHeader,
                            vec![BView::label(category.label)],
                        ),
                        BView::panel(
                            BPanelRole::Section,
                            vec![BView::label("No preferences here yet.")],
                        ),
                    ],
                )],
            );
        }
        BView::panel(BPanelRole::Body, cards)
    }
}

/// The theme picker — one row per palette, the active one lit.
fn palette_card(state: &BState) -> BView {
    use crate::v2::theme::BPaletteName;
    use crate::v2::view::prim::{BAction, BControl};

    let active = state
        .get(&K_THEME)
        .and_then(BPaletteName::from_slug)
        .unwrap_or(BPaletteName::DEFAULT);
    let mut children = vec![BView::panel(
        BPanelRole::CardHeader,
        vec![BView::label("Theme")],
    )];
    children.extend(BPaletteName::ALL.iter().map(|palette| {
        BView::panel(
            BPanelRole::Section,
            vec![
                BView::label(palette.label()),
                BView::Button(
                    BControl::new()
                        .with_icon(if *palette == active { "check" } else { "" })
                        .with_label(if *palette == active { "Active" } else { "Use" })
                        .with_active(*palette == active)
                        .with_action(BAction::Set(K_THEME, palette.slug().to_string())),
                ),
            ],
        )
    }));
    BView::panel(BPanelRole::Card, children)
}

/// The category the Preferences nav bar is showing.
fn active_category(state: &BState) -> &'static crate::v2::modal::settings::BSettingsCategorySpec {
    let label = state
        .host(BHostType::Prefs)
        .get("navbar.tab")
        .unwrap_or(CATEGORIES[0].label);
    category_for(label)
}

fn defaults_for(state: &BState) -> &'static BUiStyleDefaults {
    let palette = state
        .get(&K_THEME)
        .and_then(BPaletteName::from_slug)
        .unwrap_or(BPaletteName::DEFAULT);
    ui_style_defaults(palette)
}

fn section_view(section: BPreferenceSection, state: &BState, defaults: &BUiStyleDefaults) -> BView {
    let mut children = Vec::with_capacity(section.len() + 1);
    children.push(BView::panel(
        BPanelRole::CardHeader,
        vec![BView::label(section.title())],
    ));
    children.extend(section.rows().map(|row| {
        BView::panel(
            BPanelRole::Section,
            vec![
                BView::label(row.metadata().label),
                BPreferenceControls::for_row(row, state, defaults).view(),
            ],
        )
    }));
    BView::panel(BPanelRole::Card, children)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::part::panel::prefs::BPreferenceRow;
    use crate::v2::view::BAction;

    fn section_card<'a>(view: &'a BView, title: &str) -> &'a [BView] {
        let BView::Panel {
            role: BPanelRole::Body,
            children,
        } = view
        else {
            panic!("preferences must use a bounded body panel")
        };
        children
            .iter()
            .find_map(|card| {
                let BView::Panel {
                    role: BPanelRole::Card,
                    children,
                } = card
                else {
                    return None;
                };
                let BView::Panel {
                    role: BPanelRole::CardHeader,
                    children: header,
                } = &children[0]
                else {
                    return None;
                };
                matches!(&header[0], BView::Label { text } if text == title)
                    .then_some(&children[..])
            })
            .unwrap_or_else(|| panic!("missing preference section {title}"))
    }

    fn row_for<'a>(card: &'a [BView], label: &str) -> &'a [BView] {
        card[1..]
            .iter()
            .find_map(|row| {
                let BView::Panel {
                    role: BPanelRole::Section,
                    children,
                } = row
                else {
                    return None;
                };
                matches!(&children[0], BView::Label { text } if text == label)
                    .then_some(&children[..])
            })
            .unwrap_or_else(|| panic!("missing preference row {label}"))
    }

    /// A state showing one settings category, the way the nav bar leaves it.
    fn showing(category: &str) -> BState {
        let mut state = BState::new();
        state.set(
            &crate::v2::state::BPath::owned(vec![
                crate::v2::host::host_slug(BHostType::Prefs),
                "navbar",
                "tab",
            ]),
            category,
        );
        state
    }

    fn row_named(label: &str) -> BPreferenceRow {
        SECTIONS
            .iter()
            .flat_map(BPreferenceSection::rows)
            .find(|row| row.metadata().label == label)
            .unwrap_or_else(|| panic!("missing declaration {label}"))
    }

    #[test]
    fn a_category_shows_its_own_style_sections_and_no_others() {
        for category in CATEGORIES {
            let view = BPrefsItem::new().build(&showing(category.label));
            let BView::Panel {
                role: BPanelRole::Body,
                children,
            } = &view
            else {
                panic!("preferences must be a bounded body panel")
            };
            if category.sections.is_empty() {
                // A category with nothing to show says so, rather than
                // falling back to every section in the app.
                assert_eq!(children.len(), 1, "{}", category.label);
                continue;
            }
            // Themes carries the palette picker above the values it governs.
            let extra = usize::from(category.kind == BSettingsCategory::Themes);
            assert_eq!(
                children.len(),
                category.sections.len() + extra,
                "{}",
                category.label
            );
            for section in SECTIONS.iter().filter(|s| category.sections.contains(&s.title())) {
                assert_eq!(
                    section_card(&view, section.title()).len(),
                    section.len() + 1
                );
            }
        }
    }

    #[test]
    fn choosing_a_theme_is_offered_above_the_values_it_governs() {
        use crate::v2::theme::BPaletteName;
        let view = BPrefsItem::new().build(&showing("Themes"));
        let card = section_card(&view, "Theme");
        assert_eq!(card.len(), BPaletteName::ALL.len() + 1);
        // Exactly one palette reads as active, and it is the one in effect.
        let lit: Vec<&str> = card[1..]
            .iter()
            .filter_map(|row| {
                let BView::Panel { children, .. } = row else { return None };
                let BView::Label { text } = &children[0] else { return None };
                let BView::Button(ctl) = &children[1] else { return None };
                ctl.active.then_some(text.as_str())
            })
            .collect();
        assert_eq!(lit, vec![BPaletteName::DEFAULT.label()]);
    }

    #[test]
    fn every_style_section_belongs_to_some_category() {
        for section in SECTIONS.iter() {
            assert!(
                CATEGORIES.iter().any(|c| c.sections.contains(&section.title())),
                "no Preferences category shows the {} section",
                section.title()
            );
        }
    }

    #[test]
    fn preferences_show_effective_palette_default_and_valid_override() {
        let mut state = showing("Themes");
        state.set(&K_THEME, BPaletteName::TokyoNight.slug());
        let radius = row_named("Extra Small");
        state.set(radius.key(), "23");
        let view = BPrefsItem::new().build(&state);

        let colors = section_card(&view, "Colors");
        let background = row_for(colors, "Application Background");
        let BView::Row { children } = &background[1] else {
            panic!("preference controls must be a B-prefixed row")
        };
        let BView::Field { text } = &children[0] else {
            panic!("color control must display its effective value")
        };
        let color = row_named("Application Background");
        let expected = color
            .descriptor()
            .format_value(color.default_value(ui_style_defaults(BPaletteName::TokyoNight)))
            .expect("descriptor must format its default");
        assert_eq!(text, &expected);

        let radii = section_card(&view, "Radii");
        let xs = row_for(radii, "Extra Small");
        let BView::Row { children } = &xs[1] else {
            panic!()
        };
        assert!(matches!(&children[0], BView::Field { text } if text == "23 px"));
    }

    #[test]
    fn preference_rows_dispatch_canonical_edit_and_reset_actions() {
        let mut state = showing("Themes");
        let gradients = row_named("Gradients");
        state.set(gradients.key(), "true");
        let view = BPrefsItem::new().build(&state);
        let effects = section_card(&view, "Effects");
        let row = row_for(effects, "Gradients");
        let BView::Row { children } = &row[1] else {
            panic!()
        };
        assert!(matches!(
            &children[0],
            BView::Button(ctl)
                if matches!(&ctl.action, Some(BAction::Set(key, value)) if key == gradients.key() && value == "false")
        ));
        assert!(matches!(
            &children[1],
            BView::Button(ctl)
                if matches!(&ctl.action, Some(BAction::Reset(key)) if key == gradients.key())
        ));
    }
}
