//! `BExecuteList` — action buttons for the active host.

use super::set::actions_for;
use crate::v2::host::BHostType;
use crate::v2::state::BState;
use crate::v2::view::prim::BControl;
use crate::v2::view::{BView, BViewList};

#[derive(Clone, Copy, Debug)]
pub struct BExecuteList {
    pub host: BHostType,
}

impl BExecuteList {
    pub fn new(host: BHostType) -> Self {
        Self { host }
    }
}

impl BViewList for BExecuteList {
    fn items(&self, _s: &BState) -> Vec<BView> {
        actions_for(self.host)
            .iter()
            // The label was being passed as the icon name, so these buttons
            // painted a blank glyph and showed no text at all.
            .map(|a| {
                BView::Button(
                    BControl::new()
                        .with_icon(a.icon)
                        .with_label(a.label)
                        .with_active(a.primary),
                )
            })
            .collect()
    }
}
