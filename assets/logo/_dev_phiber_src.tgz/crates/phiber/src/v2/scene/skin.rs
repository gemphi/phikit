//! Armature deform on the GPU: phiphx batches every rigged mesh of a file into
//! [`SkinJob`]s, [`RaySkin`] runs them in one phiray pass. Declines (→ phiphx
//! CPU path) when there is no adapter or the batch is too small to pay off.

use crate::phiphx::phx::{Phx, SKIN_MIN, SkinJob, Skinner};
use phiray::kernels::{Pair, Skin, SkinParams};
use phiray::{Gpu, GpuArray, Pass};
use std::sync::{Arc, Mutex, OnceLock};

/// Below this many vertices the CPU is faster than an upload + readback.
const GPU_MIN_VERTS: usize = 20_000;

#[derive(Default)]
pub struct RaySkin {
    gpu: OnceLock<Option<Gpu>>,
    pass: Mutex<Pass>,
    /// Force the GPU even for small batches (tests).
    pub always: bool,
}

/// All jobs flattened into one set of arrays.
#[derive(Default)]
struct Batch {
    rest: Vec<[f32; 4]>,
    offsets: Vec<u32>,
    pairs: Vec<Pair>,
    bones: Vec<[f32; 16]>,
}

impl Batch {
    fn of(jobs: &[SkinJob]) -> Self {
        let mut b = Batch { offsets: vec![0], ..Default::default() };
        for j in jobs {
            let (pair_base, bone_base) = (b.pairs.len() as u32, b.bones.len() as u32);
            b.rest.extend(j.rest.iter().map(|v| [v[0], v[1], v[2], 1.0]));
            b.offsets.extend(j.offsets[1..].iter().map(|o| o + pair_base));
            b.pairs.extend(j.pairs.iter().map(|p| Pair { bone: p.bone + bone_base, weight: p.weight }));
            b.bones.extend_from_slice(&j.bones);
        }
        b
    }
}

impl RaySkin {
    /// Make every `Phx::open` in this process skin through phiray.
    pub fn install() {
        Phx::use_skinner(Some(Arc::new(RaySkin::default())));
    }

    /// Always use the GPU, whatever the batch size (tests, benchmarks).
    pub fn eager() -> Self {
        Self { always: true, ..Default::default() }
    }

    /// Whether a GPU adapter is available.
    pub fn ready(&self) -> bool {
        self.gpu().is_some()
    }

    fn gpu(&self) -> Option<&Gpu> {
        self.gpu.get_or_init(Gpu::new).as_ref()
    }
}

impl Skinner for RaySkin {
    fn run(&self, jobs: &mut [SkinJob]) -> bool {
        let n: usize = jobs.iter().map(|j| j.rest.len()).sum();
        if (n < GPU_MIN_VERTS && !self.always) || n == 0 {
            return false;
        }
        let Some(gpu) = self.gpu() else { return false };
        let Ok(mut pass) = self.pass.lock() else { return false };
        let b = Batch::of(jobs);
        let rest = GpuArray::from(gpu, &b.rest);
        let offsets = GpuArray::from(gpu, &b.offsets);
        let pairs = GpuArray::from(gpu, &b.pairs);
        let bones = GpuArray::from(gpu, &b.bones);
        let out = GpuArray::from(gpu, &vec![[0.0f32; 4]; n]);
        pass.clear();
        let params = SkinParams { min: SKIN_MIN, ..Default::default() };
        let bufs = [rest.buffer(), offsets.buffer(), pairs.buffer(), bones.buffer(), out.buffer()];
        pass.add::<Skin>(gpu, n as u32, params, &bufs);
        pass.run(gpu);
        let mut moved = out.read(gpu).into_iter();
        for j in jobs.iter_mut() {
            j.out = moved.by_ref().take(j.rest.len()).map(|v| [v[0], v[1], v[2]]).collect();
        }
        true
    }
}
