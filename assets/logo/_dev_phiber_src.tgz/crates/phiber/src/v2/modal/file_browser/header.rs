//! Re-export: the header menus live in `part::custom::file::header`.
pub use crate::v2::part::custom::file::header::{view, view_mode, BBrowseMode};
