//! About window — Blender's `WM_MT_splash_about` (`bl_operators/wm.py:3496`).
//!
//! Left column (65 %): Version, Date, Hash, Branch, Windowing Environment.
//! Right column: the app icon. Below: Release Notes · Credits · License ·
//! Website · Donate (`WM_MT_splash_about`, L3527-3540). One rounded Card per
//! block, like the welcome window.

pub mod set;

use crate::v2::modal::splash::APP_NAME;
use crate::v2::state::{BPath, BState};
use crate::v2::view::prim::{BAction, BControl, BPanelRole};
use crate::v2::view::{BView, BViewItem};

pub use set::{ABOUT_LINKS, BAboutLink};

#[derive(Clone, Copy, Debug, Default)]
pub struct BAboutModal;

fn fact(label: &str, value: String) -> BView {
    BView::row(vec![BView::label(format!("{label}: ")), BView::label(value)])
}

fn facts() -> BView {
    BView::panel(
        BPanelRole::Card,
        vec![
            BView::panel(BPanelRole::CardHeader, vec![BView::label(APP_NAME)]),
            fact("Version", env!("CARGO_PKG_VERSION").to_string()),
            fact("Date", option_env!("PHIBER_BUILD_DATE").unwrap_or("dev build").to_string()),
            fact("Hash", option_env!("PHIBER_BUILD_HASH").unwrap_or("unknown").to_string()),
            fact("Branch", option_env!("PHIBER_BUILD_BRANCH").unwrap_or("main").to_string()),
            fact("Windowing Environment", "gpui".to_string()),
        ],
    )
}

fn brand() -> BView {
    BView::panel(BPanelRole::Card, vec![BView::icon("phiber")])
}

fn links() -> BView {
    BView::panel(
        BPanelRole::Footer,
        ABOUT_LINKS
            .iter()
            .map(|l| {
                BView::Button(
                    BControl::new()
                        .with_icon(l.icon)
                        .with_label(l.label)
                        .with_action(BAction::Set(BPath::owned(vec!["link"]), l.url.to_string())),
                )
            })
            .collect(),
    )
}

impl BViewItem for BAboutModal {
    fn build(&self, _s: &BState) -> BView {
        BView::column(vec![BView::row(vec![facts(), brand()]), links()])
    }
}
