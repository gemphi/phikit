//! Help modal — Blender's Help menu items as an overlay dialog.

pub mod set;

use crate::v2::state::{BState, key::K_LINK};
use crate::v2::view::prim::{BAction, BControl, BPanelRole};
use crate::v2::view::{BView, BViewItem};

pub use set::{ACTIONS, BHelpEntry, WEB_LINKS};

#[derive(Clone, Copy, Debug, Default)]
pub struct BHelpModal;

impl BViewItem for BHelpModal {
    /// Blender's Help menu: web links open in the browser (`wm.url_open`).
    fn build(&self, _s: &BState) -> BView {
        let rows = WEB_LINKS
            .iter()
            .map(|l| {
                BView::Button(
                    BControl::new()
                        .with_icon(l.icon)
                        .with_label(l.label)
                        .with_tooltip(l.url)
                        .with_action(BAction::Set(K_LINK, l.url.to_string())),
                )
            })
            .collect();
        BView::panel(BPanelRole::Card, rows)
    }
}
