//! About window links — `WM_MT_splash_about` (`bl_operators/wm.py:3527-3540`).

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BAboutLink {
    pub icon: &'static str,
    pub label: &'static str,
    pub url: &'static str,
}

const fn l(icon: &'static str, label: &'static str, url: &'static str) -> BAboutLink {
    BAboutLink { icon, label, url }
}

pub static ABOUT_LINKS: &[BAboutLink] = &[
    l("url", "Release Notes", "https://developer.blender.org/docs/release_notes/"),
    l("url", "Credits", "https://www.blender.org/about/credits/"),
    l("url", "License", "https://www.blender.org/about/license/"),
    l("url", "Phiber Website", "https://phiace.dev"),
    l("heart", "Donate", "https://phiace.dev/support"),
];
