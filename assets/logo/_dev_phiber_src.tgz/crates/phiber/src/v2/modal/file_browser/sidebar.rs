//! Re-export: the Bookmarks sidebar lives in `part::custom::file::sidebar`.
pub use crate::v2::part::custom::file::sidebar::view;
