//! Opening a file — the progress screen.
//!
//! Blender shows the file it is reading and how far it has got; so does this,
//! over whatever is on screen, with the same card shape as every other modal.
//! It appears while an import is in flight and goes away when the scene
//! settles, so the user never stares at an unchanged viewport wondering.

use crate::v2::scene::{load_cancel_key, loaded_path_key, selected_key, view_load_progress, view_load_stage};
use crate::v2::state::{BState, val::V_TRUE};
use crate::v2::view::prim::{BAction, BControl, BPanelRole};
use crate::v2::view::{BView, BViewItem};

#[derive(Clone, Copy, Debug, Default)]
pub struct BProgressModal;

/// The file being opened, by its name alone.
fn opening(s: &BState) -> String {
    let path = s
        .get(&selected_key())
        .filter(|p| !p.is_empty())
        .or_else(|| s.get(&loaded_path_key()))
        .unwrap_or("");
    path.rsplit(['/', '\\']).next().unwrap_or(path).to_string()
}

impl BViewItem for BProgressModal {
    fn build(&self, s: &BState) -> BView {
        let fraction = view_load_progress(s).unwrap_or(0.0);
        let stage = view_load_stage(s).unwrap_or("Opening").to_string();
        BView::panel(
            BPanelRole::Body,
            vec![
                BView::row(vec![BView::icon("folder_open"), BView::label(opening(s))]),
                BView::progress_bar(fraction, stage),
                BView::row(vec![BView::Button(
                    BControl::new()
                        .with_label("Cancel")
                        .with_action(BAction::Set(load_cancel_key(), V_TRUE.to_string())),
                )]),
            ],
        )
    }
}
