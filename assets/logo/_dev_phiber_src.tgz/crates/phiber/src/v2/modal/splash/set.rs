//! Splash / Welcome set — the static columns of the welcome window.
//!
//! Blender ref: `WM_MT_splash` (`scripts/startup/bl_operators/wm.py:3431`):
//!   split 1 — col1 "New File" (templates)        │ col2 "Recent Files"
//!             (5 rows + "More…") or, with no recents, "Getting Started" links
//!   split 2 — col1 "Open…", "Recover Last Session" │ col2 "What's New", donate
//! Branding is Phiber's; structure and labels are Blender's.

use crate::v2::part::BPartType;
use crate::v2::spec::{BSpec, BSpecKind};

/// One clickable row in the welcome window.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BSplashEntry {
    pub icon: &'static str,
    pub label: &'static str,
    /// Target: a space slug for a template, a URL for a link.
    pub target: &'static str,
}

impl BSpec for BSplashEntry {
    fn kind(&self) -> BSpecKind {
        BSpecKind::Part(BPartType::Custom)
    }
    fn label(&self) -> &'static str {
        self.label
    }
    fn icon(&self) -> &'static str {
        self.icon
    }
}

const fn e(icon: &'static str, label: &'static str, target: &'static str) -> BSplashEntry {
    BSplashEntry {
        icon,
        label,
        target,
    }
}

/// Product name shown in the banner and window title.
pub const APP_NAME: &str = "Phiber";

/// "New File" column — each entry switches to the workspace it names.
/// Blender lists its app templates here (General, 2D Animation, Sculpting,
/// VFX, Video Editing); Phiber offers the workspaces it actually ships.
pub static TEMPLATES: &[BSplashEntry] = &[
    e("layout", "General", "Layout"),
    e("shader", "Shading", "Shading"),
    e("uv", "UV Editing", "UvEditing"),
    e("keyframe", "Animation", "Animation"),
    e("render", "Rendering", "Rendering"),
    e("compositor", "Compositing", "Compositing"),
    e("geonode", "Geometry Nodes", "GeometryNodes"),
    e("script", "Scripting", "Scripting"),
];

/// "Getting Started" — shown in place of the recent list when it is empty
/// (`WM_MT_splash`, L3462-3468). Labels are Blender's.
pub static GETTING_STARTED: &[BSplashEntry] = &[
    e("url", "Manual", "https://docs.blender.org/manual/"),
    e("url", "Support", "https://www.blender.org/support/"),
    e("url", "User Communities", "https://www.blender.org/community/"),
    e("url", "Get Involved", "https://www.blender.org/get-involved/"),
    e("url", "Phiber Website", "https://phiace.dev"),
];

/// Second split, right column (`WM_MT_splash`, L3485-3486).
pub static FOOT_LINKS: &[BSplashEntry] = &[
    e("url", "What's New", "https://developer.blender.org/docs/release_notes/"),
    e("heart", "Support Phiber", "https://phiace.dev/support"),
];

/// Kept for callers that still import the old name.
pub static LINKS: &[BSplashEntry] = GETTING_STARTED;

/// How many recent files the welcome window lists — `template_recent_files(rows=5)`.
pub const RECENT_ROWS: usize = 5;
/// How many recent files are remembered. Blender's `FSMENU_RECENT_MAX`.
pub const RECENT_MAX: usize = 10;

pub const EMPTY_RECENT: &str = "No recent files";
