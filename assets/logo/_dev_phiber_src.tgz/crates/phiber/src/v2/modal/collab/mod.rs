//! Collaboration modal (Activity ▸ Chat / Stream). Shows the session state
//! the collaboration service writes into `BState` — status, server and
//! peers — and nothing invented: with no service connected it says so.
//! The transport (sync, presence, chat, stream) is the service's job; this
//! view only reads `collab.*`.

use crate::v2::state::key::{K_ACTIVITY_TAB, K_COLLAB_SERVER, K_COLLAB_STATUS, P_COLLAB_PEER};
use crate::v2::state::{BPath, BState};
use crate::v2::view::prim::{BPanelRole, BRowShade, BTableCell};
use crate::v2::view::{BView, BViewItem};

/// Peer slots (`collab.peer.0` … `collab.peer.15`).
const PEER_SLOTS: [&str; 16] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"];

#[derive(Clone, Copy, Debug, Default)]
pub struct BCollabModal;

fn peers(s: &BState) -> Vec<BView> {
    PEER_SLOTS
        .iter()
        .map_while(|n| s.get(&BPath::owned(vec![P_COLLAB_PEER[0], P_COLLAB_PEER[1], n])).map(str::to_string))
        .map(|line| {
            let (name, state) = line.split_once('\t').unwrap_or((line.as_str(), ""));
            let cells = vec![BTableCell::flex(BView::label(name)), BTableCell::flex(BView::label(state))];
            BView::table_row(cells, BRowShade::Flat, None)
        })
        .collect()
}

impl BViewItem for BCollabModal {
    fn build(&self, s: &BState) -> BView {
        let tab = s.get(&K_ACTIVITY_TAB).unwrap_or("Chat");
        let status = s.get(&K_COLLAB_STATUS).unwrap_or("offline");
        let server = s.get(&K_COLLAB_SERVER).unwrap_or("no collaboration server configured");
        let mut body = vec![
            BView::label(format!("{tab} · {status}")),
            BView::label(server),
        ];
        let list = peers(s);
        if list.is_empty() {
            body.push(BView::label("No one else is in this session."));
        } else {
            body.push(BView::panel(BPanelRole::Card, list));
        }
        BView::panel(BPanelRole::Body, body)
    }
}
