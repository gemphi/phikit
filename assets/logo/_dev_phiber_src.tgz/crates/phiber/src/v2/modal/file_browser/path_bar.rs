//! Re-export: the path bar lives in `part::custom::file::path_bar` so the
//! modal dialog and the File / Asset hosts share one implementation.
pub use crate::v2::part::custom::file::path_bar::view;
