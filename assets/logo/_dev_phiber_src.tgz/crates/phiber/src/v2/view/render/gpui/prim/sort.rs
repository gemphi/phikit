use super::super::{atom::icon_path, color::to_hsla, ctx::BRenderCtx};
use crate::v2::theme::BStyleRole;
use crate::v2::view::{BAction, BColAlign, BSortDirection};
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, div, px, svg};
use std::rc::Rc;

pub struct BSort<'a> {
    pub label: &'a str,
    pub direction: Option<BSortDirection>,
    pub align: BColAlign,
    pub action: &'a BAction,
}

impl BSort<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let indicator_size = c.style.dimensions.icon_size_sm;
        // The sorted column's arrow carries the text tone, so the column the
        // list is ordered by is the one that reads; the rest stay dim.
        let indicator_tint = if self.direction.is_some() {
            c.style.colors.text
        } else {
            c.style.colors.text_dim
        };
        let mut indicator = div()
            .flex()
            .flex_shrink_0()
            .items_center()
            .justify_center()
            .size(px(indicator_size));
        if let Some(direction) = self.direction {
            let icon = match direction {
                BSortDirection::Ascending => "chevron_up",
                BSortDirection::Descending => "chevron_down",
            };
            indicator = indicator.child(
                svg()
                    .path(icon_path(icon))
                    .size(px(indicator_size))
                    .text_color(to_hsla(indicator_tint)),
            );
        }

        // Blender file-list header: label, free space, sort arrow at the far
        // end. The arrow slot is always reserved so every header lines up
        // with its column whether or not it is the sorted one.
        let mut label = div().flex_1().min_w_0().truncate().child(SharedString::from(self.label.to_string()));
        if self.align == BColAlign::End {
            label = label.text_right();
        }
        let content = div()
            .flex()
            .flex_row()
            .items_center()
            .justify_between()
            .w_full()
            .min_w_0()
            .gap(px(c.style.spacing.gap_xs))
            .child(label)
            .child(indicator);

        let handler = c.h.clone();
        let action = self.action.clone();
        let id_text = format!(
            "file-sort-{}",
            self.label.to_ascii_lowercase().replace(' ', "-")
        );
        let radius = px(c.style.radius_for(BStyleRole::MenuItem));
        div()
            .id(SharedString::from(id_text.clone()))
            .debug_selector(move || id_text.clone())
            .cursor_pointer()
            .w_full()
            .h_full()
            .flex()
            .items_center()
            // The whole column heading is the control — label, free space and
            // arrow alike — so its fill spans the column and its text keeps
            // the same inset the rows below it use.
            .px(px(super::panel::style::row_inset(c)))
            .rounded(radius)
            .overflow_hidden()
            .child(content)
            .hover(move |style| style.bg(to_hsla(c.style.colors.bg_hover)).rounded(radius))
            .on_click(move |_event: &ClickEvent, window, app| {
                (Rc::clone(&handler))(&action, window, app);
            })
            .into_any_element()
    }
}

use super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BSort<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BSort::render(self, c)
    }
}
