//! View3D top-left perspective and active-object overlay.
//!
//! Lines rendered here are fed entirely from state + Scene_Source, matching
//! Blender's viewport info line ("User Perspective" / "(Scene) Collection |
//! <object>" / "Frame N" / "Verts: V | Faces: F"). No values are hard-coded.

use super::super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::scene::{scene_metrics, scene_source};
use crate::v2::state::key::{K_FRAME, K_OBJECT, K_SCENE};
use gpui::prelude::*;
use gpui::{AnyElement, SharedString, div, px};

pub struct BOverlay;

thread_local! {
    /// Why the viewport is not drawing the scene, set by the canvas each
    /// frame: the GPU declined and the CPU painter is past its ceiling.
    static NOT_DRAWN: std::cell::Cell<Option<(super::view3d::rendered::BRayDeclined, usize)>> =
        const { std::cell::Cell::new(None) };
}

/// Record whether anything is drawing the scene this frame.
pub(super) fn note_gpu(declined: Option<super::view3d::rendered::BRayDeclined>, tris: usize) {
    NOT_DRAWN.with(|n| n.set(declined.map(|d| (d, tris))));
}

impl BOverlay {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let object = c.s.get(&K_OBJECT).unwrap_or("Cube");
        let scene = c.s.get(&K_SCENE).unwrap_or("Scene");
        let frame = c.s.get(&K_FRAME).unwrap_or("1");
        // Blender's `info_stats` counts what the view layer shows, not what
        // the file holds: a character with three hidden hair variants reads
        // 1.4M faces in Blender, and read 9M here.
        let hidden = crate::v2::part::custom::outliner::keys::BHidden::now(c.s);
        let visible: Vec<_> = scene_source(c.s)
            .into_iter()
            .filter(|o| !hidden.hides(c.s, super::view3d::object_name(o)))
            .collect();
        let (obj_count, verts, faces) = scene_metrics(&visible);
        let not_drawn = NOT_DRAWN.with(|n| n.get()).map(|(why, tris)| match why {
            super::view3d::rendered::BRayDeclined::NoGpu => format!(
                "No GPU adapter — {:.1}M triangles is more than the CPU painter will draw",
                tris as f32 / 1e6
            ),
            super::view3d::rendered::BRayDeclined::TooLarge => format!(
                "GPU declined the scene ({:.1}M triangles exceed one buffer binding) — nothing drawn",
                tris as f32 / 1e6
            ),
        });
        div()
            .flex()
            .flex_col()
            .gap(px(c.style.spacing.gap_xs))
            .text_color(to_hsla(c.style.colors.text))
            .text_size(px(c.style.typography.caption))
            .child(SharedString::from("User Perspective"))
            .child(SharedString::from(format!(
                "({scene}) Collection | {object}"
            )))
            .child(SharedString::from(format!("Frame {frame}")))
            .child(SharedString::from(format!(
                "Objects: {obj_count} | Verts: {verts} | Faces: {faces}"
            )))
            .when_some(not_drawn, |el, why| {
                el.child(
                    div()
                        .text_color(to_hsla(c.style.colors.accent))
                        .child(SharedString::from(why)),
                )
            })
            .into_any_element()
    }
}
