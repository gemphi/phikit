//! Dragging a sidebar's inner edge to widen or narrow it.
//!
//! Blender ref: `region_azones_add` — every region edge is a resize handle.
//! The zone/area seams (`zone::seam`) resize the editor grid; this one resizes
//! a panel inside a host or modal, and writes one state key.

use super::super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::state::BPath;
use gpui::prelude::*;
use gpui::{AnyElement, Context, IntoElement, Pixels, Point, Render, SharedString, Window, div, px};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

/// `ctx.sidebar.width` — the width every [`BPanelRole::Sidebar`] shares.
///
/// [`BPanelRole::Sidebar`]: crate::v2::view::prim::BPanelRole::Sidebar
pub fn k_sidebar_width() -> BPath {
    BPath::owned(vec!["sidebar", "width"])
}

/// Live drag of a panel edge: where it started and how wide the panel was.
#[derive(Clone)]
pub struct PanelDrag {
    /// The state key holding the width.
    pub key: String,
    pub start_width: f32,
    pub min: f32,
    pub max: f32,
    pub origin: Arc<Mutex<Option<Point<Pixels>>>>,
    pub dragging: Arc<AtomicBool>,
}

impl PanelDrag {
    /// Width for the pointer at `now`, clamped to the panel's range.
    pub fn width_at(&self, now: Point<Pixels>) -> f32 {
        let mut guard = self.origin.lock().unwrap();
        let origin = *guard.get_or_insert(now);
        (self.start_width + f32::from(now.x - origin.x)).clamp(self.min, self.max)
    }
}

struct BGhost {
    flag: Arc<AtomicBool>,
}

impl Drop for BGhost {
    fn drop(&mut self) {
        self.flag.store(false, Ordering::Relaxed);
    }
}

impl Render for BGhost {
    fn render(&mut self, _w: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
        div()
    }
}

/// A seam's zero-footprint overlay: `hit_width` wide, centred on the
/// boundary gap so the seam costs no layout space at all. `leading` places it
/// on the parent's trailing edge (a panel resizing itself); otherwise it hangs
/// off the leading edge (a slot resizing the boundary before it, as
/// `zone::seam` does). One geometry, so a panel edge and an area edge are the
/// same seam.
pub fn overlay(vertical: bool, leading: bool, c: &BRenderCtx) -> gpui::Div {
    let hit = px(c.style.resize.hit_width);
    let inset = px(c.style.resize.inset);
    let el = div().absolute();
    match (vertical, leading) {
        (true, true) => el.top_0().bottom_0().left(inset).w(hit),
        (true, false) => el.top_0().bottom_0().right(inset).w(hit),
        (false, true) => el.left_0().right_0().top(inset).h(hit),
        (false, false) => el.left_0().right_0().bottom(inset).h(hit),
    }
}

/// The grab strip on a panel's trailing edge.
pub fn handle(key: BPath, width: f32, c: &BRenderCtx) -> AnyElement {
    let group = SharedString::from("panel-resize");
    let line = div()
        .w(px(c.style.resize.visible_seam))
        .h_full()
        .bg(to_hsla(c.style.resize_seam_resting_color()))
        .group_hover(group.clone(), {
            let active = to_hsla(c.style.resize_seam_active_color());
            move |s| s.bg(active)
        });
    let payload = PanelDrag {
        key: key.encode(),
        start_width: width,
        min: c.style.dimensions.sidebar_min_width,
        max: c.style.dimensions.panel_width * 3.0,
        origin: Arc::new(Mutex::new(None)),
        dragging: Arc::new(AtomicBool::new(false)),
    };
    let grab = div()
        .id(SharedString::from("panel-resize-handle"))
        .debug_selector(|| "panel-resize-handle".to_string())
        .group(group)
        .flex()
        .items_center()
        .justify_center()
        .size_full()
        .occlude()
        .cursor(gpui::CursorStyle::ResizeLeftRight)
        .child(line)
        .on_drag(payload, |drag: &PanelDrag, _, _, cx| {
            drag.dragging.store(true, Ordering::Relaxed);
            let flag = drag.dragging.clone();
            cx.stop_propagation();
            cx.new(move |_| BGhost { flag })
        });
    // The seam floats over the boundary gap instead of widening it, so the
    // distance between a sidebar and the pane beside it is the same 4px a
    // zone boundary uses (`tests/chrome_geometry.rs`).
    overlay(true, false, c).child(grab).into_any_element()
}
