//! The render thread: owns the GPU and the tracer so the UI never waits.
//! The UI posts the latest scene and view; the thread keeps refining the
//! newest view and publishes each finished sample as a BGRA frame.

use super::super::mesh::BMeshPalette;
use super::scene;
use crate::v2::scene::BObject3D;
use phiray::{Camera, Gpu, Mode, Tracer};
use std::sync::mpsc::{Receiver, Sender, channel};
use std::sync::{Arc, Mutex};

pub(super) enum BRayJob {
    Scene(u64, Vec<BObject3D>, BMeshPalette),
    View(u64, Camera, u32, u32, Mode),
}

/// A published image (BGRA8, row 0 at the top).
pub(super) struct BRayFrame {
    pub seq: u64,
    pub view: u64,
    pub w: u32,
    pub h: u32,
    pub bgra: Vec<u8>,
    pub done: bool,
}

pub(super) struct BRayWorker {
    tx: Sender<BRayJob>,
    latest: Arc<Mutex<Option<BRayFrame>>>,
    /// Scene keys the GPU could not take (too large): the painter falls back.
    refused: Arc<Mutex<Vec<u64>>>,
}

impl BRayWorker {
    /// Start the thread; `None` when there is no GPU adapter.
    pub fn start() -> Option<Self> {
        let (tx, rx) = channel();
        let (ready_tx, ready_rx) = channel();
        let latest = Arc::new(Mutex::new(None));
        let refused = Arc::new(Mutex::new(Vec::new()));
        let (out, no) = (latest.clone(), refused.clone());
        std::thread::Builder::new()
            .name("phiray".into())
            .spawn(move || {
                let gpu = Gpu::new();
                let _ = ready_tx.send(gpu.is_some());
                if let Some(gpu) = gpu {
                    run(gpu, rx, out, no);
                }
            })
            .ok()?;
        ready_rx.recv().ok()?.then_some(Self { tx, latest, refused })
    }

    pub fn send(&self, job: BRayJob) {
        let _ = self.tx.send(job);
    }

    /// Whether the render thread gave up on scene `key`.
    pub fn refused(&self, key: u64) -> bool {
        self.refused.lock().is_ok_and(|r| r.contains(&key))
    }

    /// Take the newest frame if it is newer than `seq`.
    pub fn take(&self, seq: u64) -> Option<BRayFrame> {
        let mut slot = self.latest.lock().ok()?;
        if slot.as_ref().is_some_and(|f| f.seq > seq) { slot.take() } else { None }
    }
}

fn run(gpu: Gpu, rx: Receiver<BRayJob>, out: Arc<Mutex<Option<BRayFrame>>>, refused: Arc<Mutex<Vec<u64>>>) {
    let mut tracer: Option<Tracer> = None;
    let mut view: Option<(u64, Camera, u32, u32, Mode)> = None;
    let mut done = true;
    let mut seq = 0u64;
    loop {
        // Idle → block; refining → only drain what is already queued.
        let first = if done || tracer.is_none() || view.is_none() {
            match rx.recv() {
                Ok(job) => Some(job),
                Err(_) => return,
            }
        } else {
            None
        };
        for job in first.into_iter().chain(rx.try_iter()) {
            match job {
                BRayJob::Scene(key, objects, palette) => {
                    tracer = Tracer::from_scene(&gpu, scene::build(&objects, &palette));
                    if tracer.is_none()
                        && let Ok(mut r) = refused.lock()
                    {
                        r.push(key);
                    }
                    done = false;
                }
                BRayJob::View(key, cam, w, h, mode) => {
                    view = Some((key, cam, w, h, mode));
                    done = false;
                }
            }
        }
        let (Some(t), Some((key, cam, w, h, mode))) = (tracer.as_mut(), view) else { continue };
        // Workbench and the tracer are different kernels over the same scene;
        // switching re-records the pass, which is why the mode rides with the
        // view rather than the scene.
        t.set_mode(mode);
        let (sample, finished) = t.sample(&gpu, cam, w, h);
        done = finished;
        // Read back early samples, then every 4th (readback is the slow part).
        if !(finished || sample < 4 || sample % 4 == 3) {
            continue;
        }
        let mut px = t.pixels(&gpu);
        px.chunks_exact_mut(4).for_each(|p| p.swap(0, 2));
        seq += 1;
        if let Ok(mut slot) = out.lock() {
            *slot = Some(BRayFrame { seq, view: key, w, h, bgra: px, done });
        }
    }
}
