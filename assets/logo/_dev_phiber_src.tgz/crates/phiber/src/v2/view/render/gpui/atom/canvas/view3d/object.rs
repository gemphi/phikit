//! Per-object helpers shared by the mesh painter and hit labels.

use crate::v2::scene::BObject3D;

pub(in super::super::super) fn name(object: &BObject3D) -> &str {
    match object {
        BObject3D::Primitive { name, .. } | BObject3D::Loaded { name, .. } => name,
    }
}

pub(super) fn ground(object: &BObject3D) -> (f32, f32) {
    match object {
        BObject3D::Primitive { x, y, .. } => (*x, *y),
        // Loaded objects use their Blender location remapped from Z-up to our
        // (x, up, z) coord system — same mapping mesh::loaded applies. Uses
        // MESH_SCALE so hit labels sit next to the projected mesh, not off
        // in world-space.
        BObject3D::Loaded { matrix_world, .. } => (
            matrix_world[3][0] * crate::v2::scene::MESH_SCALE,
            matrix_world[3][1] * crate::v2::scene::MESH_SCALE,
        ),
    }
}


