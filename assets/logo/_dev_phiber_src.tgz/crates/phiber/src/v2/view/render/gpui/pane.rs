//! Pane walker — tri-cell horizontal slot inside a region. Left hugs left,
//! Center flexes, Right hugs right. Uses `items_stretch` (default) so a
//! Canvas child in the Center pane can fill the full pane height; button
//! rows keep their own `h(h_button)` and still align cleanly.
//!
//! In every **canvas host** (View3D + node graphs + image/UV/seq/clip) the
//! Toolbar (Left) and Sidebar (Right) panes are rendered as absolute
//! overlays on top of the content so the canvas fills the full host area
//! (Blender's floating panel behaviour).

use super::{color::to_hsla, ctx::BRenderCtx, walk};
use crate::v2::pane::BPaneType;
use crate::v2::view::BView;
use crate::v2::view::render::BPaneLayout;
use gpui::prelude::*;
use gpui::{AnyElement, Hsla, div, hsla, px};

/// True when this pane lives inside a floating-side-panel host's center
/// region and should be rendered as a floating absolute overlay instead of a
/// flex slot. The host set is owned by [`BHostType::floats_side_panels`] (the
/// viewport + graphs + image/uv/seq/clip) — timelines fill content but keep
/// their docked Channels list, so they are excluded.
fn is_floating_pane(kind: BPaneType, c: &BRenderCtx) -> bool {
    // Only the CONTENT region's side panes float over the canvas. A header's
    // Left / Right panes are part of the strip: floating them turned the
    // viewport's menu bar into an absolute column stacked over the canvas,
    // which is what made the menus look detached and overlapping.
    c.host.floats_side_panels()
        && c.region == Some(crate::v2::region::BRegionType::Center)
        && matches!(kind, BPaneType::Left | BPaneType::Right)
}

/// The fill every piece of floating chrome shares — the toolbar, the sidebar
/// and the navigation gizmos. Slightly translucent so the canvas shows
/// through, matching Blender's floating panels.
pub fn floating_bg(c: &BRenderCtx) -> Hsla {
    let base = to_hsla(c.style.colors.bg_panel);
    hsla(base.h, base.s, base.l, c.style.effects.floating_alpha)
}

/// How much room a floating side strip takes, including its inset from the
/// canvas edge. Overlays that sit in the same corner read this so they keep
/// their distance from the strip instead of colliding with it.
pub fn floating_strip_room(is_right: bool, c: &BRenderCtx) -> f32 {
    if !c.host.floats_side_panels() {
        return 0.0;
    }
    strip_width(is_right, c) + 3.0 * c.style.spacing.pad_sm
}

/// The content width of a floating side strip.
///
/// Collapsed it is one button wide, so the icon in it is square — a floating
/// strip is not part of the docked header grid, so sizing it by the grid
/// module left each icon in a 36x26 slot. Expanded it takes a panel's width
/// and shows its labels.
fn strip_width(is_right: bool, c: &BRenderCtx) -> f32 {
    let key = if is_right { "sidebar" } else { "tool" };
    if crate::v2::part::strip::is_expanded(c.s, c.host, key) {
        c.style.dimensions.panel_width
    } else {
        c.style.dimensions.button_height
    }
}

pub fn view(kind: BPaneType, children: &[BView], c: &BRenderCtx) -> AnyElement {
    // Canvas-host Toolbar / Sidebar: render as absolute overlay, not a flex slot.
    if is_floating_pane(kind, c) {
        let pad = px(c.style.spacing.pad_sm);
        let radius = px(c.style.radius_for(crate::v2::theme::BStyleRole::Panel));
        let bg = floating_bg(c);

        let is_right = kind == BPaneType::Right;
        let strip = strip_width(is_right, c);
        let id = format!("pane-floating-{:?}-{:?}", kind, c.host);
        let mut outer = div()
            .id(gpui::SharedString::from(id.clone()))
            .debug_selector(move || id.clone())
            .absolute()
            .top(pad)
            .bottom(pad)
            .flex()
            .flex_col()
            .gap(px(c.style.spacing.gap_xs))
            .p(pad)
            .w(px(strip + 2.0 * c.style.spacing.pad_sm))
            .bg(bg)
            .rounded(radius);
        outer = if is_right {
            outer.right(pad)
        } else {
            outer.left(pad)
        };
        // Everything inside a floating pane is floating chrome: it connects
        // to nothing, so its controls round fully instead of capping into an
        // edge (`atom::tab::cap`).
        let c = &c.floating();
        for ch in children {
            outer = outer.child(walk(ch, c));
        }
        return outer.into_any_element();
    }

    // A header row lays out its three panes tri-cell: Left hugs left, Center
    // flexes to occupy the gap (so Left/Right land at opposite ends) but its
    // CHILDREN hug-and-centre rather than stretch, and Right hugs right. Only
    // a content-region Center stretches its child to fill (canvas / accordion
    // stack). This split is what stops header content from ballooning into
    // full-width "pills" or overflowing the pane.
    let in_header = matches!(
        c.region,
        Some(crate::v2::region::BRegionType::Header)
            | Some(crate::v2::region::BRegionType::ToolHeader)
    );
    // Caps (menus, tabs) run the full strip height and hang from its bottom
    // edge, so the popover or pane below continues the same surface — that is
    // what `items_end` serves. A control that is shorter than the strip (an
    // icon button) centres itself instead, with `self_center` (`atom::chrome`),
    // so it sits on the strip's centre line rather than on the caps' baseline.
    let base = div()
        .flex()
        .flex_row()
        .gap(px(c.style.spacing.gap_xs));
    let base = if in_header { base.items_end().h_full() } else { base.items_center() };
    let center = kind.is_center();
    // A pinned header (the top bar) divides its width into three equal cells,
    // so its centre group sits on the window's centre line however wide the
    // menus beside it are. `flex_shrink_0` keeps a cell from dropping below
    // its content when the window is narrow — it gives up its share, not its
    // contents.
    let pinned = in_header && c.host.pins_header_cells();
    let el = if pinned {
        let cell = base.flex_grow_1().flex_shrink_0().flex_basis(gpui::Pixels::ZERO).h_full().min_h_0();
        if center {
            cell.justify_center()
        } else if kind.is_right() {
            cell.justify_end()
        } else {
            cell.justify_start()
        }
    } else if center {
        // Center still takes the flex slot so Left/Right sit at the ends, but
        // in a header it centres its (hugging) content instead of stretching
        // each child to full width.
        let center_el = base.flex_1().h_full().min_h_0().min_w_0();
        if in_header {
            center_el.justify_center()
        } else {
            center_el
        }
    } else if kind.is_right() {
        base.flex_shrink_0().justify_end()
    } else {
        // Left pane: shrink-to-fit, never expand.
        base.flex_shrink_0()
    };
    let dbg = format!("pane-{:?}-{:?}", kind, c.host);
    let mut el = el
        .id(gpui::SharedString::from(dbg.clone()))
        .debug_selector(move || dbg.clone());
    // Only a CONTENT-region Center stretches its child to fill the slot (a
    // property stack or a canvas). A header Center hugs its content so menus
    // and the mode dropdown keep their natural width.
    let stretch_child = center && !in_header;
    for ch in children {
        if stretch_child {
            el = el.child(
                div()
                    .flex()
                    .flex_1()
                    .min_w_0()
                    .h_full()
                    .min_h_0()
                    .child(walk(ch, c)),
            );
        } else {
            el = el.child(walk(ch, c));
        }
    }
    el.into_any_element()
}
