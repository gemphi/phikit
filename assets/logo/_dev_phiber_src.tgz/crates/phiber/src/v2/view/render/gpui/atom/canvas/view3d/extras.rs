//! Projects and strokes the overlay extras (camera frustums, light gizmos,
//! empties) produced by `scene::extras`, with the same world → view mapping
//! the mesh painter uses (Blender Z-up → projector (x, up, z), MESH_SCALE).

use crate::v2::scene::extras::{BExtraKind, BExtraLine, scene_extras};
use crate::v2::scene::{MESH_SCALE, project3_full, source::with_loaded};
use crate::v2::state::BState;
use gpui::{Bounds, Hsla, PathBuilder, Pixels, Window, point, px};

/// Stroke colours per kind (Blender theme: camera / light / empty wires).
#[derive(Clone, Copy)]
pub(super) struct BExtraPalette {
    pub camera: Hsla,
    pub light: Hsla,
    pub empty: Hsla,
}

impl BExtraPalette {
    pub fn from_style(c: &crate::v2::view::render::gpui::ctx::BRenderCtx) -> Self {
        use crate::v2::view::render::gpui::color::to_hsla;
        Self {
            camera: to_hsla(c.style.colors.text_dim),
            light: to_hsla(c.style.colors.accent_soft),
            empty: to_hsla(c.style.colors.text_dim),
        }
    }
}

#[derive(Clone)]
pub(super) struct BProjectedLine {
    pub a: (f32, f32),
    pub b: (f32, f32),
    pub color: Hsla,
}

/// Is this extra drawn? `hidden` is the frame's collection-hidden set,
/// built ONCE by the caller. Building it in here — a walk of the whole
/// collection tree — ran once per line, for every line, every frame.
fn visible(s: &BState, hidden: &crate::v2::part::custom::outliner::keys::BHidden, line: &BExtraLine) -> bool {
    with_loaded(|m| {
        let Some(m) = m else { return false };
        let name = match line.kind {
            BExtraKind::Camera => m.cameras.get(line.name_index).map(|c| c.name.as_str()),
            BExtraKind::Light => m.lights.get(line.name_index).map(|l| l.name.as_str()),
            BExtraKind::Empty => m.empties.get(line.name_index).map(|e| e.name.as_str()),
        };
        // Cameras, lights and empties hide with their collection too.
        name.is_some_and(|n| !hidden.hides(s, n))
    })
}

pub(super) fn project(
    s: &BState,
    yaw: f32,
    pitch: f32,
    pan: (f32, f32),
    zoom: f32,
    palette: BExtraPalette,
) -> Vec<BProjectedLine> {
    let lines = with_loaded(|m| m.map(scene_extras).unwrap_or_default());
    let to_screen = |p: [f32; 3]| {
        let (x, y, _) = project3_full(
            p[0] * MESH_SCALE,
            p[2] * MESH_SCALE,
            p[1] * MESH_SCALE,
            yaw,
            pitch,
            pan,
            zoom,
        );
        (x, y)
    };
    let hidden = crate::v2::part::custom::outliner::keys::BHidden::now(s);
    lines
        .iter()
        .filter(|l| visible(s, &hidden, l))
        .map(|l| BProjectedLine {
            a: to_screen(l.a),
            b: to_screen(l.b),
            color: match l.kind {
                BExtraKind::Camera => palette.camera,
                BExtraKind::Light => palette.light,
                BExtraKind::Empty => palette.empty,
            },
        })
        .collect()
}

pub(super) fn paint(bounds: Bounds<Pixels>, lines: &[BProjectedLine], width: f32, window: &mut Window) {
    let w = f32::from(bounds.size.width);
    let h = f32::from(bounds.size.height);
    let at = |p: (f32, f32)| {
        point(
            bounds.origin.x + px((0.5 + p.0) * w),
            bounds.origin.y + px((0.5 + p.1) * h),
        )
    };
    for line in lines {
        let mut builder = PathBuilder::stroke(px(width));
        builder.move_to(at(line.a));
        builder.line_to(at(line.b));
        if let Ok(path) = builder.build() {
            window.paint_path(path, line.color);
        }
    }
}
