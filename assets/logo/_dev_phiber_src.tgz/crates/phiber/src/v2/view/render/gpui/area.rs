//! Area walker — fixed side-column widths come from `BAreaLayout::size()`;
//! the enclosing Zone owns variable-axis fractions and height allocation.
//! Left/Right areas scroll vertically and all hosts fill their assigned slot.

use super::{color::to_hsla, ctx::BRenderCtx, surface::BCorners, walk};
use crate::v2::area::BAreaType;
use crate::v2::host::{BHostType, host_slug};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::render::BAreaLayout;
use gpui::prelude::*;
use gpui::{AnyElement, SharedString, div, px};

fn child_host(v: &BView) -> BHostType {
    if let BView::Host { kind, .. } = v {
        *kind
    } else {
        BHostType::Empty
    }
}

fn card(el: gpui::Div, c: &BRenderCtx) -> gpui::Div {
    // Full-bleed hosts fill their zone slot flush with no card chrome (no
    // border / bg tint / radius) so Blender paints the whole area directly.
    // The set is owned by `BHostType::fills_content`. Properties (Buts) is
    // also flush but keeps its own recessed surface, hence the extra arm.
    if c.host == BHostType::Buts || c.host.fills_content() {
        // Properties: zero radius, flush with workspace.
        // Content-fill hosts: no chrome — the host bg paints its own surface.
        el
    } else {
        el.bg(to_hsla(c.style.workspace_background()))
            .border(px(c.style.strokes.border))
            .border_color(to_hsla(c.style.colors.border))
            .rounded(px(c.style.radius_for(BStyleRole::Area)))
    }
}

pub fn view(kind: BAreaType, child: &BView, c: &BRenderCtx) -> AnyElement {
    let host = child_host(child);

    // The Activity rail is a fixed strip — one rail wide, never dragged — but
    // it is still a zone of the workspace, so it carries the same rounded card
    // as every other area instead of reading as a loose bar.
    if host == BHostType::Activity {
        // One rail wide normally; rail plus a panel while a primary icon's
        // secondary strip is open, since each primary icon is a grouping and
        // its options open beside it rather than over the workspace.
        let width = c.style.dimensions.activity_width
            + match crate::v2::part::activity::options::open_group(c.s) {
                Some(_) => c.style.dimensions.panel_width,
                None => 0.0,
            };
        let el = div()
            .flex()
            .flex_row()
            .w(px(width))
            .h_full()
            .min_h_0()
            .flex_shrink_0();
        // No clipping: an area's opaque child paints its own matching corners
        // (`semantic_hierarchy_surfaces`).
        return card(el, c).child(walk(child, c)).into_any_element();
    }

    let sz = kind.size();
    let mut el = div().flex().flex_col().flex_1().min_h_0();
    // The zone owns the variable-axis split. Areas only establish the fixed
    // side-column width; applying Top/Bottom heights here caused nested hosts
    // to overflow or collapse instead of filling their allocated slot.
    el = if let Some(w) = sz.width {
        el.w(px(w))
    } else {
        el.w_full().min_w_0()
    };
    el = card(el, c);

    // The host is the opaque descendant that reaches every area corner. Give
    // it explicit ownership so it can paint a compatible inner arc; clipping
    // with `overflow_hidden` is intentionally avoided because GPUI's mask is
    // rectangular rather than radius-aware.
    let child_context = c.with_corners(BCorners::ALL);
    // A side area scrolls only when its host *stacks* content that can run
    // taller than the slot — properties, an outliner, a file list. A
    // content-fill host is an editor canvas: it fills the area. Scrolling one
    // let its canvas take its natural height and left a dead band between the
    // canvas and the area's bottom edge, which is the gap under the Image
    // Editor in the Texture Paint workspace.
    if kind.is_scrollable() && !host.fills_content() {
        let id = SharedString::from(format!("area-{:?}-{}", kind, host_slug(host)));
        let scroller = div()
            .id(id)
            .flex()
            .flex_col()
            .flex_1()
            .size_full()
            .min_h_0()
            .min_w_0()
            .overflow_y_scroll()
            .child(walk(child, &child_context));
        return el.child(scroller).into_any_element();
    }
    el.child(walk(child, &child_context)).into_any_element()
}
