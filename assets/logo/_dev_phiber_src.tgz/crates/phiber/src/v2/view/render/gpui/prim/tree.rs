//! Focused tree family: indent, guide, disclosure, and row renderers.

use super::super::{
    atom,
    color::to_hsla,
    ctx::BRenderCtx,
    walk,
};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BRowShade};
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

mod disclosure;
use disclosure::BTreeDisclosure;

mod guide;
pub use guide::guides_backdrop;

pub struct BTreeIndent(pub u16);

pub struct BTreeRow<'a> {
    pub depth: u16,
    pub expanded: Option<bool>,
    pub toggle: Option<&'a BAction>,
    pub icon: &'a str,
    pub children: &'a [BView],
    pub trail: &'a [BView],
    pub shade: BRowShade,
}

struct BTreeGuide;


impl BTreeIndent {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        self.render_with_unit(c.style.dimensions.indent_unit)
    }

    /// Render with the design-system default indent unit for callers that do
    /// not have a `BRenderCtx` (e.g. snapshot helpers). Uses the same value
    /// as `DEFAULT_DIMENSIONS.indent_unit` without importing legacy defaults.
    pub fn render_default(&self) -> AnyElement {
        // 20.0 matches DEFAULT_DIMENSIONS.indent_unit; kept as a named
        // constant here so grep finds it if the default ever changes.
        const DEFAULT_INDENT_UNIT: f32 = 20.0;
        self.render_with_unit(DEFAULT_INDENT_UNIT)
    }

    fn render_with_unit(&self, unit: f32) -> AnyElement {
        div()
            .flex_shrink_0()
            .w(px(unit * self.0 as f32))
            .into_any_element()
    }
}

impl BTreeRow<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        // A tree row takes the same fills as every other selectable control
        // in the app — the strip item fill when banded, the active gradient
        // when selected. Palette-only `row_alt` / `row_selected` entries let
        // the outliner drift to shades no other region used.
        let selected = self.shade == BRowShade::Selected;
        let unit = c.style.dimensions.indent_unit;
        let mut element = div()
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .relative()
            .h(px(c.style.dimensions.row_height))
            // A row keeps its height: when the host is short the list scrolls
            // (`prim::column`) rather than squashing every row to fit.
            .flex_shrink_0()
            .rounded(px(c.style.radius_for(BStyleRole::MenuItem)))
            .pr(px(c.style.spacing.pad_md))
            .overflow_hidden()
            .text_color(to_hsla(c.style.colors.text))
            .text_size(px(c.style.typography.body));
        match self.shade {
            BRowShade::Flat => {}
            BRowShade::Alt => element = element.bg(to_hsla(c.style.host_item_hover(c.host))),
            // A list row is flat. A cap or a tab carries a sweep because it
            // is a raised surface handing its shade to the pane beside it; a
            // row in a tree is neither, so it takes the same flat selection
            // tone the file list uses and the outliner reads as one surface.
            BRowShade::Selected => {
                element = element.bg(to_hsla(c.style.colors.row_selected))
            }
        }
        if !selected {
            let hover = to_hsla(c.style.host_item_hover(c.host));
            element = element.hover(move |style| style.bg(hover));
        }

        for _ in 0..self.depth {
            element = element.child(BTreeGuide.render(c));
        }
        element = element.child(
            BTreeDisclosure {
                expanded: self.expanded,
                toggle: self.toggle,
            }
            .render(c),
        );
        element = element.child(
            div()
                .flex_shrink_0()
                .w(px(unit))
                .h_full()
                .flex()
                .items_center()
                .justify_center()
                .child(atom::icon(self.icon, c)),
        );

        // The row is the control. Blender selects an outliner item by clicking
        // anywhere on its row and lights the whole row on hover; a labelled
        // button as the name cell gave the name its own hover fill inside the
        // row's, so only the text looked hovered. The name's action lifts to
        // the row and the name draws as plain text.
        let (select, cells) = match self.children.split_first() {
            Some((BView::Button(ctl), rest)) if ctl.icon.is_none() && ctl.action.is_some() => {
                (ctl.action.clone(), std::iter::once(BView::label(ctl.label.clone().unwrap_or_default())).chain(rest.iter().cloned()).collect::<Vec<_>>())
            }
            _ => (None, self.children.to_vec()),
        };
        let mut main = div()
            .flex()
            .flex_row()
            .items_center()
            .flex_1()
            .min_w_0()
            .gap(px(c.style.spacing.gap_xs))
            .overflow_hidden();
        for child in &cells {
            main = main.child(walk(child, c));
        }
        element = element.child(main);

        if !self.trail.is_empty() {
            let mut trail = div()
                .flex()
                .flex_row()
                .items_center()
                .flex_shrink_0()
                .gap(px(c.style.spacing.gap_xs));
            for child in self.trail {
                trail = trail.child(walk(child, c));
            }
            element = element.child(trail);
        }
        let Some(action) = select else {
            return element.into_any_element();
        };
        let id = gpui::SharedString::from(atom::button::element_id("tree-row", None, &action));
        let handler = c.h.clone();
        element
            .id(id)
            .cursor_pointer()
            .on_click(move |_event, window, app| {
                (std::rc::Rc::clone(&handler))(&action, window, app);
            })
            .into_any_element()
    }
}

impl BTreeGuide {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        let unit = c.style.dimensions.indent_unit;
        let stroke = c.style.strokes.hairline;
        div()
            .flex_shrink_0()
            .relative()
            .w(px(unit))
            .h_full()
            .child(
                div()
                    .absolute()
                    .top_0()
                    .bottom_0()
                    .left(px((unit - stroke) / 2.0))
                    .w(px(stroke))
                    .bg(to_hsla(c.style.colors.sep)),
            )
            .into_any_element()
    }
}

use super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BTreeIndent {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BTreeIndent::render(self, c)
    }
}

impl BFocusedRenderer for BTreeRow<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BTreeRow::render(self, c)
    }
}
