//! The opaque base every canvas paints on, and the corners it inherits.

use super::super::super::ctx::BRenderCtx;
use gpui::{Div, Styled, div, px};

/// The opaque base every canvas paints on.
///
/// A canvas is the surface that reaches the host's corners, so it has to
/// paint them itself: GPUI's content mask is a plain rectangle, so a rounded
/// parent cannot clip a square child for us. Every canvas starts here, which
/// is why the viewport, the node editors and the image editor all stop
/// squaring off the zone they sit in.
pub fn base(c: &BRenderCtx) -> Div {
    round(div().flex_1().min_h_0().size_full().relative().overflow_hidden(), c)
}

/// Give an element the corners it inherits from its host.
pub fn round<E: Styled>(el: E, c: &BRenderCtx) -> E {
    use crate::v2::theme::BStyleRole;
    use crate::v2::view::render::gpui::surface::{
        BChildCornerSupport, BSurfaceOpacity, child_surface_plan, compatible_inner_radius,
    };
    let host = c.style.radius_for(BStyleRole::Host).min(compatible_inner_radius(
        c.style.radius_for(BStyleRole::Area),
        c.style.strokes.border,
    ));
    let plan = child_surface_plan(
        c.corners,
        BSurfaceOpacity::Opaque,
        BChildCornerSupport::Propagated,
        host,
        0.0,
    );
    if !plan.corners.any() {
        return el;
    }
    let r = px(c.style.radius_for(BStyleRole::Region).min(plan.radius));
    let el = if plan.corners.tl { el.rounded_tl(r) } else { el };
    let el = if plan.corners.tr { el.rounded_tr(r) } else { el };
    let el = if plan.corners.bl { el.rounded_bl(r) } else { el };
    if plan.corners.br { el.rounded_br(r) } else { el }
}
