//! The hierarchy lines behind a tree.

use super::super::super::{color::to_hsla, ctx::BRenderCtx};
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

/// The hierarchy lines behind a tree, spanning the whole list rather than
/// stopping at the last row. A guide drawn per row ends where the content
/// does; the branch it marks does not.
pub fn guides_backdrop(depth: u16, c: &BRenderCtx) -> AnyElement {
    let unit = c.style.dimensions.indent_unit;
    let stroke = c.style.strokes.hairline;
    let mut backdrop = div().absolute().inset_0().flex().flex_row();
    for _ in 0..depth {
        backdrop = backdrop.child(
            div()
                .flex_shrink_0()
                .relative()
                .w(px(unit))
                .h_full()
                .child(
                    div()
                        .absolute()
                        .top_0()
                        .bottom_0()
                        .left(px((unit - stroke) / 2.0))
                        .w(px(stroke))
                        .bg(to_hsla(c.style.colors.sep)),
                ),
        );
    }
    backdrop.into_any_element()
}

