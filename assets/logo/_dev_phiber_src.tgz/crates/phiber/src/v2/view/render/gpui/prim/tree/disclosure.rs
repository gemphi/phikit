//! The disclosure triangle at the head of a tree row — one indent unit
//! wide, blank for a leaf so names stay column-aligned (Blender reserves the
//! slot too), and the click that opens or closes the row.

use super::super::super::{atom, color::to_hsla, ctx::BRenderCtx};
use crate::v2::view::prim::BAction;
use gpui::prelude::*;
use gpui::{AnyElement, div, px, svg};

pub(super) struct BTreeDisclosure<'a> {
    pub(super) expanded: Option<bool>,
    pub(super) toggle: Option<&'a BAction>,
}

impl BTreeDisclosure<'_> {
    pub(super) fn render(&self, c: &BRenderCtx) -> AnyElement {
        let unit = c.style.dimensions.indent_unit;
        let cell = div()
            .flex_shrink_0()
            .w(px(unit))
            .h_full()
            .flex()
            .items_center()
            .justify_center();
        let Some(open) = self.expanded else {
            return cell.into_any_element();
        };
        let icon = if open {
            "chevron_down"
        } else {
            "chevron_right"
        };
        let glyph = || {
            svg()
                .path(format!("icons/{icon}.svg"))
                .size(px(c.style.dimensions.icon_size_sm))
                .flex_shrink_0()
                .text_color(to_hsla(c.style.colors.text_dim))
        };
        let Some(action) = self.toggle else {
            return cell.child(glyph()).into_any_element();
        };
        let handler = c.h.clone();
        let action_copy = action.clone();
        let row_id = match action {
            BAction::Set(path, _)
            | BAction::Toggle(path)
            | BAction::Open(path)
            | BAction::Reset(path) => path.segs.last().copied().unwrap_or("row"),
        };
        let selector = format!("tree-arrow-{row_id}");
        let id = gpui::SharedString::from(atom::button::element_id("tree", None, action));
        cell.id(id)
            .debug_selector(move || selector.clone())
            .cursor_pointer()
            .child(glyph())
            .on_click(move |_event, window, app| {
                (std::rc::Rc::clone(&handler))(&action_copy, window, app);
            })
            .into_any_element()
    }
}

