//! Focused renderer for `BPanelRole::Section` — property row.

use super::super::super::{ctx::BRenderCtx, walk};
use super::style::{panel_bg, row_inset};
use crate::v2::view::BView;
use crate::v2::view::prim::BPanelRole;
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

pub struct BSection<'a>(pub &'a [BView]);

impl BSection<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let selector = match self.0.first() {
            Some(BView::Label { text }) => format!("section-{text}"),
            _ => "section".to_string(),
        };
        let row_id = selector.clone();
        let mut element = div()
            .id(gpui::SharedString::from(selector.clone()))
            .debug_selector(move || selector.clone())
            .flex()
            .flex_row()
            .items_center()
            .justify_between()
            .gap(px(c.style.spacing.gap_xs))
            .w_full()
            .h(px(c.style.dimensions.row_height))
            .px(px(row_inset(c)));
        if c.host != crate::v2::host::BHostType::Buts {
            element = element.bg(panel_bg(BPanelRole::Section, c));
        }
        let last = self.0.len().saturating_sub(1);
        for (n, child) in self.0.iter().enumerate() {
            // The first and last columns are the two a reader lines up: the
            // label under the heading title, the value under its chevron.
            let slot = match n {
                0 => format!("{row_id}-label"),
                n if n == last => format!("{row_id}-value"),
                n => format!("{row_id}-{n}"),
            };
            // The value column hands its whole width to one control, so a
            // dropdown there is as wide as the label beside it rather than as
            // wide as its own longest option.
            let inner = if n == last && last > 0 { c.filling() } else { c.clone() };
            element = element.child(
                div()
                    .id(gpui::SharedString::from(slot.clone()))
                    .debug_selector(move || slot.clone())
                    .flex()
                    .flex_1()
                    .min_w_0()
                    .child(walk(child, &inner)),
            );
        }
        element.into_any_element()
    }
}

use super::super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BSection<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BSection::render(self, c)
    }
}
