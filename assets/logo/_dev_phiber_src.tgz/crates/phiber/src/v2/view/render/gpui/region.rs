//! Region walker — orientation + fixed size from resolved UI style. Painted
//! header/strip regions receive explicit host-corner ownership; ordinary
//! layout regions are transparent so their pane or specialized content owns
//! the visible surface.

use super::{
    color::resolved_gradient,
    ctx::BRenderCtx,
    surface::{BChildCornerSupport, BSurfaceOpacity, child_surface_plan, compatible_inner_radius},
    walk,
};
use crate::v2::host::BHostType;
use crate::v2::part::strip;
use crate::v2::region::BRegionType;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::render::{BAxis, BPlacement, BRegionLayout};
use gpui::prelude::*;
use gpui::{AnyElement, Background, div, px};

pub(super) const fn surface_opacity(kind: BRegionType, host: BHostType) -> BSurfaceOpacity {
    match kind {
        BRegionType::Header | BRegionType::ToolHeader if !matches!(host, BHostType::Topbar) => {
            BSurfaceOpacity::Opaque
        }
        BRegionType::NavBar
        | BRegionType::Channels
        | BRegionType::Scrubbing
        | BRegionType::AssetShelfHeader => BSurfaceOpacity::Opaque,
        // A content region paints nothing of its own, but in a content-fill
        // host it holds the canvas — and the canvas is opaque and reaches the
        // host's corners. Corner ownership has to follow what actually paints
        // there, not what the region's own background is: reading the region
        // as transparent handed the canvas no corners at all, so it squared
        // off the zone it sits in however carefully the canvas rounded itself.
        BRegionType::Center if host.fills_content() => BSurfaceOpacity::Opaque,
        _ => BSurfaceOpacity::Transparent,
    }
}

fn region_bg(kind: BRegionType, c: &BRenderCtx) -> Background {
    match kind {
        // All vertical icon rails (Properties navbar, activity bar, other
        // navbars) are transparent. Only hovered/active items carry paint so
        // the strip reads as part of the enclosing host area, not a separate
        // chrome piece.
        BRegionType::NavBar => gpui::transparent_black().into(),
        BRegionType::Channels
        | BRegionType::Scrubbing
        | BRegionType::AssetShelfHeader => resolved_gradient(c.style.strip_gradient(c.host)),
        BRegionType::Header | BRegionType::ToolHeader => {
            resolved_gradient(c.style.host_header_surface(c.host))
        }
        _ => gpui::transparent_black().into(),
    }
}


/// True when a region's content is a vertical rail. Rails are laid out the
/// same way wherever they appear — the Activity bar, the tool strip, the
/// Properties navbar and the editor side rail are one element, not four.
fn rail_region(kind: BRegionType, host: BHostType) -> bool {
    matches!(kind, BRegionType::NavBar | BRegionType::Tools)
        || (kind == BRegionType::Center && host == BHostType::Activity)
}

pub fn view(kind: BRegionType, children: &[BView], c: &BRenderCtx) -> AnyElement {
    let axis = kind.axis();
    let placement = kind.placement();
    let mut el = match (axis, placement) {
        (BAxis::Row, BPlacement::Top | BPlacement::Bottom) => {
            // Header rows: the three panes sit at the start, the centre and
            // the end. `justify_between` states that directly rather than
            // relying on the Center pane's `flex_1` to push the other two
            // apart — a host with nothing in its middle paints no Center pane
            // at all, which left its right-hand controls stranded mid-row.
            div().flex().flex_row().items_center().justify_between()
        }
        (BAxis::Row, _) => div().flex().flex_row(),
        (BAxis::Column, _) => div().flex().flex_col().items_stretch(),
    }
    .bg(region_bg(kind, c))
    .gap(px(c.style.spacing.gap_xs));

    // Every vertical strip is the topbar turned on its side, so every rail
    // region is flush horizontally — the cap owns the gap on its outer edge
    // and runs into the pane on the other (`atom::tab::cap`). Vertical
    // padding matches the adjacent content region so the first icon sits
    // level with the first accordion header, and balances the flex spacer
    // that centres the bottom cluster. Header strips stay vertically centred
    // in their fixed height.
    el = if rail_region(kind, c.host) {
        el.pt(px(c.style.rail_lead()))
            .pb(px(c.style.spacing.pad_sm))
            .gap(px(c.style.spacing.gap_none))
    } else if matches!(kind, BRegionType::Header | BRegionType::ToolHeader) {
        el.px(px(c.style.spacing.pad_md))
    } else if c.host == BHostType::Buts && kind == BRegionType::Center {
        // Properties content: small top/bottom pad so the first and last
        // accordion don't touch the edges. Right-edge padding gives the
        // content column a small gutter against the pane edge (keeps the
        // last property row from butting against the border).
        el.py(px(c.style.spacing.pad_sm))
            .pr(px(c.style.spacing.pad_sm))
    } else if kind == BRegionType::Center && c.host.fills_content() {
        // Content-fill hosts (3D viewport + every node graph + image / UV /
        // seq / clip + timelines): the content region paints wall-to-wall.
        // No outer padding —
        // the viewport's blue clear + the graph's grid must reach every
        // edge of the pane. Overlays (gizmos, toolbar, sidebar, HUD) are
        // absolute-positioned so they don't need a padded parent.
        el
    } else {
        el.p(px(c.style.spacing.pad_md))
    };

    // No rule at the header/content seam. The two surfaces already differ in
    // tone, and a line there cut every menu cap off from the popover or pane
    // that continues beneath it — with two header strips stacked, it read as
    // a bar of its own under the menus.

    let fixed_size = match kind {
        BRegionType::Header | BRegionType::ToolHeader | BRegionType::AssetShelfHeader => {
            Some(c.style.dimensions.header_height)
        }
        BRegionType::Footer | BRegionType::Execute => Some(c.style.dimensions.footer_height),
        BRegionType::Scrubbing => Some(c.style.dimensions.scrubbing_height),
        BRegionType::AssetShelf => Some(c.style.dimensions.asset_shelf_height),
        BRegionType::Tools => {
            // The tool rail shares the strip expand key: widened to the
            // sidebar label width when expanded (Blender's toolbar flyout
            // shows labels), metric width when collapsed.
            if strip::is_expanded(c.s, c.host, "tool") {
                Some(c.style.dimensions.sidebar_min_width)
            } else {
                Some(c.style.dimensions.toolbar_width)
            }
        }
        BRegionType::NavBar => {
            // Every navbar rail (Buts Properties, Prefs) shares the same
            // expand key — widened to show icon + label when expanded,
            // metric icon-only width when collapsed.
            if strip::is_expanded(c.s, c.host, "navbar") {
                Some(c.style.dimensions.sidebar_min_width)
            } else {
                Some(c.style.dimensions.navbar_width)
            }
        }
        BRegionType::UI => Some(c.style.dimensions.panel_width),
        BRegionType::Channels => Some(c.style.dimensions.channels_width),
        BRegionType::ToolProps => Some(c.style.dimensions.tool_props_width),
        _ => None,
    };
    el = if let Some(size) = fixed_size {
        match axis {
            BAxis::Row => el.h(px(size)).w_full(),
            BAxis::Column if matches!(kind, BRegionType::NavBar | BRegionType::Tools) => {
                el.w(px(size)).flex_shrink_0().h_full().min_h_0()
            }
            BAxis::Column => el.min_w(px(size)).w_full().h_full().min_h_0(),
        }
    } else {
        // Every canvas host (View3D + node graphs + image/UV/seq/clip)
        // makes its Center region a `.relative()` container so the absolute-
        // positioned Toolbar / Sidebar panes (see pane.rs) anchor to it
        // instead of falling through to the window root.
        if kind == BRegionType::Center && c.host.floats_side_panels() {
            // Only floating-side-panel hosts need a relative container so the
            // absolute Toolbar / Sidebar overlays anchor to the center region.
            el.flex_1().min_h_0().h_full().w_full().relative()
        } else {
            el.flex_1().min_h_0().h_full().w_full()
        }
    };

    let area_inner_radius =
        compatible_inner_radius(c.style.radius_for(BStyleRole::Area), c.style.strokes.border);
    let host_radius = c.style.radius_for(BStyleRole::Host).min(area_inner_radius);
    let plan = child_surface_plan(
        c.corners,
        surface_opacity(kind, c.host),
        BChildCornerSupport::Propagated,
        host_radius,
        0.0,
    );
    if plan.corners.any() {
        let radius = px(c.style.radius_for(BStyleRole::Region).min(plan.radius));
        if plan.corners.tl {
            el = el.rounded_tl(radius);
        }
        if plan.corners.tr {
            el = el.rounded_tr(radius);
        }
        if plan.corners.bl {
            el = el.rounded_bl(radius);
        }
        if plan.corners.br {
            el = el.rounded_br(radius);
        }
    }

    let dbg = format!("region-{:?}-{:?}", kind, c.host);
    let mut el = el
        .id(gpui::SharedString::from(dbg.clone()))
        .debug_selector(move || dbg.clone());
    // Tag the context with this region kind so pane children can distinguish
    // a header pane (content hugs, Left/Center/Right tri-cell) from a
    // content-region Center pane (stretches to fill).
    let child_ctx = c.with_region(kind);
    // The canvas fills the region, so a floating rail or sidebar has to be
    // painted after it — otherwise the viewport covers its own chrome.
    // Paint order, and only for the region whose panes actually float: the
    // canvas fills the Center region, so a floating rail has to be painted
    // after it. A header's side panes are ordinary strip content
    // (`pane::is_floating_pane`).
    let floats = c.host.floats_side_panels() && kind == BRegionType::Center;
    let floating = |ch: &BView| {
        floats
            && matches!(ch, BView::Pane { kind, .. } if matches!(kind, crate::v2::pane::BPaneType::Left | crate::v2::pane::BPaneType::Right))
    };
    let ordered: Vec<&BView> = children
        .iter()
        .filter(|ch| !floating(ch))
        .chain(children.iter().filter(|ch| floating(ch)))
        .collect();
    for ch in ordered {
        el = el.child(walk(ch, &child_ctx));
    }
    el.into_any_element()
}

#[cfg(test)]
mod tests;
