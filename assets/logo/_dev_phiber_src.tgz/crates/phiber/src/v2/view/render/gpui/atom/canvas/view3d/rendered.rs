//! Material Preview and Rendered shading through phiray: the scene is
//! ray traced on a render thread ([`worker`]) and painted as one image that
//! refines while the view is still. Material Preview uses the studio rig
//! (like Blender's default HDRI preview); Rendered uses the file's lights and
//! world. Falls back to the mesh painter when
//! there is no GPU adapter.

mod key;
mod scene;
mod verts;
mod worker;
pub(super) use scene::BRayLook;
#[cfg(test)]
mod tests;

use super::mesh::BMeshPalette;
use crate::v2::scene::BObject3D;
use crate::v2::scene::camera::BViewSetup;
use gpui::{Bounds, Corners, Hsla, Pixels, RenderImage, Window};
use std::cell::RefCell;
use std::hash::{Hash, Hasher};
use std::sync::Arc;
use worker::{BRayJob, BRayWorker};

/// Longest rendered side in device pixels (keeps frames interactive).
const MAX_SIDE: f32 = 1600.0;

#[derive(Default)]
struct BRayState {
    worker: Option<Option<BRayWorker>>,
    scene: u64,
    view: u64,
    /// Shown image: (frame seq, view key, finished, image).
    image: Option<(u64, u64, bool, Arc<RenderImage>)>,
}

thread_local! {
    static STATE: RefCell<BRayState> = RefCell::new(BRayState::default());
}

/// What the painter needs this frame.
#[derive(Clone, Copy)]
pub(super) struct BRayView {
    pub yaw: f32,
    pub pitch: f32,
    pub pan: (f32, f32),
    pub zoom: f32,
    pub setup: BViewSetup,
    pub sky: Hsla,
    pub grid: Hsla,
    /// Material Preview: studio lighting, file lights and world ignored.
    pub studio: bool,
    /// Wireframe: the wire's colour.
    pub wire: Hsla,
    /// Which phiray kernel draws it — Workbench for Solid, the tracer
    /// otherwise. Solid finishes in one dispatch, so it never re-polls.
    pub mode: phiray::Mode,
}

/// Why the GPU is not drawing this frame, when it is not.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in super::super::super) enum BRayDeclined {
    /// No adapter at all: the CPU painter is the only renderer.
    NoGpu,
    /// The scene exceeds what this device can bind, even chunked.
    TooLarge,
}

/// Hand `scene` to the render thread when it changed. `Err` → the GPU is not
/// drawing, and says why, so the fallback can decide what it can honestly do.
pub(super) fn prepare(scene: &[BObject3D], palette: &BMeshPalette) -> Result<(), BRayDeclined> {
    STATE.with(|s| {
        let mut s = s.borrow_mut();
        s.worker.get_or_insert_with(BRayWorker::start);
        let key = key::key(scene, palette);
        let fresh = key != s.scene;
        let Some(Some(w)) = s.worker.as_ref() else { return Err(BRayDeclined::NoGpu) };
        if fresh {
            w.send(BRayJob::Scene(key, scene.to_vec(), *palette));
        }
        let refused = w.refused(key);
        if fresh {
            s.scene = key;
            s.view = 0;
        }
        if refused { Err(BRayDeclined::TooLarge) } else { Ok(()) }
    })
}

/// Post the view, then paint the newest image into `bounds`.
pub(super) fn paint(bounds: Bounds<Pixels>, view: BRayView, window: &mut Window) {
    let (bw, bh) = (f32::from(bounds.size.width), f32::from(bounds.size.height));
    if bw < 1.0 || bh < 1.0 {
        return;
    }
    let dpr = window.scale_factor();
    let fit = (MAX_SIDE / (bw.max(bh) * dpr)).min(1.0);
    let (w, h) = ((bw * dpr * fit) as u32, (bh * dpr * fit) as u32);
    let look = BRayLook {
        sky: view.sky,
        grid: view.grid,
        world: if view.studio { None } else { crate::v2::scene::source::with_loaded(|m| m.map(|m| m.world.horizon_color)) },
        lights: if view.studio { Vec::new() } else { crate::v2::scene::scene_lights() },
        wire: (view.mode == phiray::Mode::Wire).then_some(view.wire),
    };
    let cam = scene::camera(view.yaw, view.pitch, view.pan, view.zoom, view.setup, bw / bh, &look);
    let (image, settled) = STATE.with(|s| {
        let mut s = s.borrow_mut();
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        (s.scene, w, h, view.mode as u32, bytemuck::bytes_of(&cam)).hash(&mut hasher);
        let key = hasher.finish();
        let Some(Some(worker)) = s.worker.as_ref() else { return (None, true) };
        if key != s.view {
            worker.send(BRayJob::View(key, cam, w, h, view.mode));
        }
        let seq = s.image.as_ref().map_or(0, |i| i.0);
        let frame = worker.take(seq);
        s.view = key;
        if let Some(f) = frame
            && let Some(buf) = image::RgbaImage::from_raw(f.w, f.h, f.bgra)
        {
            let img = Arc::new(RenderImage::new(smallvec::smallvec![image::Frame::new(buf)]));
            if let Some((.., old)) = s.image.replace((f.seq, f.view, f.done, img)) {
                let _ = window.drop_image(old);
            }
        }
        match &s.image {
            Some((_, v, done, img)) => (Some(img.clone()), *done && *v == key),
            None => (None, false),
        }
    });
    if let Some(img) = image {
        let _ = window.paint_image(bounds, bounds, Corners::default(), img, 0, false);
    }
    // Poll for new samples until the current view is fully refined.
    if !settled {
        window.request_animation_frame();
    }
}
