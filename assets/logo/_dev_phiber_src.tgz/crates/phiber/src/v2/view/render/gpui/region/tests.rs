//! Which regions own a host's corners.
//!
//! A region claims a corner only when something inside it actually paints
//! there; the host keeps the rest.

use super::{BSurfaceOpacity, surface_opacity};
use crate::v2::host::BHostType;
use crate::v2::region::BRegionType;

#[test]
fn only_intentionally_painted_regions_claim_host_corners() {
    for kind in [
        BRegionType::Footer,
        BRegionType::Tools,
        BRegionType::ToolProps,
        BRegionType::UI,
        BRegionType::AssetShelf,
    ] {
        assert_eq!(
            surface_opacity(kind, BHostType::View3D),
            BSurfaceOpacity::Transparent
        );
    }
    assert_eq!(
        surface_opacity(BRegionType::Header, BHostType::View3D),
        BSurfaceOpacity::Opaque
    );
    assert_eq!(
        surface_opacity(BRegionType::Header, BHostType::Topbar),
        BSurfaceOpacity::Transparent
    );
    assert_eq!(
        surface_opacity(BRegionType::NavBar, BHostType::Buts),
        BSurfaceOpacity::Opaque
    );
}

#[test]
fn a_canvas_host_hands_its_corners_to_the_region_that_holds_the_canvas() {
    // The canvas is what paints to the edges, so the region around it
    // owns the corners on its behalf; a host that stacks content keeps
    // them itself, because nothing inside reaches them.
    assert_eq!(
        surface_opacity(BRegionType::Center, BHostType::View3D),
        BSurfaceOpacity::Opaque
    );
    assert_eq!(
        surface_opacity(BRegionType::Center, BHostType::Shader),
        BSurfaceOpacity::Opaque
    );
    assert_eq!(
        surface_opacity(BRegionType::Center, BHostType::Buts),
        BSurfaceOpacity::Transparent
    );
    assert_eq!(
        surface_opacity(BRegionType::Center, BHostType::Outliner),
        BSurfaceOpacity::Transparent
    );
}

#[test]
fn the_viewports_canvas_inherits_the_zones_bottom_corners() {
    use super::super::surface::{BCellPosition, BCorners, BRowPosition};

    // A View3D host is a header row above a content band, so the band is the
    // last row: its region — and through it the canvas — owns the two bottom
    // corners. This is the whole chain that decides whether the blue surface
    // paints an arc or squares off the zone it sits in.
    let rows = 2;
    let opacity = surface_opacity(BRegionType::Center, BHostType::View3D);
    let ownership = BCorners::ALL.assign_cell(
        BCellPosition::at(1, rows, 0, 1),
        opacity,
    );
    assert_eq!(
        ownership.child,
        BCorners::new(false, false, true, true),
        "the content region must carry the bottom corners to its canvas"
    );

    // The header above it keeps the two at the top.
    let header = BCorners::ALL.assign_row(
        BRowPosition::at(0, rows),
        surface_opacity(BRegionType::Header, BHostType::View3D),
    );
    assert_eq!(header.child, BCorners::new(true, true, false, false));
}
