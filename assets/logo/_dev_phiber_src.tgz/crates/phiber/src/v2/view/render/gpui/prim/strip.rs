//! A strip: groups of controls placed at the start, the centre and the end of
//! one axis.
//!
//! A header row and a vertical rail are the same element. The header divides
//! its width three ways; the activity bar, the tool strip, the properties
//! navbar and the editor side rail divide their height the same three ways.
//! Only the axis differs, and whether the groups hug their content or share
//! out the slack — so both go through here rather than each growing its own
//! flex rules.

use super::super::ctx::BRenderCtx;
use gpui::prelude::*;
use gpui::{AnyElement, Div, div, px};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BStripAxis {
    /// A header: groups run left to right.
    Row,
    /// A rail: groups run top to bottom.
    Column,
}

impl BStripAxis {
    fn lay(self, el: Div) -> Div {
        match self {
            BStripAxis::Row => el.flex().flex_row(),
            BStripAxis::Column => el.flex().flex_col(),
        }
    }
}

/// How a group shares the strip's slack.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BStripFit {
    /// Groups hug their content; the strip's own container divides the space.
    Hug,
    /// Groups take the slack: first at the start, last at the end, the rest
    /// centred between them. Their children sit on the strip's centre line,
    /// which is what a bar of controls wants.
    Divide,
    /// As `Divide`, but each group also stretches its children across the
    /// strip. A content row is columns, not controls: a file browser's
    /// bookmark column and its file table both run the full height, rather
    /// than floating at whatever height their own content happens to be.
    Fill,
}

/// One group's cell, at position `n` of `total`.
pub fn slot(
    axis: BStripAxis,
    fit: BStripFit,
    n: usize,
    total: usize,
    c: &BRenderCtx,
) -> Div {
    let mut el = axis.lay(div()).min_w_0().gap(px(c.style.spacing.gap_xs));
    el = if fit == BStripFit::Fill {
        el.items_stretch().min_h_0()
    } else {
        el.items_center()
    };
    if fit == BStripFit::Hug {
        return el.flex_shrink_0();
    }
    el = match (n, total) {
        (_, 1) => el.flex_1(),
        (0, 2) => el.flex_1().justify_start(),
        (0, _) => el.flex_shrink_0().justify_start(),
        (n, total) if n + 1 == total => el.flex_shrink_0().justify_end(),
        _ => el.flex_1().justify_center(),
    };
    el
}

/// The strip's own container: groups pushed apart along `axis`.
pub fn container(axis: BStripAxis, c: &BRenderCtx) -> Div {
    axis.lay(div())
        .items_center()
        .min_h_0()
        .min_w_0()
        .justify_between()
        .gap(px(c.style.spacing.gap_xs))
}

/// Place `groups` along `axis`, dropping the empty ones so a strip with only
/// a start and an end group still puts them at the two ends.
pub fn place(
    axis: BStripAxis,
    fit: BStripFit,
    groups: Vec<Vec<AnyElement>>,
    c: &BRenderCtx,
) -> Div {
    let filled: Vec<Vec<AnyElement>> = groups.into_iter().filter(|g| !g.is_empty()).collect();
    let total = filled.len();
    let mut el = container(axis, c);
    for (n, group) in filled.into_iter().enumerate() {
        let mut cell = slot(axis, fit, n, total, c);
        for child in group {
            cell = cell.child(child);
        }
        el = el.child(cell);
    }
    el
}
