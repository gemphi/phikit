//! Field atom — a bordered value read-out used inside property rows.
//! Blender ref: `uiItemR` renders numeric/enum/string RNA props as slim
//! rounded boxes with a subtle bg and centre-aligned value text.

use super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::theme::BStyleRole;
use gpui::prelude::*;
use gpui::{AnyElement, SharedString, div, px};

/// The box every input shares: one rounded, clipped surface that owns its
/// fill and its border. Read-outs and typed fields differ only in what they
/// put inside it, so an input can never end up with a second, square box
/// painted behind its rounded one.
pub fn shell(editing: bool, c: &BRenderCtx) -> gpui::Stateful<gpui::Div> {
    let border = if editing {
        c.style.colors.accent
    } else {
        c.style.colors.border
    };
    div()
        .id(SharedString::from("field-shell"))
        .flex()
        .flex_1()
        .flex_row()
        .items_center()
        .min_w_0()
        // The fill, the focus border and any hover all stop at the rounded
        // edge, so nothing bleeds onto the strip behind the field.
        .overflow_hidden()
        .h(px(c.style.dimensions.row_height))
        .px(px(c.style.spacing.pad_sm))
        .rounded(px(c.style.radius_for(BStyleRole::Field)))
        .bg(to_hsla(c.style.colors.bg_hover))
        .border_1()
        .border_color(to_hsla(border))
        .text_color(to_hsla(c.style.colors.text))
        .text_size(px(c.style.typography.body))
}

pub fn view(text: &str, c: &BRenderCtx) -> AnyElement {
    shell(false, c)
        .justify_center()
        .child(SharedString::from(text.to_string()))
        .into_any_element()
}
