//! Focused renderer for `BPanelRole::Card` — grouped accordion section.

use super::super::super::{color::to_hsla, ctx::BRenderCtx, walk};
use super::style::{content_inset, panel_bg, row_inset};
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::BPanelRole;
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

pub struct BCard<'a>(pub &'a [BView]);

/// A card's heading strip paints edge to edge, so it never sits in the
/// content gutter.
fn is_heading(v: &BView) -> bool {
    matches!(
        v,
        BView::AccordionHeader { .. } | BView::Panel { role: BPanelRole::CardHeader, .. }
    )
}

impl BCard<'_> {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let lead = self.0.iter().take_while(|v| is_heading(v)).count();
        let (heads, rows) = self.0.split_at(lead);
        // Heading strips paint to the card's edge; every row below them sits in
        // one gutter, so row text lands under the heading title
        // (`tests/layout_gutters.rs`).
        let mut element = div()
            .flex()
            .flex_col()
            .w_full()
            .rounded(px(c.style.radius_for(BStyleRole::Card)))
            .border(px(c.style.strokes.border))
            .border_color(to_hsla(c.style.colors.border))
            // No clipping: a dropdown opened from a card row has to escape the
            // card (`file_browser_accordion_refinement`).
            .bg(panel_bg(BPanelRole::Card, c));
        for head in heads {
            element = element.child(walk(head, c));
        }
        if rows.is_empty() {
            return element.into_any_element();
        }
        let name = heads.iter().find_map(title).unwrap_or("card");
        let slot = format!("card-content-{name}");
        let mut content = div()
            .id(gpui::SharedString::from(slot.clone()))
            .debug_selector(move || slot.clone())
            .flex()
            .flex_col()
            .w_full()
            .px(px(content_inset(c)))
            .py(px(c.style.spacing.pad_xs))
            .gap(px(c.style.spacing.gap_xs));
        for (n, row) in rows.iter().enumerate() {
            content = content.child(inset(row, c, &format!("card-row-{name}-{n}")));
        }
        element.child(content).into_any_element()
    }
}

/// The heading title a card's content sits under, for a stable selector.
fn title(v: &BView) -> Option<&str> {
    match v {
        BView::AccordionHeader { title, .. } => Some(title.as_str()),
        BView::Panel { children, .. } => children.iter().find_map(|child| match child {
            BView::Label { text } => Some(text.as_str()),
            _ => None,
        }),
        _ => None,
    }
}

/// Bare text carries no inset of its own, so the card lends it one and its
/// baseline stays in the shared column.
fn inset(row: &BView, c: &BRenderCtx, id: &str) -> AnyElement {
    let slot = id.to_string();
    let mut el = div()
        .id(gpui::SharedString::from(slot.clone()))
        .debug_selector(move || slot.clone())
        .w_full();
    if matches!(row, BView::Label { .. }) {
        el = el.px(px(row_inset(c)));
    }
    el.child(walk(row, c)).into_any_element()
}

use super::super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BCard<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BCard::render(self, c)
    }
}
