//! Menu-popover row — flat by default, hover-only highlight, matches
//! Blender's `layout.operator` rows. Optional `hover` action fires when
//! the pointer enters the row (submenu anchors use it to open on hover).

use super::super::{color::to_hsla, ctx::BRenderCtx};
use super::{chrome, icon_path};
use crate::v2::theme::BStyleRole;
use crate::v2::view::prim::BControl;
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, div, px, svg};
use std::rc::Rc;

pub fn view(ctl: &BControl, c: &BRenderCtx) -> AnyElement {
    let ic = ctl.icon.as_deref().unwrap_or("");
    let lbl = ctl.label.as_deref().unwrap_or("");
    let sc = ctl.shortcut.as_deref().unwrap_or("");
    let action = ctl.action.as_ref();
    let hover = ctl.hover.as_ref();
    // A menu row is a strip control: flat at rest, filled on hover or when
    // active. A resting fill turned every row into a pill and made a menu
    // look nothing like the toolbar and sidebar it sits next to.
    let mut row = div()
        .flex()
        .flex_row()
        .items_center()
        .w_full()
        .gap(px(c.style.spacing.gap_sm))
        .px(px(c.style.spacing.pad_sm))
        .h(px(c.style.dimensions.row_height))
        .text_color(to_hsla(c.style.colors.text))
        .text_size(px(c.style.typography.body));
    // Every row reserves the icon slot, drawn or not, so labels start on one
    // line down the whole menu. A row without an icon used to start its label
    // where the icon would have been, which put the labels of one menu on two
    // different left edges — Blender reserves the slot the same way.
    let slot = px(c.style.dimensions.icon_size_sm);
    let icon = div().size(slot).flex_shrink_0();
    row = row.child(if ic.is_empty() {
        icon
    } else {
        icon.child(
            svg()
                .path(icon_path(ic))
                .size(slot)
                .text_color(to_hsla(c.style.colors.text_dim)),
        )
    });
    // The label hugs the slot and reads left-aligned; `flex_1` lets the
    // shortcut sit at the far end.
    row = row.child(
        div()
            .flex_1()
            .min_w_0()
            .text_left()
            .child(SharedString::from(lbl.to_string())),
    );
    if !sc.is_empty() {
        row = row.child(
            div()
                .text_color(to_hsla(c.style.colors.text_dim))
                .text_size(px(c.style.typography.caption))
                .child(SharedString::from(sc.to_string())),
        );
    }
    let radius = px(c.style.radius_for(BStyleRole::MenuItem));
    let Some(a) = action else {
        return row.into_any_element();
    };
    let ch = c.h.clone();
    let ac = a.clone();
    let id = SharedString::from(format!("menu-{}", lbl));
    // Rest / hover / active come from the one strip treatment, so a menu row
    // and the anchor that opened it share a shape and a fill. Not `floating`:
    // the popover panel is the floating surface; its rows sit inside it.
    let el = div()
        .id(id.clone())
        .debug_selector(move || id.to_string())
        .cursor_pointer()
        .w_full()
        .rounded(radius)
        .overflow_hidden()
        .child(row);
    let mut el = chrome::paint(el, ctl.active, c).on_click(
            move |_e: &ClickEvent, w: &mut gpui::Window, cx: &mut gpui::App| {
                (Rc::clone(&ch))(&ac, w, cx);
            },
        );
    if let Some(h) = hover {
        let hh = c.h.clone();
        let ha = h.clone();
        el = el.on_hover(
            move |hovered: &bool, w: &mut gpui::Window, cx: &mut gpui::App| {
                if *hovered {
                    (Rc::clone(&hh))(&ha, w, cx);
                }
            },
        );
    }
    el.into_any_element()
}

pub fn sep(c: &BRenderCtx) -> AnyElement {
    div()
        // GPUI mechanics: hairline separator uses the border stroke width as
        // the minimal 1px divider height in the GPUI div layout.
        .h(px(c.style.strokes.hairline))
        .w_full()
        .my(px(c.style.spacing.gap_xs))
        .bg(to_hsla(c.style.colors.sep))
        .into_any_element()
}
