//! Focused renderer for `BView::Row` — flex-row with bounded height.

use super::super::{ctx::BRenderCtx, walk};
use super::strip;
use crate::v2::view::BView;
use gpui::prelude::*;
use gpui::AnyElement;

pub struct BRow<'a>(pub &'a [BView]);

impl BRow<'_> {
    pub fn render(&self, c: &BRenderCtx<'_>) -> AnyElement {
        // A row is a strip along the horizontal axis. In a header its panes
        // already divide the strip three ways, so its groups hug; elsewhere
        // the groups divide the slack themselves.
        // A row inside any chrome strip — a header region, or a toolbar /
        // footer panel in a modal — holds controls, and controls sit on the
        // strip's line. Everywhere else a row holds columns.
        let in_header = c.strip
            || matches!(
                c.region,
                Some(crate::v2::region::BRegionType::Header)
                    | Some(crate::v2::region::BRegionType::ToolHeader)
            );
        let fit = if in_header {
            strip::BStripFit::Hug
        } else {
            // A content row holds columns, so its groups stretch across it.
            strip::BStripFit::Fill
        };
        let groups: Vec<Vec<AnyElement>> = groups(self.0)
            .into_iter()
            .map(|views| views.iter().map(|v| walk(v, c)).collect())
            .collect();
        let mut element = strip::place(strip::BStripAxis::Row, fit, groups, c);
        element = if in_header {
            // A header row passes the strip's height straight through, so a
            // cap's `self_end` still measures against the strip rather than
            // against the row.
            element.h_full().items_end()
        } else {
            element.items_stretch().w_full().h_full()
        };
        element.into_any_element()
    }
}

/// A row is a set of groups separated by `BView::Spacer`: whatever the author
/// wanted kept together stays together, and the groups are pushed to the
/// strip's start, centre and end.
fn groups(children: &[BView]) -> Vec<&[BView]> {
    let mut out = Vec::new();
    let mut start = 0usize;
    for (n, child) in children.iter().enumerate() {
        if matches!(child, BView::Spacer) {
            out.push(&children[start..n]);
            start = n + 1;
        }
    }
    out.push(&children[start..]);
    out.retain(|group| !group.is_empty());
    out
}

use super::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BRow<'_> {
    fn render(&self, c: &BRenderCtx) -> AnyElement {
        BRow::render(self, c)
    }
}
