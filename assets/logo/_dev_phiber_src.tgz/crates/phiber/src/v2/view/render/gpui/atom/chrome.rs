//! One treatment for every control that sits in a header strip.
//!
//! A header is a row of menus, so everything in it reads as a menu: the same
//! resting fill, the same hover lift, the same filled active cap. Without
//! this, an icon button rested on nothing while the menu beside it rested on
//! the strip fill, which is what made headers look like several unrelated
//! widget sets sharing a row.

use super::super::{
    color::{resolved_gradient, to_hsla},
    ctx::BRenderCtx,
};
use gpui::prelude::*;
use gpui::{Div, Stateful};

/// True inside a strip whose controls follow the menu treatment: the two
/// header rows and the path/tool bar beneath them.
pub fn in_strip(c: &BRenderCtx) -> bool {
    c.strip
}

/// Paint one strip control: nothing at rest, the menu hover fill on hover,
/// a filled cap when active.
///
/// A strip control rests on the strip itself and paints only in response to
/// the pointer. Giving every control a resting fill turned each header into a
/// row of pills, which is not what a menu bar looks like.
pub fn paint(el: Stateful<Div>, active: bool, c: &BRenderCtx) -> Stateful<Div> {
    if active {
        return el.bg(resolved_gradient(c.style.host_item_active_gradient(c.host)));
    }
    let hover = to_hsla(if in_strip(c) {
        c.style.host_item_hover(c.host)
    } else {
        c.style.colors.bg_hover
    });
    if c.floating {
        // Floating chrome sits over the canvas, so its controls need a
        // resting fill to stay readable against whatever is behind them.
        // Docked chrome rests on its own strip and needs none — giving it one
        // turns a header into a row of pills.
        let resting = to_hsla(c.style.host_item_hover(c.host));
        return el.bg(resting).hover(move |s| s.bg(hover));
    }
    el.hover(move |s| s.bg(hover))
}
