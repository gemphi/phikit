//! Modal title bar with existing minimize, maximize/restore, and close actions.

use super::super::{
    color::{resolved_gradient, to_hsla},
    ctx::BRenderCtx,
    surface::compatible_inner_radius,
};
use crate::v2::modal::BModalType;
use crate::v2::state::{
    key::{K_MODAL, K_MODAL_MAXIMIZED, K_MODAL_MINIMIZED},
    val::V_EMPTY,
};
use crate::v2::theme::{BStyleRole, BSurfaceTone};
use crate::v2::view::prim::BAction;
use gpui::prelude::*;
use gpui::{AnyElement, ClickEvent, SharedString, div, px, svg};
use std::rc::Rc;

pub struct BTitle {
    pub kind: BModalType,
    pub maximized: bool,
    pub rounded: bool,
}

impl BTitle {
    /// A modal's window control — the same button the OS caption draws, with
    /// the modal's own action attached.
    fn button(&self, slug: &str, icon: &str, action: BAction, c: &BRenderCtx) -> gpui::Stateful<gpui::Div> {
        let handler = c.h.clone();
        let dispatched = action.clone();
        super::super::atom::caption::control(
            SharedString::from(format!("modal-{slug}")),
            icon,
            slug == "close",
            c,
        )
        .on_click(move |_e: &ClickEvent, w: &mut gpui::Window, cx: &mut gpui::App| {
            (Rc::clone(&handler))(&dispatched, w, cx);
        })
    }

    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let spec = self.kind.spec();
        let title_row = div()
            .flex()
            .flex_row()
            .items_center()
            .gap(px(c.style.spacing.gap_sm))
            .child(
                svg()
                    .path(format!("icons/{}.svg", spec.icon))
                    .size(px(c.style.dimensions.icon_size))
                    .flex_shrink_0()
                    .text_color(to_hsla(c.style.colors.text)),
            )
            .child(SharedString::from(spec.label.to_string()));
        let mut bar = div()
            .flex()
            .flex_row()
            .items_center()
            .justify_between()
            .h(px(c.style.dimensions.header_height))
            .px(px(c.style.spacing.pad_md))
            .bg(resolved_gradient(c.style.surface(BSurfaceTone::Header)))
            .border_b(px(c.style.strokes.border))
            .border_color(to_hsla(c.style.colors.border))
            .text_size(px(c.style.typography.header))
            .child(title_row)
            .child({
                let mut controls = div()
                    .flex()
                    .flex_row()
                    .items_center()
                    .gap(px(c.style.spacing.gap_xs));
                for ctl in super::super::atom::caption::WINDOW_CONTROLS {
                    let action = match ctl.slug {
                        "min" => BAction::Toggle(K_MODAL_MINIMIZED),
                        "max" => BAction::Toggle(K_MODAL_MAXIMIZED),
                        _ => BAction::Set(K_MODAL, V_EMPTY.to_string()),
                    };
                    controls = controls.child(self.button(
                        ctl.slug,
                        ctl.icon(self.maximized),
                        action,
                        c,
                    ));
                }
                controls
            });
        if self.rounded {
            bar = bar.rounded_t(px(compatible_inner_radius(
                c.style.radius_for(BStyleRole::Modal),
                c.style.strokes.border,
            )));
        }
        bar.into_any_element()
    }
}
