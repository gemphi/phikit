# A unified structure for `phiber/src/v2`

The proposal, in one sentence: **every level is one folder with one trait, one
enum, one table and one build file; every visual thing is a `view`; every
piece of state is a path.** Nothing else earns a file.

Names are four letters wherever the thing allows it (`view`, `flex`, `atom`,
`card`, `part`, `host`, `pane`, `zone`, `area`, `menu`, `rail`, `keys`,
`sets`, `text`, `draw`). Blender's own names stay where they are Blender's
(`space`, `region`, `modal`, `state`, `theme`) — a reader coming from
`space_file.cc` has to find `space` and `region`.

## 0. What buikit already got right

`crates/apple/src/buikit` (v1) is the shape to keep, minus AppKit:

| buikit                     | what it is                                              | v2 name         |
|----------------------------|---------------------------------------------------------|-----------------|
| `view/` — one `BView` enum | the retained tree, pure data, no native view until host | `view/mod.rs`   |
| `structure/`               | `ScrArea` / `ARegion` / `eSpace_Type` as data           | the level folders |
| `blayout/` — `classify` → `measure` → `layout` | one layout engine that looks at a view's *kind* and decides Fixed / Flex / Spacer | `view/flex/` |
| `brender/` — `BRenderer`   | the single render boundary, one file per view family    | `view/draw/`    |
| `spaces/`                  | one file per editor, declaring its regions              | `host/sets.rs`  |
| `see/*.md`                 | the design record beside the code                       | `v2/*.md`       |

Two things buikit did that v2 has drifted from, and this proposal restores:

- **The layout engine decides from the type, not the call site.**
  `BLayoutEngine::classify` looks at `BView::Button` and knows it is one
  `row_h` tall; nobody writes `.h(px(row_h))` at a button. In v2 that role is
  `BFlex`, and it already has the trait for it — `BFlexed` — but only the
  levels implement it. The rule becomes: **every kind implements `BFlexed`,
  and `BFlex` is the only thing that turns a kind into layout.**
- **One render boundary.** buikit has `brender/`; v2 has `atom/`, `prim/`,
  `prim/panel/`, `modal/`, `popover/` each styling on their own. §4 merges
  them into `view/draw/`, where a file may only ask a kind for its `BFlex`
  and add children.

## 1. The three traits everything implements

```rust
// v2/view/mod.rs

/// A tree of declared UI. Levels build it; `view/draw` paints it.
pub enum BView { Space{..}, Zone{..}, Area{..}, Host{..}, Region{..}, Pane{..},
                 Part{..}, Modal{..}, Card(BCard), Row{..}, Column{..}, Label{..},
                 Prose{..}, Button(BCtrl), Tab(BCtrl), Menu(BCtrl), Field{..},
                 Icon{..}, Canvas{..}, Empty }

/// One thing that becomes one view.
pub trait BItem { fn view(&self, s: &BState) -> BView; }

/// One thing that becomes many views (a table's rows, a strip's caps).
pub trait BList { fn views(&self, s: &BState) -> Vec<BView>; }

/// One view that becomes pixels. Only `view/draw/*` implements it.
pub trait BDraw { fn draw(&self, c: &BCtx) -> AnyElement; }
```

`BViewItem::build` → `BItem::view`; `BViewList::items` → `BList::views`;
`BFocusedRenderer::render` (dead today) → `BDraw::draw`, and it is the *only*
render trait.

## 2. One trait per level

Each level has one trait that says what the level *is*, one enum of kinds,
one declared table. The trait carries the enum and the table as associated
items, so a level is queryable the same way whichever level it is:

```rust
// v2/spec.rs
pub trait BSpec: Copy + Debug + 'static {
    fn label(&self) -> &'static str;
    fn icon(&self) -> &'static str { "" }
}

/// What every level has in common: a kind, a set of kinds, a spec per kind.
pub trait BLevel {
    type Kind: Copy + Eq + Hash + Debug + 'static;
    type Spec: BSpec;
    const ALL: &'static [Self::Kind];
    fn spec(kind: Self::Kind) -> &'static Self::Spec;
    fn slug(kind: Self::Kind) -> &'static str;
}
```

and then, per level, the trait that names it:

```rust
pub trait BSpace: BLevel + BItem {}     // space/space.rs
pub trait BZone:  BLevel + BItem {}     // zone/zone.rs
pub trait BArea:  BLevel + BItem {}     // area/area.rs
pub trait BHost:  BLevel + BItem {}     // host/host.rs
pub trait BRegion:BLevel + BItem {}     // region/region.rs
pub trait BPane:  BLevel + BItem {}     // pane/pane.rs
pub trait BPart:  BLevel + BItem {}     // part/part.rs
pub trait BModal: BLevel + BItem {}     // modal/modal.rs
```

A level folder is then exactly:

```
part/
    mod.rs      pub use; nothing else
    part.rs     BPartKind (the enum), BPartSpec, `impl BLevel`, `impl BPart`,
                and the one `fn view()` that was item.rs + list.rs
    sets.rs     the declared table: one spec per kind, Blender's order
    menubar/    a kind with content of its own
        part.rs     its BItem/BList impls (was mod.rs + item.rs + list.rs)
        sets.rs     its declared content (was set.rs)
    switcher/
        part.rs
        sets.rs
    …
```

The same shape for `host/`, `zone/`, `area/`, `pane/`, `region/`, `space/`,
`modal/`: `<level>.rs` + `sets.rs` + one folder per kind that has content,
each holding `<level>.rs` + `sets.rs`. Today's `type.rs`, `spec.rs`,
`item.rs`, `list.rs` collapse into `<level>.rs`; `set.rs` becomes `sets.rs`
(it is always a set *of* sets: several `static` tables per file).

A kind folder with real content may add files named for the content, never
for the mechanism: `part/file/table.rs`, `part/file/thumbs.rs`,
`modal/reader/store/*.rs`. No `helpers.rs`, no `util.rs`, no `impl.rs`.

## 3. The card

Every panel role today (`Header`, `Body`, `Footer`, `Card`, `CardHeader`,
`Section`, `Sidebar`, `Toolbar`, `Viewport`, `Modal`, `Banner`) is one type
with three slots and a handful of traits:

```rust
// v2/view/card.rs
pub struct BCard {
    pub kind: BCardKind,          // Card | Section | Sheet | Strip | Bare
    pub head: Vec<BView>,         // the heading strip (title, controls)
    pub body: Vec<BView>,         // the content
    pub foot: Vec<BView>,         // the footer strip (actions)
    pub traits: BCardTraits,
}

#[derive(Default)]
pub struct BCardTraits {
    pub scroll: Option<BScroll>,  // Scroll::Y / Scroll::Both, id from the card's kind+title
    pub size:   Option<BSize>,    // resizable: the key the drag writes, min, axis
    pub shrink: bool,             // may give up height/width below its content
    pub fold:   Option<BPath>,    // collapsible: the key that holds open/closed
}

impl BCard {
    pub fn new(kind: BCardKind) -> Self;
    pub fn head(self, views: impl Into<Vec<BView>>) -> Self;
    pub fn body(self, views: impl Into<Vec<BView>>) -> Self;
    pub fn foot(self, views: impl Into<Vec<BView>>) -> Self;
    pub fn scroll(self, how: BScroll) -> Self;
    pub fn size(self, key: BPath, axis: BAxis) -> Self;   // resizable
    pub fn shrink(self) -> Self;
    pub fn fold(self, key: BPath) -> Self;               // accordion
}
```

`BView::Card(BCard)` replaces `BView::Panel { role, children }`,
`BView::AccordionHeader`, and the ad-hoc `CardHeader`/`Footer` pairs. The
file browser's source list is `BCard::new(Section).head([title]).body(rows)
.fold(key)`; the reader is `BCard::new(Sheet).body(prose).scroll(Y)`; a host
header region is a `Strip` card with only a `head`.

**Resize is standalone.** `view/size.rs` owns the grab handle, the drag, and
the key it writes; a card that is `.size(key, axis)` gets the handle laid
over its edge by `view/draw/card.rs`. Nothing about resizing lives in the
card, the sidebar or the region — today it is spread over
`prim/panel/resize.rs`, `prim/panel/sidebar.rs`, `zone/seam.rs`,
`space/seam.rs` and `state/area_resize.rs`. One `BSize` and one `size.rs`.

Likewise **scroll is standalone** (`view/scrl.rs`: the id, the offset, the
overflow) and **fold** is standalone (`view/fold.rs`: the chevron, the key).

## 3a. Controls: one vocabulary over one value category — *implemented*

Every widget that edits a value is a `BCtrl` (`view/prim/ctrl.rs`,
drawn by `view/render/gpui/atom/ctrl.rs`, in sync108):

```rust
pub enum BCtrlKind {
    Check, Toggle,                       // Bool
    Radio, Select,                       // Enum   (options: Vec<BOption>)
    Int { min, max },                    // Int
    Number { min, max, step },           // Float
    Slider { min, max },                 // Float
    Text, Search,                        // Text
    Color,                               // Color  [r,g,b,a]
    Path,                                // Path
}
impl BCtrlKind { const fn value_kind(self) -> BValueKind }

pub struct BCtrl { kind, key: BPath, value: BValue, label, tooltip, options, editing, open, open_key }
impl BCtrl {
    fn read(kind, key, default, s: &BState) -> Self;   // the value from the state, as its category
    fn set(&self, BValue) -> BAction;                  // Set(key, value.encode())
    fn flip(&self) -> BAction;                         // Bool
    fn nudge(&self, steps: f32) -> Option<BAction>;    // Int / Number / Slider, clamped
    fn focus(&self) -> BAction;                        // typed kinds: the caret
    fn chosen(&self) -> Option<&BOption>;              // Radio / Select
}
```

and every state value has a category (`state/val.rs`):

```rust
pub enum BValueKind { Bool, Int, Float, Enum, Text, Color, Path }
pub enum BValue { Bool(bool), Int(i64), Float(f32), Enum(String), Text(String), Color([f32;4]), Path(String) }
impl BValue { fn encode(&self) -> String; fn parse(BValueKind, &str) -> Option<Self>; fn display(&self) -> String }
impl BState { fn value(&self, key, BValueKind) -> Option<BValue> }
```

The state stays strings; the *category* travels with the control that
edits the key, so one `encode`/`parse` serves every widget. What this buys:

- A Properties row is `BPropKind → (BCtrlKind, default)`; Bool, Int, Float,
  Enum, Str, Color, Vec3/Vec4 (one control per axis) are all real controls
  over `ctx.buts.<key>` — no more placeholder fields.
- **Render Engine → Phiray** is `Select` over `ctx.buts.engine`; choosing it
  is `Set(ctx.buts.engine, "PHIRAY")`, the log says "Render Engine: Phiray"
  (`prop_named` looks the label up), and anything else — a menu item, a
  script, a keymap — sets the engine with the same write.
- The file browser's "Load UI" is the same `Check` as a Properties bool.
- A `Button`, `Tab`, `MenuItem` stay `BControl` (an action, no value); a
  menu is `BMenuKind::{Op, Toggle, Sub, Sep}` with declared `modal` /
  `purpose` / `url` targets — already one typed table (`part/menubar/sets`).

Still to do in this area: drag on `Number`/`Slider` (today: step buttons and
typing), a colour picker popover behind the swatch, and moving the
`open_key` of a `Select` into the control's own key namespace.

## 3b. `BFlex` takes the types and decides

```rust
// v2/view/flex/flex.rs
/// A kind that knows how it is laid out. Every level kind, every card kind,
/// every control kind implements it — it is the only way into BFlex.
pub trait BFlexed { fn flex(&self, c: &BCtx) -> BFlex; }

impl BFlexed for BZoneKind   { … }   // zone/zone.rs:   axis, fill, size
impl BFlexed for BRegionKind { … }   // region/region.rs: strip height, rail width, padding
impl BFlexed for BPaneKind   { … }
impl BFlexed for BCardKind   { … }   // view/card.rs: Card / Section / Sheet / Strip
impl BFlexed for BCtrlKind   { … }   // view/ctrl.rs: Button / Tab / Cap / Field / Menu row
impl BFlexed for BProse      { … }
```

and `BFlex` itself gains what buikit's engine had — a classification —
so a draw file never asks "is this a strip?":

```rust
impl BFlex {
    pub fn of(kind: &impl BFlexed, c: &BCtx) -> Self;   // the one entry
    pub fn div(&self, c: &BCtx) -> Div;                  // container
    pub fn scroller(&self, id, c) -> Stateful<Div>;      // + BScroll
    pub fn unfolding(&self, id, c) -> AnimationElement;  // + motion
    pub fn class(&self) -> BFlexClass;                   // Fixed | Flex | Spacer | Strip | Rail
}
```

`view/draw/<x>.rs` then reads as: take the kind, `BFlex::of(kind, c).div(c)`,
add the children, tag the id. Nothing else. `tests/style_budget.rs` pins
every draw file at zero raw style calls from the start, not "no worse than
today".

## 3c. A dialog is a space — *implemented (sync109)*

A modal was a "peer of Space" with its own body builder, which is why the
file dialog, Preferences and the render window each laid themselves out
differently from the editors in a workspace. Now `BModalSpec` declares
`areas: &[BAreaSpec]` exactly as `BSpaceSpec` does, and `BModalItem` builds
them through the same `BZoneList` → `BZoneItem` → `BAreaItem` → `BHostItem`
chain, scoped to the modal (`area::BScope::Modal`) so the editor chosen in
the dialog's area never overwrites the workspace's slot:

```rust
static FILE_AREAS:   &[BAreaSpec] = &[editor(BHostType::File,  &[BHostType::File, BHostType::Asset])];
static PREFS_AREAS:  &[BAreaSpec] = &[editor(BHostType::Prefs, &[BHostType::Prefs])];
static RENDER_AREAS: &[BAreaSpec] = &[editor(BHostType::Image, &[BHostType::Image])];
```

So the file dialog *is* Zone::Center ▸ Area ▸ Host::File, with the same
header (switcher icon + View/Select on the left, display / hidden / filter
icons on the right — Blender's `FILEBROWSER_HT_header`), the same path
strip, source list, table and execute bar as the File editor in the Shading
workspace. Dialogs with an empty `areas` (Splash, About, Help, Reader,
Profile, Collab, Command, Spaces, Progress) are Blender *menus*
(`WM_MT_splash`, `WM_MT_splash_about`…), not editors; they keep their own
`BViewItem` until §4's regions-for-everything step.

Sizes: every card dialog is half the window wide (`BLen::Share(0.5)`); one
that raises an editor is the window's height, a form keeps its declared
height; the reader sheet is half the window too. Declared `width`s in
`modal/set.rs` are now unused and will go.

Known gap: `zone_size` / `area_fraction` still key by `ctx.space`, so a
dialog's zone reads the active workspace's drag sizes (harmless for a
single Center zone; to fix when `BRenderCtx` carries the scope).

## 4. `view/` is the whole visual layer — no `render/`

```
view/
    mod.rs      BView, BItem, BList, BDraw
    card.rs     BCard + traits (§3)
    ctrl.rs     BCtrl: icon/label/action/hover/active (was prim/control.rs)
    prim.rs     the constructors: row, column, label, field, icon, table_row, tree_row…
    text.rs     the text dump of a BView (was render/ascii.rs) — the test oracle
    flex/       BFlex, the one layout element (as today)
        flex.rs token.rs apply.rs
    draw/       BDraw impls, one file per view kind, no level knows GPUI but these
        space.rs zone.rs area.rs host.rs region.rs pane.rs part.rs modal.rs
        card.rs  row.rs  table.rs  tree.rs  menu.rs  rail.rs  tab.rs
        ctrl.rs  text.rs  icon.rs  prose.rs  log.rs
        size.rs  scrl.rs  fold.rs      ← the standalone traits' painters
        ctx.rs   color.rs  brand.rs
    canvas/     the viewport and node graph — a renderer of its own, not an atom
        view3d/ node/ image/ gizmo/
    seam.rs     the drag line between two zones or areas (one, not two)
```

`render/gpui/atom/` and `render/gpui/prim/` merge into `draw/`: an atom and a
prim were the same thing (a `BDraw` for one `BView` variant). The
`B…Layout` traits in `render/*.rs` (axis, placement) fold into each level's
`<level>.rs` as methods on the kind — `BZoneKind::axis()` is a fact about
zones, not about rendering.

## 5. `state/` is two files

```
state/
    mod.rs      BState: get / set / has / toggle / remove; BPath; BKey; BAction; apply
    keys/       one enum per domain, each `impl BKey` — the only place a path is spelt
        space.rs zone.rs area.rs host.rs region.rs pane.rs part.rs modal.rs
        file.rs view3d.rs menu.rs edit.rs theme.rs log.rs
```

```rust
/// A key is a path: `ctx.{domain}.{owner}.{field}`, spelt once, in an enum.
pub trait BKey { fn path(&self) -> BPath; }

// state/keys/zone.rs
pub enum ZoneKey { Shown(BSpaceKind, BZoneKind), Size(BSpaceKind, BZoneKind) }
impl BKey for ZoneKey {
    fn path(&self) -> BPath { match self {
        Self::Shown(s, z) => BPath::of(["zone", s.slug(), z.slug(), "shown"]),
        Self::Size(s, z)  => BPath::of(["zone", s.slug(), z.slug(), "size"]),
    }}
}

// anywhere
s.get(ZoneKey::Size(space, zone));  s.set(ZoneKey::Shown(space, zone), true);
```

`BState::get/set/has/toggle/remove` take `impl BKey`. The 37 `K_…`
constants and the `k_…()` functions once scattered through
`part/custom/file/keys.rs`, `part/custom/outliner/keys.rs`, `scene/keys.rs`,
`part/strip.rs` and `prim/panel/resize.rs` are now variants of a domain enum
in `state/keys/` (done, §5a); `k_menu*` is the last holdout.
A reader looking for what the file browser stores opens `keys/file.rs` and
sees every key it has.

What is *not* in `state/`: the reducers. `area_resize.rs`, `zone_size.rs`,
`file_nav.rs`, `space_switch.rs`, `follow.rs`, `menu.rs`, `edit.rs`,
`log.rs`, `seed.rs` are rules about a level, so they live with the level and
register through one trait:

```rust
/// A rule that runs after a key is set.
pub trait BRule { fn after(&self, key: &BPath, value: &str, s: &mut BState); }
```

`zone/size.rs`, `area/size.rs`, `part/file/nav.rs`, `space/switch.rs`,
`app/log.rs` each `impl BRule`; `state/mod.rs::apply` runs the table of
rules. `follow.rs` disappears into them.

### 5a. Done so far (sync111)

`state/keys/mod.rs` has the trait; `BState::get / set / has / remove / value`
take `impl BKey`, and `BPath` implements it, so the old constants and the
new enums meet at the store. The file browser is the first domain moved:
`state/keys/file.rs` — `FileKey::{Path, Selected, Filename, Search, Display,
Sort, SortInvert, ShowHidden, UseFilter, Filter(flag), Nav, HistBack,
HistFwd, Purpose, Error, SidebarExpanded(label), Bookmark(slot),
BookmarkAdd, FilterOpen, LoadUi, RecoverLastSession}` — and
`part/custom/file/keys.rs` is gone. `tests/key_budget.rs` lists the moved
domains and fails on any `vec!["file", …]` or `"ctx.file.…"` spelt outside
the keys file.

sync112 moved two more: `state/keys/outliner.rs` —
`OutlinerKey::{Expanded(id), Search, DisplayMode, SortAlpha,
Restrict(object, field), Column(field), FilterOpen}` (the outliner's
`keys.rs` keeps only its predicates: `is_hidden`, `BHidden`,
`is_expanded`, `search_text`, `display_mode`, `sort_alpha`) — and
`state/keys/buts.rs` — `ButsKey::{Value(prop), Axis(prop, axis),
Dropdown(prop), NavbarTab}`, so a Properties value is `ButsKey::Value("engine")`
wherever it is read. The budget caught one spelling the grep had missed
(`modebar/set.rs`), which is the point of it. sync113: `View3dKey::{Yaw, Pitch, Zoom, Perspective, PanX, PanY, Shading,
View, Pivot, Fov, GizmoCorner}` and `SceneKey::{Loading, LoadStage,
LoadProgress, LoadCancel, Error, LoadedPath}`; `scene/keys.rs`'s `*_key()`
functions now delegate to them (the ~200 call sites keep the function
names; only the spelling moved). sync114: `ZoneKey::{Shown(zone), Size(space, zone)}` and
`AreaKey::{Host(scope, slot, host), Switcher(scope, slot, host),
Size(space, zone, index), DragSpace, DragZone, DragIndex}` with
`size_prefix()` / `switcher_prefix()` for the sweeps; the `K_ZONE_*`
constants and `P_AREA` are gone, the seed writes typed keys, and the
"close every menu and switcher" sweeps use prefixes from the key modules
rather than string literals. Eleven domain prefixes are now under the
budget.

sync115 finished the sweep: **the `K_…` constants are gone.** Four enums
took the rest — `CtxKey::{Space, Scene, ViewLayer, Object, Mode, Tool,
Frame, Playing, FrameStep, FrameStart, FrameEnd, Fps}` (the one-segment
scene context), `ModalKey::{Open, Maximized, Minimized, ReaderDoc,
ReaderReturn}`, `ActivityKey::{Tab, Group, Pick}` and `AppKey::{WindowWidth,
Theme, UseGradients, Link, Edit, EditUndo, CommandQuery, StatusLogOpen,
Profile(field), CollabStatus, CollabServer, CollabPeer(n)}`; the navbar's
expanded flag moved to `ButsKey::NavbarExpanded`, where its path already
lived. `state/key.rs` keeps only `int_or` / `float_or`, `P_MENU` and the
`ui_style` catalogue. `state/follow.rs`'s rule table is `(fn() -> BPath,
Rule)` so its keys are typed too; `edit::is_editing / start` take `impl
BKey`. The budget now covers 36 prefixes, including the one-segment keys
(`vec!["space"]`, `"ctx.link"`), and it caught the one hand-spelt
comparison left in `app/handle.rs`. Next: `menu` (§5's `menu.rs`, folding
`k_menu*` into `MenuKey`), then the reducers become `BRule`s.

## 6. The whole tree

```
v2/
    mod.rs  spec.rs                     BSpec, BLevel

    space/  space.rs sets.rs            BSpaceKind, the 11 workspaces (sets.rs holds all 11
                                        tables — today's eleven files are eleven tables)
            switch.rs                   BRule: picking a space
    zone/   zone.rs sets.rs size.rs     size.rs: BRule for the dragged zone size
    area/   area.rs sets.rs size.rs     size.rs: BRule for the area fractions
    host/   host.rs sets.rs             BHostKind, 36 specs; each host's regions are a
                                        table in sets.rs, not 36 folders of one mod.rs
    region/ region.rs sets.rs           BRegionKind with axis()/placement(); the Header
                                        pane template lives here (was host/header.rs)
    pane/   pane.rs sets.rs
    part/   part.rs sets.rs
            menubar/  part.rs sets.rs
            switcher/ part.rs sets.rs
            search/   part.rs
            filter/   part.rs sets.rs
            toolbar/  part.rs sets.rs
            sidebar/  part.rs sets.rs
            navbar/   part.rs sets.rs
            channels/ part.rs sets.rs
            statusbar/part.rs sets.rs
            log/      part.rs
            zonebar/  part.rs
            activity/ part.rs sets.rs
            caption/  part.rs
            execute/  part.rs
            hud/ assetshelf/ toolprops/ spacebar/ modebar/ …
            props/    part.rs sets.rs   the Properties tabs (was part/panel/, 17 folders →
                      object.rs material.rs modifier.rs … one file per tab)
            file/     part.rs sets.rs   the browser: table.rs thumbs.rs path.rs list.rs
                      nav.rs (BRule)    (was part/custom/file, 19 files → 7)
            outliner/ part.rs sets.rs tree.rs
            time/     part.rs
            text/ node/ image/ seq/ clip/ action/ buts/ prefs/ spreadsheet/ view3d/
                      part.rs each      (was part/custom/*: mod+item+list → part.rs)
    modal/  modal.rs sets.rs
            splash/   modal.rs sets.rs
            help/     modal.rs sets.rs
            about/    modal.rs sets.rs
            reader/   modal.rs sets.rs store/*.rs
            settings/ profile/ collab/ command/ spaces/ progress/ render/ file/
                      modal.rs (+ sets.rs where declared content exists)
    view/   (§4)
    state/  (§5)
    theme/  theme.rs sets.rs            BTheme (was semantic.rs + style.rs + resolver.rs)
            color.rs size.rs fx.rs      the three token families (colors, metrics, effects)
            table.rs                    the descriptor table → Preferences
            palette/  sets.rs           the shipped palettes
    scene/  scene.rs camera.rs …        the loaded file and the viewport state (as today,
                                        minus keys.rs → state/keys/scene.rs, tests → tests/)
    app/    app.rs load.rs log.rs       the window, the file load, the action log (BRule)
```

Counts: today 499 files, 36 host folders of one file each, 17 property-tab
folders of two files each, four "level mechanism" files per level. The tree
above is ~190 files, with no folder that exists only to hold a `mod.rs`.

## 7. The rules, so it stays this way

1. A folder is a level or a kind. A file is `<level>.rs`, `sets.rs`, or
   named for content. Nothing named for a mechanism (`item`, `list`,
   `helpers`, `impl`, `render`).
2. `BItem::view` builds; `BDraw::draw` paints; nothing does both. Only
   `view/draw/` and `view/flex/apply.rs` may name a GPUI type.
3. Every path is a `BKey` variant in `state/keys/`. A string with a dot in
   it outside `state/keys/` is a bug (`tests/style_budget.rs` gets a sibling
   `tests/key_budget.rs` that greps for it).
4. Scroll, size, fold and seam are standalone (`view/size.rs` etc.) and are
   *asked for* through `BCard`'s traits, never built inside a part.
5. Declared content is a `static` table in a `sets.rs`. A `Vec` built at
   runtime from literals is a table that forgot to be declared.
6. Tests live in `tests/`. A `mod tests` at the foot of a file is for
   private items only; no `*_tests.rs` in `src/`.

## 8. Migration order

Each step keeps the layout fingerprint identical or explains every moved
line, as the BFlex refactor did.

1. `state/`: introduce `BKey` and `state/keys/*`; replace the `K_…`/`k_…()`
   uses; move reducers to their levels as `BRule`s. (Mechanical; the
   fingerprint does not move.)
2. `view/card.rs` + `view/size.rs`/`scrl.rs`/`fold.rs`; migrate `BView::Panel`
   and `AccordionHeader` to `BCard`. Delete `prim/panel/*`, `resize.rs`.
3. Collapse each level's four files into `<level>.rs` + `sets.rs`; hosts'
   36 folders into `host/sets.rs`; spaces' 11 files into `space/sets.rs`.
4. `render/` → `view/draw/`; `atom/` + `prim/` merged; `B…Layout` traits
   into the kinds; `BFocusedRenderer` deleted.
5. `part/custom/*` → `part/<name>/part.rs`; `part/panel/` → `part/props/`;
   `part/custom/file/` split into `part/file/` (view) and `state/keys/file.rs`
   + `part/file/nav.rs` (state).
6. Modals: every body a `BView::Host` or a list of `BView::Region`; the title
   bar a Header region.
7. `theme/set.rs` deleted; tests read `DEFAULT_*`.
