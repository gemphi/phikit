//! Command Palette — searchable operator/menu launcher.
//! Blender ref: F3 "Menu Search" and "Operator Search" (Developer Extras).

pub mod palette;
pub mod set;

use crate::v2::state::{BKey as _, AppKey};
use crate::v2::state::{BState};
use crate::v2::view::prim::{BAction, BPanelRole};
use crate::v2::view::{BView, BViewItem};

pub use set::{BCommandField, BCommandKind, SOURCES};

#[derive(Clone, Copy, Debug, Default)]
pub struct BCommandModal;

impl BViewItem for BCommandModal {
    fn build(&self, s: &BState) -> BView {
        let query = s.get(AppKey::CommandQuery).unwrap_or("").to_string();
        let search = BView::text_field(
            "Search menus…",
            query.clone(),
            crate::v2::state::edit::is_editing(s, AppKey::CommandQuery),
            BAction::Set(AppKey::CommandQuery.path(), String::new()),
        );
        BView::column(vec![search, BView::panel(BPanelRole::Body, palette::rows(&query))])
    }
}
