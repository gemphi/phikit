//! Seed Phiber's UI state from a loaded file's view layer, so the Outliner
//! and viewport open the way Blender does: the file's active object is the
//! active row, and objects hidden in the view layer (`BASE_HIDDEN`) or living
//! in a hidden / excluded collection (`LAYER_COLLECTION_HIDE` / `_EXCLUDE`)
//! start with their eye closed.

use crate::v2::state::{CtxKey};
use crate::phiphx::scene::{SceneCollection, SceneModel};
use crate::v2::part::custom::outliner::tree::k_restrict;
use crate::v2::part::custom::text::info::{BReportLevel, push};
use crate::v2::state::{
    BState,
    val::V_TRUE,
};
use crate::v2::state::BPath;

/// A hidden or excluded collection closes its own eye, and the viewport
/// inherits that down the tree (`outliner::layer::hidden_by_collections`).
/// Marking every object under it individually would leave them hidden after
/// the collection's eye was opened again.
fn seed_collections(state: &mut BState, c: &SceneCollection, path: &str) {
    if c.exclude || c.hide_viewport {
        let id = crate::v2::part::custom::outliner::layer::collection_id(path);
        state.set(&k_restrict(id, "hide_get"), V_TRUE);
    }
    for k in &c.children {
        seed_collections(state, k, &format!("{path}/{}", k.name));
    }
}

pub fn seed_view_layer(state: &mut BState, model: &SceneModel) {
    if let Some(active) = &model.selection.active {
        state.set(CtxKey::Object, active.clone());
    }
    for name in &model.selection.hidden {
        state.set(&k_restrict(name, "hide_get"), V_TRUE);
    }
    for c in &model.collections {
        seed_collections(state, c, &c.name);
    }
}

/// Status bar + Info log after a successful read — Blender's
/// `file_read_reports_finalize` line and the `info_stats` string.
pub fn report_loaded(state: &mut BState, model: &SceneModel) {
    let r = &model.report;
    if let Some(path) = &model.source_path {
        push(state, BReportLevel::Info, format!("Read blend: \"{path}\""));
    }
    push(state, BReportLevel::Info, r.duration_line());
    push(
        state,
        BReportLevel::Info,
        format!("Scene \"{}\" (file version {}) · {}", r.scene, r.file_version, r.stats_line()),
    );
    for w in &r.warnings {
        push(state, BReportLevel::Warning, w.clone());
    }
    state.set(CtxKey::Scene, r.scene.clone());
    let t = &model.timeline;
    state.set(CtxKey::Frame, t.current_frame.to_string());
    state.set(CtxKey::FrameStart, t.frame_start.to_string());
    state.set(CtxKey::FrameEnd, t.frame_end.to_string());
    state.set(CtxKey::Fps, t.fps.to_string());
    state.set(&BPath::owned(vec!["stats"]), r.stats_line());
}

/// Info log entry for a failed read (Blender: `Cannot read file "…": …`).
pub fn report_failed(state: &mut BState, path: Option<&str>, message: &str) {
    let text = match path {
        Some(p) => format!("Cannot read file \"{p}\": {message}"),
        None => message.to_string(),
    };
    push(state, BReportLevel::Error, text);
}
