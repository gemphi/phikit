//! Playback ticker (Blender `screen.animation_play`): while `CtxKey::Playing.path()` is
//! true, advance `CtxKey::Frame.path()` by one at the scene's fps (looping through the
//! reducer's frame-step rule) and redraw. One ticker at a time.

use crate::v2::state::{BKey as _, CtxKey};
use super::BPhiberApp;
use crate::v2::state::key::{float_or};
use crate::v2::state::{action::apply_action, val::V_TRUE};
use crate::v2::view::prim::BAction;
use gpui::Context;
use std::time::Duration;

impl BPhiberApp {
    pub(crate) fn ensure_playback(&mut self, cx: &mut Context<Self>) {
        if self.playing_ticker || self.state.get(CtxKey::Playing) != Some(V_TRUE) {
            return;
        }
        self.playing_ticker = true;
        let fps = float_or(&self.state, CtxKey::Fps, 24.0).clamp(1.0, 240.0);
        let period = Duration::from_secs_f32(1.0 / fps);
        cx.spawn(async move |this, cx| loop {
            cx.background_executor().timer(period).await;
            let go_on = this
                .update(cx, |app, cx| {
                    if app.state.get(CtxKey::Playing) != Some(V_TRUE) {
                        app.playing_ticker = false;
                        return false;
                    }
                    apply_action(&mut app.state, &BAction::Set(CtxKey::FrameStep.path(), "+1".into()));
                    cx.notify();
                    true
                })
                .unwrap_or(false);
            if !go_on {
                break;
            }
        })
        .detach();
    }
}
