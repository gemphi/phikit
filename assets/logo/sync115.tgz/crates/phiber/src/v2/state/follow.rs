//! Declarative follow-ups of a `Set`: when one key changes, these rules
//! write the keys that must change with it. Each rule is a row.

use crate::v2::state::{BKey as _, ActivityKey, CtxKey, ModalKey, View3dKey};
use super::key::{int_or};
use super::val::{V_EMPTY, V_MODAL_READER, V_MODAL_SETTINGS, V_MODAL_SPACES};
use super::{BPath, BState};

type Rule = fn(&mut BState, &str);

/// `(trigger key, rule)`. A table of key *makers*: a key's path is built
/// from its variant at run time, so the table can stay a constant.
const RULES: &[(fn() -> BPath, Rule)] = &[
    // A named viewpoint is the pair of angles that define it. Clicking the
    // compass's Z cap has to change the pitch, not the yaw, so the axis caps
    // write the viewpoint and this rule turns it into both angles.
    (|| View3dKey::View.path(), |s, name| {
        let Some((yaw, pitch)) = view_angles(name) else {
            return;
        };
        s.set(&crate::v2::scene::yaw_key(), yaw.to_string());
        s.set(&crate::v2::scene::pitch_key(), pitch.to_string());
        s.remove(View3dKey::View);
    }),
    // Activity entry chosen. A grouping opens its secondary strip beside the
    // rail — clicking the same icon again closes it; everything else goes
    // straight to its declared destination.
    (|| ActivityKey::Tab.path(), |s, label| {
        use crate::v2::part::activity::options;
        if options::grouping_named(label).is_some() {
            if s.get(ActivityKey::Group) == Some(label) {
                s.remove(ActivityKey::Group);
            } else {
                s.set(ActivityKey::Group, label.to_string());
            }
            return;
        }
        s.remove(ActivityKey::Group);
        let entry = crate::v2::part::activity::set::ENTRIES.iter().find(|e| e.label == label);
        if let Some(modal) = entry.and_then(|e| e.modal) {
            s.set(ModalKey::Open, modal);
        }
    }),
    // An option chosen from the secondary strip, as `"<entry>:<option>"`.
    (|| ActivityKey::Pick.path(), |s, pick| {
        use crate::v2::part::activity::{options, set::BActivityOptions};
        let Some((entry, option)) = pick.split_once(':') else { return };
        let Some(entry) = options::grouping_named(entry) else { return };
        match entry.options {
            BActivityOptions::Spaces => {
                if let Some(space) = crate::v2::space::BSpaceType::ALL
                    .iter()
                    .find(|sp| sp.label() == option)
                {
                    s.set(CtxKey::Space, space.slug());
                }
            }
            // A category picked here selects the Preferences tab AND raises
            // the screen that shows it, so one click lands somewhere.
            BActivityOptions::Settings => {
                s.set(&options::prefs_tab_key(), option.to_string());
                s.set(ModalKey::Open, V_MODAL_SETTINGS);
            }
            BActivityOptions::None => {}
        }
        s.remove(ActivityKey::Pick);
    }),
    // Transport: step / jump the current frame inside the scene range,
    // wrapping like Blender's looping playback.
    (|| CtxKey::FrameStep.path(), |s, step| {
        // Blender's factory range until a file sets its own.
        let a = int_or(s, CtxKey::FrameStart, 1);
        let b = int_or(s, CtxKey::FrameEnd, 250).max(a);
        let cur = int_or(s, CtxKey::Frame, a);
        let next = match step {
            "start" => a,
            "end" => b,
            d => match d.parse::<i32>() {
                Ok(d) if cur + d > b => a,
                Ok(d) if cur + d < a => b,
                Ok(d) => cur + d,
                Err(_) => cur,
            },
        };
        s.set(CtxKey::Frame, next.to_string());
        s.remove(CtxKey::FrameStep);
    }),
    // A document named opens the reader over whatever modal was up — the
    // welcome window, Help, About — and remembers it for the way back.
    (|| ModalKey::ReaderDoc.path(), |s, slug| {
        if slug.is_empty() || s.get(ModalKey::Open) == Some(V_MODAL_READER) {
            return;
        }
        match s.get(ModalKey::Open).filter(|m| !m.is_empty()) {
            Some(under) => s.set(ModalKey::ReaderReturn, under.to_string()),
            None => s.remove(ModalKey::ReaderReturn),
        }
        s.set(ModalKey::Open, V_MODAL_READER);
    }),
    // Closing the reader puts back the modal it covered.
    (|| ModalKey::Open.path(), |s, value| {
        if !value.is_empty() {
            return;
        }
        if let Some(back) = s.get(ModalKey::ReaderReturn).map(str::to_string) {
            s.remove(ModalKey::ReaderReturn);
            s.set(ModalKey::Open, back);
        }
    }),
    // A space picked from the Spaces dialog closes it.
    (|| CtxKey::Space.path(), |s, _| {
        if s.get(ModalKey::Open) == Some(V_MODAL_SPACES) {
            s.set(ModalKey::Open, V_EMPTY);
        }
    }),
];

pub fn after_set(state: &mut BState, path: &BPath, value: &str) {
    for (key, rule) in RULES {
        if key() == *path {
            rule(state, value);
        }
    }
}

/// The yaw and pitch of each named viewpoint, in Blender's convention:
/// the front view looks along +Y, and the top view looks straight down.
pub fn view_angles(name: &str) -> Option<(f32, f32)> {
    Some(match name {
        "front" => (0.0, 0.0),
        "back" => (180.0, 0.0),
        "right" => (90.0, 0.0),
        "left" => (270.0, 0.0),
        "top" => (0.0, 90.0),
        "bottom" => (0.0, -90.0),
        _ => return None,
    })
}
