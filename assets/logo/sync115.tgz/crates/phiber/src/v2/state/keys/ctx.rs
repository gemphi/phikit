//! The context keys — Blender's `bContext`: which workspace, scene, view
//! layer, object, mode and tool are active, and where the frame is.
//! Top-level paths, `ctx.<field>`.

use super::BKey;
use crate::v2::state::BPath;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum CtxKey {
    /// The active workspace (`BSpaceType::slug`).
    Space,
    Scene,
    ViewLayer,
    /// The active object's name.
    Object,
    /// The interaction mode (Object, Edit, Sculpt, …).
    Mode,
    /// The active tool.
    Tool,
    /// The current frame.
    Frame,
    /// `"true"` while playing back.
    Playing,
    /// A transport request (`start`, `end`, `+1`, `-1`), consumed by `follow`.
    FrameStep,
    FrameStart,
    FrameEnd,
    Fps,
}

impl BKey for CtxKey {
    fn path(&self) -> BPath {
        let seg: &'static str = match self {
            Self::Space => "space",
            Self::Scene => "scene",
            Self::ViewLayer => "view_layer",
            Self::Object => "object",
            Self::Mode => "mode",
            Self::Tool => "tool",
            Self::Frame => "frame",
            Self::Playing => "playing",
            Self::FrameStep => "frame_step",
            Self::FrameStart => "frame_start",
            Self::FrameEnd => "frame_end",
            Self::Fps => "fps",
        };
        BPath::owned(vec![seg])
    }
}
