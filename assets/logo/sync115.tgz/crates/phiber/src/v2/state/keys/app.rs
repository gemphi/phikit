//! The window's own keys — things that belong to the app rather than to a
//! Blender editor: the window, the theme, links, typing, the command
//! palette, the status log and the collaboration session.

use super::BKey;
use crate::v2::state::BPath;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum AppKey {
    /// The window's width, for narrow-layout decisions.
    WindowWidth,
    /// The theme's slug.
    Theme,
    UseGradients,
    /// A URL to hand to the system browser (`wm.url_open`); side effect only.
    Link,
    /// The key of the field that has the caret, if any.
    Edit,
    /// What that field held when typing started, for Escape.
    EditUndo,
    /// The command palette's filter text.
    CommandQuery,
    /// Whether the status bar's action log is unfolded.
    StatusLogOpen,
    /// A profile field: `ctx.profile.<field>`.
    Profile(&'static str),
    /// The collaboration session's status (`online` / `offline`).
    CollabStatus,
    CollabServer,
    /// One peer of the session: `ctx.collab.peer.<n>`.
    CollabPeer(&'static str),
}

impl BKey for AppKey {
    fn path(&self) -> BPath {
        match self {
            Self::WindowWidth => BPath::owned(vec!["window", "width"]),
            Self::Theme => BPath::owned(vec!["theme"]),
            Self::UseGradients => BPath::owned(vec!["use_gradients"]),
            Self::Link => BPath::owned(vec!["link"]),
            Self::Edit => BPath::owned(vec!["edit"]),
            Self::EditUndo => BPath::owned(vec!["edit_undo"]),
            Self::CommandQuery => BPath::owned(vec!["command", "query"]),
            Self::StatusLogOpen => BPath::owned(vec!["status", "log", "open"]),
            Self::Profile(field) => BPath::owned(vec!["profile", field]),
            Self::CollabStatus => BPath::owned(vec!["collab", "status"]),
            Self::CollabServer => BPath::owned(vec!["collab", "server"]),
            Self::CollabPeer(n) => BPath::owned(vec!["collab", "peer", n]),
        }
    }
}
