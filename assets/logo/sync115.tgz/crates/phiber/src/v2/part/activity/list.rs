//! `BActivityList` — entries grouped into three regions (Top / Center /
//! Bottom) per each entry's `BActivityGroup`, emitted as ONE `BView::Rail` —
//! the same strip element the Toolbar, the NavBar and the Sidebar use. Active
//! is read from `ctx.activity.tab`.

use crate::v2::state::{BKey as _, ActivityKey};
use super::options;
use super::set::{BActivityGroup, ENTRIES};
use crate::v2::state::{BState};
use crate::v2::view::{BView, BViewList};
use crate::v2::view::prim::{
    BAction, BControl, BRailEntry, BRailGroup, BRailKind, BRailSide, BRailView,
};

#[derive(Clone, Copy, Debug, Default)]
pub struct BActivityList;

impl BActivityList {
    pub fn new() -> Self {
        Self
    }

    fn group(g: BActivityGroup) -> BRailGroup {
        match g {
            BActivityGroup::Top => BRailGroup::Top,
            BActivityGroup::Center => BRailGroup::Center,
            BActivityGroup::Bottom => BRailGroup::Bottom,
        }
    }

    /// The whole strip as one view.
    pub fn rail(&self, s: &BState) -> BView {
        let active = s.get(ActivityKey::Tab);
        let entries: Vec<BRailEntry> = ENTRIES
            .iter()
            .map(|e| {
                // Selecting an entry records it; the reducer opens the
                // entry's declared modal (`set.rs`).
                let action = BAction::Set(ActivityKey::Tab.path(), e.label.to_string());
                // A grouping reads as active while its strip is open, so the
                // rail shows which column beside it belongs to which icon.
                let lit = Some(e.label) == active
                    || options::open_group(s).is_some_and(|open| open.label == e.label);
                BRailEntry {
                    control: BControl::new()
                        .with_icon(e.icon)
                        .with_label(e.label)
                        .with_active(lit)
                        .with_action(action),
                    group: Self::group(e.group),
                }
            })
            .collect();
        BView::rail(BRailView {
            kind: BRailKind::Activity,
            side: BRailSide::Left,
            expanded: false,
            entries,
        })
    }

    /// The secondary strip: the open entry's options, or nothing.
    ///
    /// It is a rail like the primary one — same element, same treatment —
    /// but expanded, because an option is only useful with its name beside
    /// it. Its own bottom entry closes the group.
    pub fn group_strip(&self, s: &BState) -> BView {
        let Some(entry) = options::open_group(s) else {
            return BView::empty();
        };
        let entries: Vec<BRailEntry> = options::options_for(entry, s)
            .into_iter()
            .map(|control| BRailEntry { control, group: BRailGroup::Top })
            .collect();
        if entries.is_empty() {
            return BView::empty();
        }
        BView::rail(BRailView {
            kind: BRailKind::Activity,
            side: BRailSide::Left,
            expanded: true,
            entries,
        })
    }
}

impl BViewList for BActivityList {
    fn items(&self, _s: &BState) -> Vec<BView> {
        vec![]
    }
}
