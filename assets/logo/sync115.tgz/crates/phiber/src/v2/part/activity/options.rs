//! The activity bar's secondary strip — the options behind one primary icon.
//!
//! Every list here is a projection of a table the app already keeps, so the
//! strip cannot offer a workspace the space bar does not have, or a settings
//! category the Preferences nav bar does not have.
//!
//! Choosing an option writes one key, `ctx.activity.pick`, as
//! `"<entry>:<option>"`. `state::follow` turns that into the keys the choice
//! actually means — the same shape the compass's viewpoint caps use, and the
//! reason a row here needs no compound action.

use crate::v2::state::{BKey as _, ActivityKey, CtxKey};
use super::set::{BActivityEntry, BActivityOptions, ENTRIES};
use crate::v2::host::{BHostType, host_slug};
use crate::v2::modal::settings::CATEGORIES;
use crate::v2::space::BSpaceType;
use crate::v2::state::{
    BPath, BState,
};
use crate::v2::view::prim::{BAction, BControl};

/// The Preferences nav-bar tab key, so a category chosen here selects the
/// same tab the Preferences screen reads.
pub fn prefs_tab_key() -> BPath {
    BPath::owned(vec![host_slug(BHostType::Prefs), "navbar", "tab"])
}

/// One entry's options, in the order its own screen lists them.
pub fn options_for(entry: &BActivityEntry, s: &BState) -> Vec<BControl> {
    let pick = |label: &str| {
        BAction::Set(ActivityKey::Pick.path(), format!("{}:{}", entry.label, label))
    };
    match entry.options {
        BActivityOptions::Spaces => {
            let active = s.get(CtxKey::Space);
            BSpaceType::ALL
                .iter()
                .map(|space| {
                    BControl::new()
                        .with_icon(space.icon())
                        .with_label(space.label())
                        .with_active(Some(space.slug()) == active)
                        .with_action(pick(space.label()))
                })
                .collect()
        }
        BActivityOptions::Settings => {
            let active = s.get(&prefs_tab_key());
            CATEGORIES
                .iter()
                .map(|category| {
                    BControl::new()
                        .with_icon(category.icon)
                        .with_label(category.label)
                        .with_active(Some(category.label) == active)
                        .with_action(pick(category.label))
                })
                .collect()
        }
        BActivityOptions::None => Vec::new(),
    }
}

/// True when this entry opens a secondary strip rather than a destination.
pub fn is_grouping(entry: &BActivityEntry) -> bool {
    entry.options != BActivityOptions::None
}

/// The entry named by a label, when it is one that groups.
pub fn grouping_named(label: &str) -> Option<&'static BActivityEntry> {
    ENTRIES.iter().find(|e| e.label == label && is_grouping(e))
}

/// The entry whose strip is open, if any.
pub fn open_group(s: &BState) -> Option<&'static BActivityEntry> {
    grouping_named(s.get(ActivityKey::Group)?)
}
