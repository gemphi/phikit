//! View3D canvas composition; interaction and mesh painting live in focused helpers.

pub mod cache;
pub mod corner;
mod draw;
mod extras;
mod floor;
mod hit;
mod mesh;
mod object;
mod orbit;
pub(super) mod rendered;
pub use rendered::views_posted;
pub(super) use object::name as object_name;

use crate::v2::state::{CtxKey};
use self::hit::BHit;
pub use draw::on_gpu;
pub use mesh::rasterised;
use self::mesh::{BMesh, BMeshPalette};
use self::orbit::BOrbit;
use super::super::super::{color::to_hsla, ctx::BRenderCtx};
use crate::v2::scene::{
    project3_full, view_pan, view_pitch, view_yaw, view_zoom, zoom_key, zoom_step,
};
use crate::v2::view::prim::BAction;
use gpui::prelude::*;
use gpui::{
    AnyElement, ScrollDelta, ScrollWheelEvent, SharedString, canvas, div,
};
use std::rc::Rc;

pub struct BView3d;

impl BView3d {
    pub fn render(&self, c: &BRenderCtx) -> AnyElement {
        let grid = c.style.viewport_grid_stroke();
        let axis_x = c.style.axis_stroke(c.style.colors.axis_x);
        let axis_y = c.style.axis_stroke(c.style.colors.axis_y);
        let vp = to_hsla(c.style.viewport_surface());
        let zoom_handler = c.h.clone();
        let current_zoom = view_zoom(c.s);
        let mut element = div()
            .id(SharedString::from("view3d-canvas"))
            .debug_selector(|| "view3d-canvas".to_string())
            .flex_1()
            .min_h_0()
            .size_full()
            .relative()
            .overflow_hidden()
            .bg(vp)
            .on_scroll_wheel(move |event: &ScrollWheelEvent, window, app| {
                // Wheel thresholds and factors are input mechanics, not UI design.
                let delta = match event.delta {
                    ScrollDelta::Pixels(point) => f32::from(point.y),
                    ScrollDelta::Lines(point) => point.y * 20.0,
                };
                if delta.abs() < 0.5 {
                    return;
                }
                let factor = if delta > 0.0 { 1.1 } else { 1.0 / 1.1 };
                let next = zoom_step(current_zoom, factor);
                (Rc::clone(&zoom_handler))(
                    &BAction::Set(zoom_key(), next.to_string()),
                    window,
                    app,
                );
            });

        element = element
            .child(BOrbit.render(c));

        let yaw = view_yaw(c.s);
        let pitch = view_pitch(c.s);
        let pan = view_pan(c.s);
        let zoom = view_zoom(c.s);
        let active = c.s.get(CtxKey::Object).unwrap_or("Cube").to_string();
        let panel = c.style.colors.bg_panel;
        let palette = BMeshPalette {
            shading: crate::v2::scene::view_shading(c.s),
            cube: to_hsla(c.style.shade(panel, c.style.effects.node_grid_alpha)),
            sphere: to_hsla(c.style.shade(
                panel,
                c.style.effects.node_grid_alpha + c.style.effects.sheen_lift,
            )),
            gem: to_hsla(c.style.colors.accent_soft),
            loaded: to_hsla(c.style.colors.bg_active),
            accent: to_hsla(c.style.colors.accent),
        };
        let hidden = crate::v2::part::custom::outliner::keys::BHidden::now(c.s);
        // The shared list, not a fresh copy: the overlay and the outliner read
        // the same one this pass (`scene_objects`).
        let scene: Vec<_> = crate::v2::scene::scene_objects(c.s)
            .iter()
            .filter(|object| !hidden.hides(c.s, mesh::name(object)))
            .cloned()
            .collect();
        // Every projection below runs through this frame's camera.
        let setup = crate::v2::scene::camera::setup_from_state(c.s);
        crate::v2::scene::camera::with_view(setup, || {
        let floor_lines = floor::lines(
            (yaw, pitch, pan, zoom),
            setup,
            crate::v2::scene::camera::view_pivot(c.s),
            floor::BFloorPalette {
                grid: to_hsla(grid.color),
                axis_x: to_hsla(axis_x.color),
                axis_y: to_hsla(axis_y.color),
            },
        );
        let mut hits = Vec::new();
        for object in &scene {
            let (x, y) = mesh::ground(object);
            let (screen_x, screen_y, _) =
                project3_full(x, 0.0, y, yaw, pitch, pan, zoom);
            hits.push((screen_x, screen_y, mesh::name(object).to_string()));
        }
        hits.sort_by(|left, right| {
            right
                .1
                .partial_cmp(&left.1)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        let studio = draw::studio(palette.shading);
        let draw::BPlan { ray, cpu_draws, mode } = draw::plan(palette.shading, &scene, &palette);
        let ray_view = rendered::BRayView {
            yaw, pitch, pan, zoom, setup,
            sky: vp,
            grid: to_hsla(grid.color),
            studio,
            // Blender draws unselected wires in the theme's wire colour and
            // the active object in `wire_active`; the kernel carries one wire
            // colour, so it takes the neutral one.
            wire: to_hsla(c.style.colors.text_dim),
            mode,
        };
        // Projecting every vertex is the most expensive thing a frame does,
        // and it depends only on the camera, the palette and the scene — none
        // of which a resize or a space change touches, so `cache` memoises it.
        let meshes = cache::meshes(cpu_draws, &scene, (yaw, pitch, pan, zoom), palette, &active);
        // No sort. Ordering objects by the depth of their origin is what hid
        // a character's clothes: one number per object cannot say which of
        // two interleaved surfaces is nearer at a given pixel. The depth
        // buffer answers that per pixel, so the order they arrive in stops
        // mattering (`mesh::raster`).
        let outline_width = c.style.strokes.border * 2.0;
        let wire = palette.shading == crate::v2::scene::BShading::Wireframe;
        let extra_lines = extras::project(
            c.s,
            yaw,
            pitch,
            pan,
            zoom,
            extras::BExtraPalette::from_style(c),
        );
        element = element.child(
            canvas(
                |_, _, _| {},
                move |bounds, _, window, _| {
                    let (w, h) = (f32::from(bounds.size.width), f32::from(bounds.size.height));
                    if h > 0.0 && crate::v2::scene::camera::note_aspect(w / h) {
                        window.refresh();
                    }
                    if ray {
                        rendered::paint(bounds, ray_view, window);
                    } else {
                        extras::paint(bounds, &floor_lines, 1.0, window);
                    }
                    BMesh::paint(bounds, &meshes, outline_width, wire, yaw, pitch, window);
                    extras::paint(bounds, &extra_lines, outline_width * 0.5, window);
                },
            )
            .absolute()
            .inset_0()
            .size_full(),
        );
        for (x, y, name) in hits {
            element = element.child(BHit { x, y, name }.render(c));
        }
        // The canvas is the opaque surface that reaches the host's corners, so
        // it paints them itself. GPUI's clip is a rectangle, not a rounded
        // one, so `overflow_hidden` cannot round a child for us — the blue
        // surface was squaring off the zone's corners.
        corner::round_surface(element, c)
        })
            // Both overlays clear the floating strips, so neither collides
            // with the toolbar or the sidebar as those move or expand.
            .child(
                corner::BCorner::TopLeft
                    .place(div().absolute(), c)
                    .child(super::overlay::BOverlay.render(c)),
            )
            .child(
                corner::gizmo_corner(c)
                    .place(div().absolute(), c)
                    .child(super::gizmo::BGizmo.compass(c)),
            )
            .child(
                corner::gizmo_corner(c)
                    .flipped()
                    .place(div().absolute(), c)
                    .child(super::gizmo::BGizmo.controls(c)),
            )
            .into_any_element()
    }
}

use crate::v2::view::render::gpui::prim::render_contract::BFocusedRenderer;

impl BFocusedRenderer for BView3d {
    fn render(&self, c: &crate::v2::view::render::gpui::ctx::BRenderCtx) -> gpui::AnyElement {
        BView3d::render(self, c)
    }
}
