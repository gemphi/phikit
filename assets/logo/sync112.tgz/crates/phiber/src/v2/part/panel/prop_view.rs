//! Blender ref: `uiItemR` — every RNA prop renders as label + kind-specific
//! control. A property's kind (`BPropKind`) picks the control (`BCtrlKind`);
//! the control reads its value from `ctx.buts.<key>` as the value category
//! it edits and writes back through `BAction::Set`. So the render engine, a
//! sample count, a colour and a name are one mechanism: a control over a
//! typed key. Choosing Phiray is `Set(ctx.buts.engine, "PHIRAY")`.

use super::prop::{BEnumItem, BPropKind, BPropSpec};
use crate::v2::state::{BKey as _, BPath, BState, ButsKey, val::BValue};
use crate::v2::view::BView;
use crate::v2::view::prim::{BCtrl, BCtrlKind, BOption, BPanelRole};

/// State key that stores the value of `spec`. Segments live under `buts` so
/// all Property-panel values share one root and can be introspected
/// uniformly.
pub fn value_key(spec: &BPropSpec) -> BPath {
    ButsKey::Value(spec.key).path()
}

/// State key gating whether the dropdown for `spec` is open.
fn open_key(spec: &BPropSpec) -> BPath {
    ButsKey::Dropdown(spec.key).path()
}

fn options(items: &'static [BEnumItem]) -> impl Iterator<Item = BOption> {
    items.iter().map(|i| BOption { key: i.key.to_string(), label: i.label.to_string(), icon: String::new() })
}

/// The control a property kind is edited with, and its factory value.
fn ctrl_for(kind: BPropKind) -> (BCtrlKind, BValue) {
    match kind {
        BPropKind::Bool => (BCtrlKind::Check, BValue::Bool(false)),
        BPropKind::Int { min, max } => (BCtrlKind::Int { min, max }, BValue::Int(min.max(0).min(max))),
        BPropKind::Float { .. } => (
            BCtrlKind::Number { min: f32::MIN, max: f32::MAX, step: 0.1 },
            BValue::Float(0.0),
        ),
        BPropKind::Enum(items) => (
            BCtrlKind::Select,
            BValue::Enum(items.first().map(|i| i.key).unwrap_or("").to_string()),
        ),
        BPropKind::Str | BPropKind::Pointer { .. } => (BCtrlKind::Text, BValue::Text(String::new())),
        BPropKind::Color { .. } => (BCtrlKind::Color, BValue::Color([0.8, 0.8, 0.8, 1.0])),
        // Vectors are one control per axis (below); this is the axis's kind.
        BPropKind::Vec3 { .. } | BPropKind::Vec4 { .. } => (
            BCtrlKind::Number { min: f32::MIN, max: f32::MAX, step: 0.1 },
            BValue::Float(0.0),
        ),
    }
}

/// One control over `key`, read from the state.
fn control(spec: &BPropSpec, key: BPath, s: &BState) -> BCtrl {
    let (kind, default) = ctrl_for(spec.kind);
    let mut ctrl = BCtrl::read(kind, key, default, s);
    match spec.kind {
        BPropKind::Enum(items) => {
            ctrl = ctrl.with_options(options(items)).with_menu(open_key(spec), s);
        }
        BPropKind::Pointer { target } => ctrl = ctrl.with_label(target),
        _ => {}
    }
    ctrl
}

fn value(spec: &BPropSpec, s: &BState) -> BView {
    let axes: &[&str] = match spec.kind {
        BPropKind::Vec3 { .. } => &["x", "y", "z"],
        BPropKind::Vec4 { .. } => &["r", "g", "b", "a"],
        _ => return BView::ctrl(control(spec, value_key(spec), s)),
    };
    BView::row(
        axes.iter()
            .map(|axis| BView::ctrl(control(spec, ButsKey::Axis(spec.key, axis).path(), s)))
            .collect(),
    )
}

pub fn prop_row(spec: &BPropSpec, s: &BState) -> BView {
    // A property row is a Panel with role `Section` so the renderer splits it
    // 50/50 (label left, control right) — Blender's `uiItemR` split factor.
    BView::panel(BPanelRole::Section, vec![BView::label(spec.label), value(spec, s)])
}
