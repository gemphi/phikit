//! The outliner's rows keep their height, its lines run the whole list, and
//! every level that holds something can be opened.

use phiber::v2::state::{BKey as _, OutlinerKey};
use phiber::v2::part::custom::outliner::tree;
use phiber::v2::state::{BState, val::V_TRUE};
use phiber::v2::view::{BView, BViewItem};

fn rows(s: &BState) -> Vec<tree::BOutlineRow> {
    tree::flatten(s)
}

fn source(relative: &str) -> String {
    std::fs::read_to_string(
        std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("src/v2").join(relative),
    )
    .unwrap_or_else(|error| panic!("{relative}: {error}"))
}

#[test]
fn a_data_row_can_be_opened_and_holds_what_the_mesh_has() {
    let mut s = BState::new();
    let object = rows(&s)
        .into_iter()
        .find(|r| r.depth == 2)
        .expect("an object row");
    s.set(&OutlinerKey::Expanded(object.id).path(), V_TRUE);

    let data = rows(&s)
        .into_iter()
        .find(|r| r.depth == 3)
        .expect("the object's data row");
    assert!(
        data.expanded.is_some(),
        "the third level must carry a disclosure arrow, not read as a leaf"
    );

    s.set(&OutlinerKey::Expanded(data.id).path(), V_TRUE);
    let held: Vec<String> = rows(&s)
        .into_iter()
        .filter(|r| r.depth == 4)
        .map(|r| r.label)
        .collect();
    assert_eq!(held, vec!["Vertex Groups", "UV Maps", "Material"]);
}

#[test]
fn a_row_never_shrinks_and_the_list_scrolls_instead() {
    let tree_src = source("view/render/gpui/prim/tree.rs");
    assert!(
        tree_src.contains(".flex_shrink_0()"),
        "a tree row must keep its height when the host is short"
    );
    let column = source("view/render/gpui/prim/column.rs");
    assert!(
        column.contains(".overflow_y_scroll()"),
        "the list scrolls rather than squashing its rows"
    );
}

#[test]
fn the_hierarchy_lines_run_the_whole_list() {
    let guide = source("view/render/gpui/prim/tree/guide.rs");
    // A backdrop spanning the container, not a segment inside each row —
    // per-row guides stop where the content does.
    assert!(guide.contains(".absolute().inset_0()"));
    let column = source("view/render/gpui/prim/column.rs");
    assert!(
        column.contains("guides_backdrop"),
        "the list must paint the guides behind its rows"
    );
}

#[test]
fn every_data_block_icon_has_an_asset() {
    let icons = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("assets/icons");
    let mut s = BState::new();
    let object = rows(&s).into_iter().find(|r| r.depth == 2).unwrap();
    s.set(&OutlinerKey::Expanded(object.id).path(), V_TRUE);
    let data = rows(&s).into_iter().find(|r| r.depth == 3).unwrap();
    s.set(&OutlinerKey::Expanded(data.id).path(), V_TRUE);
    for row in rows(&s) {
        assert!(
            icons.join(format!("{}.svg", row.icon)).exists(),
            "outliner row {:?} has no icon asset ({})",
            row.label,
            row.icon
        );
    }
    let _ = BView::Empty;
    let _: fn(&BState) -> BView =
        |s| phiber::v2::part::custom::outliner::BOutlinerItem::new().build(s);
}
