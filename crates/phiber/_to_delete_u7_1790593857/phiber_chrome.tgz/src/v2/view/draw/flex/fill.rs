//! `BFill` — what a container paints behind its children, as a token.
//!
//! Split out of `token.rs` for the file cap. A fill is always a name for a
//! decision the theme owns (a surface tone, a host's header, the shared item
//! hover), never a colour written at the call site.

use super::super::color::{resolved_gradient, to_hsla};
use super::super::ctx::BRenderCtx;
use super::ink::BInk;
use crate::v2::theme::BSurfaceTone;
use crate::v2::view::prim::BRowShade;
use gpui::Background;

/// What a container paints behind its children.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BFill {
    /// Explicitly nothing.
    Clear,
    /// The gutter showing between zones.
    Gutter,
    /// The current host's body — the panel shade for an editor, the chrome
    /// shade for a bar or a rail (`host_background`).
    HostBody,
    /// A vertical icon rail — the Properties navbar, the activity rail: the
    /// chrome shade, flat (`strip_gradient_soft`).
    HostRail,
    /// A semantic surface tone (modal, header, …).
    Tone(BSurfaceTone),
    /// A heading over a tone's surface, a step over it (`heading_surface`).
    Heading(BSurfaceTone),
    /// The current host's header surface.
    HostHeader,
    /// The current host's strip gradient.
    HostStrip,
    /// Chrome floating over a canvas: the panel colour, translucent enough
    /// for the canvas to show through (Blender's floating panels).
    Floating,
    /// The dim laid over the workspace behind a modal.
    ModalDim,
    /// A value's own colour — a colour control's swatch. RGBA, 0..1.
    Swatch([f32; 4]),
    /// An ink, as a fill — the filled part of a drawn glyph.
    Ink(BInk),
    /// A rule between things: the theme's separator shade, as a hairline
    /// divider's whole surface.
    Separator,
    /// A tone's own colour with no sweep over it — a well sunk into a
    /// surface rather than a surface raised off one. A progress track is the
    /// case: a sweep on it would read as fill that is not there.
    Flat(BSurfaceTone),
    /// What a row of this shade paints at rest, and what it paints under the
    /// pointer — the one mapping the tree, the list and the table share
    /// (`tone::row_fill` / `tone::row_hover`). `Row` is `Clear` for a shade
    /// that lets its surface through.
    Row(BRowShade),
    RowHover(BRowShade),
    /// The one hover every selectable thing outside a header strip answers
    /// with (`tone::item_hover`). Controls *inside* a strip are a separate,
    /// deliberate family and go through `chrome::paint` instead.
    ItemHover,
    /// The shade a control wears while it is the chosen one — the sorted
    /// column's heading, a pressed toggle.
    ControlActive,
}

impl BFill {
    pub(super) fn background(self, ctx: &BRenderCtx) -> Background {
        match self {
            Self::Clear => gpui::transparent_black().into(),
            Self::Gutter => to_hsla(ctx.style.resize_gutter_background()).into(),
            Self::HostBody => to_hsla(ctx.style.host_background(ctx.host)).into(),
            Self::HostRail => resolved_gradient(ctx.style.strip_gradient_soft(ctx.host)),
            Self::Tone(tone) => resolved_gradient(ctx.style.surface(tone)),
            Self::Heading(tone) => resolved_gradient(ctx.style.heading_surface(tone)),
            Self::HostHeader => resolved_gradient(ctx.style.host_header_surface(ctx.host)),
            Self::HostStrip => resolved_gradient(ctx.style.strip_gradient(ctx.host)),
            Self::ModalDim => to_hsla(ctx.style.colors.bg_modal_dim).into(),
            Self::Swatch([r, g, b, a]) => gpui::Rgba { r, g, b, a }.into(),
            Self::Ink(ink) => ink.color(ctx).into(),
            Self::Separator => to_hsla(ctx.style.colors.sep).into(),
            Self::Flat(tone) => to_hsla(ctx.style.surface(tone).bottom).into(),
            Self::ItemHover => to_hsla(super::super::tone::item_hover(ctx)).into(),
            Self::Row(shade) => match super::super::tone::row_fill(shade, ctx) {
                Some(fill) => to_hsla(fill).into(),
                None => gpui::transparent_black().into(),
            },
            Self::RowHover(shade) => to_hsla(super::super::tone::row_hover(shade, ctx)).into(),
            Self::ControlActive => to_hsla(ctx.style.colors.bg_active).into(),
            Self::Floating => {
                let base = to_hsla(ctx.style.colors.bg_panel);
                gpui::hsla(base.h, base.s, base.l, ctx.style.effects.floating_alpha).into()
            }
        }
    }
}
