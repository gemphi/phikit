//! `BFlex` itself: the record of one container's layout decisions, and the
//! builder the levels describe themselves with.

use super::token::{BAlign, BBasis, BEdge, BFill, BInk, BJustify, BLen, BOverflow, BPlace, BRadius, BSpace, BType};
// (`BEdge`, `BFill`, `BRadius`, `BType` are the record's field types; their
// builder methods live in `surface.rs`.)
use crate::v2::theme::BElevation;
use crate::v2::view::layout::BAxis;

/// The complete description of one container. Fields left `None` are not
/// decided here and fall to the defaults.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BFlex {
    pub axis: Option<BAxis>,
    /// Children that do not fit on the axis start a new line (a header
    /// too narrow for its menus puts them under its switcher).
    pub wrap: bool,
    pub grow: Option<f32>,
    pub shrink: Option<f32>,
    pub basis: Option<BBasis>,
    pub width: Option<BLen>,
    pub height: Option<BLen>,
    pub min_width: Option<BLen>,
    pub min_height: Option<BLen>,
    pub max_width: Option<BLen>,
    pub align: Option<BAlign>,
    pub justify: Option<BJustify>,
    pub gap: Option<BSpace>,
    pub pad_top: Option<BSpace>,
    pub pad_right: Option<BSpace>,
    pub pad_bottom: Option<BSpace>,
    pub pad_left: Option<BSpace>,
    pub margin_left: Option<BSpace>,
    pub margin_right: Option<BSpace>,
    pub margin_top: Option<BSpace>,
    pub margin_bottom: Option<BSpace>,
    /// Raised above its parent's alignment by this much of its own margin.
    pub raised_by: Option<BSpace>,
    pub fill: Option<BFill>,
    /// What it paints under the pointer. Written here so a hover is a token
    /// like any other fill, rather than a `.hover(|s| s.bg(…))` written out
    /// wherever a hoverable thing happens to be built.
    pub hover_fill: Option<BFill>,
    pub border: Option<BEdge>,
    pub radius: Option<BRadius>,
    /// How far off the workspace this sits, and so what it casts. `Base` is
    /// in the plane and casts nothing (`theme::BElevation`).
    pub elevation: BElevation,
    pub ink: Option<BInk>,
    pub type_size: Option<BType>,
    pub place: BPlace,
    pub overflow: BOverflow,
    /// Swallows pointer events so what lies beneath does not see them.
    pub occludes: bool,
    /// Drawn at half strength — a hint, not a control (Blender's panel grip).
    pub dimmed: bool,
    /// The hover group this container names, for parts shown on hover.
    pub group: Option<&'static str>,
    /// Shown only while the pointer is over the named group.
    pub revealed_by: Option<&'static str>,
}

impl BFlex {
    /// A flex container laid out along `axis`, deciding nothing else yet.
    pub const fn along(axis: BAxis) -> Self {
        Self {
            axis: Some(axis),
            ..Self::NOTHING
        }
    }

    /// A row.
    pub const fn row() -> Self {
        Self::along(BAxis::Row)
    }

    /// A column.
    pub const fn column() -> Self {
        Self::along(BAxis::Column)
    }

    /// A plain box: no flex container of its own, only its own size and place.
    pub const fn cell() -> Self {
        Self::NOTHING
    }

    const NOTHING: Self = Self {
        axis: None,
        wrap: false,
        grow: None,
        shrink: None,
        basis: None,
        width: None,
        height: None,
        min_width: None,
        min_height: None,
        max_width: None,
        align: None,
        justify: None,
        gap: None,
        pad_top: None,
        pad_right: None,
        pad_bottom: None,
        pad_left: None,
        margin_left: None,
        margin_right: None,
        margin_top: None,
        margin_bottom: None,
        raised_by: None,
        fill: None,
        hover_fill: None,
        border: None,
        radius: None,
        elevation: BElevation::Base,
        ink: None,
        type_size: None,
        place: BPlace::Flow,
        overflow: BOverflow::Visible,
        occludes: false,
        group: None,
        revealed_by: None,
        dimmed: false,
    };

    pub const fn width(mut self, len: BLen) -> Self {
        self.width = Some(len);
        self
    }

    pub const fn height(mut self, len: BLen) -> Self {
        self.height = Some(len);
        self
    }

    /// The whole of the parent on both axes.
    pub const fn full(self) -> Self {
        self.width(BLen::Full).height(BLen::Full)
    }

    pub const fn min_width(mut self, len: BLen) -> Self {
        self.min_width = Some(len);
        self
    }

    pub const fn min_height(mut self, len: BLen) -> Self {
        self.min_height = Some(len);
        self
    }

    pub const fn max_width(mut self, len: BLen) -> Self {
        self.max_width = Some(len);
        self
    }

    /// May shrink below its content on both axes.
    pub const fn unclamped(self) -> Self {
        self.min_width(BLen::Zero).min_height(BLen::Zero)
    }

    // ── How it arranges its children ────────────────────────────────────

    pub const fn align(mut self, align: BAlign) -> Self {
        self.align = Some(align);
        self
    }

    pub const fn justify(mut self, justify: BJustify) -> Self {
        self.justify = Some(justify);
        self
    }

    pub const fn gap(mut self, space: BSpace) -> Self {
        self.gap = Some(space);
        self
    }

    pub const fn pad(self, space: BSpace) -> Self {
        self.pad_x(space).pad_y(space)
    }

    pub const fn pad_x(mut self, space: BSpace) -> Self {
        self.pad_left = Some(space);
        self.pad_right = Some(space);
        self
    }

    pub const fn pad_y(mut self, space: BSpace) -> Self {
        self.pad_top = Some(space);
        self.pad_bottom = Some(space);
        self
    }

    pub const fn pad_top(mut self, space: BSpace) -> Self {
        self.pad_top = Some(space);
        self
    }

    pub const fn pad_right(mut self, space: BSpace) -> Self {
        self.pad_right = Some(space);
        self
    }

    pub const fn pad_left(mut self, space: BSpace) -> Self {
        self.pad_left = Some(space);
        self
    }

    pub const fn pad_bottom(mut self, space: BSpace) -> Self {
        self.pad_bottom = Some(space);
        self
    }

    pub const fn margin_x(mut self, space: BSpace) -> Self {
        self.margin_left = Some(space);
        self.margin_right = Some(space);
        self
    }

    pub const fn margin_y(mut self, space: BSpace) -> Self {
        self.margin_top = Some(space);
        self.margin_bottom = Some(space);
        self
    }

    pub const fn margin_left(mut self, space: BSpace) -> Self {
        self.margin_left = Some(space);
        self
    }

    pub const fn raised_by(mut self, space: BSpace) -> Self {
        self.raised_by = Some(space);
        self
    }
}
