//! Animation — task 17. Reading actions and evaluating them at a frame.
//!
//! (a) object keyframes: [`read`] takes layered (4.4+) and legacy actions to
//!     [`fcurve::BFCurve`]s; [`channels`] writes them over a transform.
//! (b) pose-bone keyframes: [`pose`] builds each bone's basis and the plain
//!     `BKE_pose_where_is` chain.
//! (c) [`motion`]: every object's rest transform, bound curves and parent,
//!     solved to world matrices at a frame — what a player asks for.
//! (d) constraints and drivers — not yet. Rigify's deforming bones are moved
//!     by constraints, so a rigged character does not move until (c) lands.
//!
//! Every step is checked against Blender at several frames
//! (`tests/truth/thymus_anim.txt`, made by `truth/blender_anim.py`).

// Stages (b)–(d) above are written and checked against Blender but not yet
// wired to a player, so their entry points have no caller inside the crate
// (`pose`, `channels::basis_at`, the easing modes). This is staged work for
// task 17, not dead code: it goes when the stages land, not before.
#![allow(dead_code)]

pub mod channels;
pub mod drivers;
pub mod easing;
pub mod fcurve;
pub mod motion;
pub mod nla;
pub mod pose;
pub mod read;
pub mod summary;


#[cfg(test)]
mod tests;
