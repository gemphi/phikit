//! Focused tree family: indent, guide, disclosure, and row renderers.
//!
//! A tree is a table with indentation: a row's depth is a run of indent
//! units before its arrow slot, which every row keeps (a leaf's is blank,
//! as Blender reserves it), and the hierarchy lines that run down those
//! units are drawn once behind the whole column (`guide::guides_backdrop`),
//! so they reach the column's foot and no row draws a line of its own.

use super::atom;
use super::ctx::BRenderCtx;
use super::flex::{
    BAlign, BDim, BFill, BFlex, BFlexed, BJustify, BLen, BOverflow, BPlace, BRadius, BSpace, BType,
};
use super::walk;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BRowShade};
use gpui::prelude::*;
use gpui::AnyElement;

mod disclosure;
use self::disclosure::BTreeDisclosure;

mod guide;
pub use self::guide::guides_backdrop;

pub struct BTreeIndent(pub u16);

pub struct BTreeRow<'a> {
    pub depth: u16,
    pub expanded: Option<bool>,
    pub toggle: Option<&'a BAction>,
    /// Between the disclosure and the icon (a collection's checkbox).
    pub lead: &'a [BView],
    pub icon: &'a str,
    pub list: &'a [BView],
    pub trail: &'a [BView],
    pub shade: BRowShade,
}

impl BFlexed for BTreeIndent {
    fn flex(&self, ctx: &BRenderCtx) -> BFlex {
        // A run of indent units before the arrow slot. The hierarchy lines
        // that run down them are drawn once behind the whole column
        // (`guide::guides_backdrop`), so this is blank width and nothing else.
        BFlex::row()
            .width(BLen::Measured(ctx.style.dimensions.indent_unit * self.0 as f32))
            .keeps_size()
    }
}

impl BTreeIndent {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        self.flex(ctx).div(ctx).into_any_element()
    }
}

impl BTreeRow<'_> {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        let mut element = BTreeRowPart(self.shade).flex(ctx).div(ctx);
        element = element.child(BTreeIndent(self.depth).render(ctx));
        element = element.child(
            BTreeDisclosure {
                expanded: self.expanded,
                toggle: self.toggle,
            }
            .render(ctx),
        );
        for child in self.lead {
            element = element.child(walk(child, ctx));
        }
        element = element.child(BTreeIconSlot.flex(ctx).div(ctx).child(atom::icon(self.icon, ctx)));

        // The row is the control. Blender selects an outliner item by clicking
        // anywhere on its row and lights the whole row on hover; a labelled
        // button as the name cell gave the name its own hover fill inside the
        // row's, so only the text looked hovered. The name's action lifts to
        // the row and the name draws as plain text.
        let (select, cell_list) = match self.list.split_first() {
            Some((BView::Button(ctl), rest)) if ctl.icon.is_none() && ctl.action.is_some() => {
                (ctl.action.clone(), std::iter::once(BView::label(ctl.label.clone().unwrap_or_default())).chain(rest.iter().cloned()).collect::<Vec<_>>())
            }
            _ => (None, self.list.to_vec()),
        };
        let mut main = BTreeNameCells.flex(ctx).div(ctx);
        for child in &cell_list {
            main = main.child(walk(child, ctx));
        }
        element = element.child(main);

        if !self.trail.is_empty() {
            let mut trail = BTreeTrail.flex(ctx).div(ctx);
            for child in self.trail {
                trail = trail.child(walk(child, ctx));
            }
            element = element.child(trail);
        }
        let Some(action) = select else {
            return element.into_any_element();
        };
        let id = gpui::SharedString::from(super::button::element_id("tree-row", None, &action));
        let handler = ctx.handler.clone();
        let dbg = id.clone();
        element
            .id(id)
            .debug_selector(move || dbg.to_string())
            .cursor_pointer()
            .on_click(move |_event, window, app| {
                (std::rc::Rc::clone(&handler))(&action, window, app);
            })
            .into_any_element()
    }
}

/// The row band.
///
/// A tree row takes the same fills as the file list's rows and the table's,
/// resolved in one place (`BFill::Row` → `tone::row_fill`) — mapping the
/// shades here let the outliner drift to shades no other region used. A list
/// row is flat: a cap or a tab carries a sweep because it is a raised surface
/// handing its shade to the pane beside it, and a row in a tree is neither.
struct BTreeRowPart(BRowShade);

impl BFlexed for BTreeRowPart {
    fn flex(&self, ctx: &BRenderCtx) -> BFlex {
        BFlex::row()
            .width(BLen::Full)
            .height(BLen::Dim(BDim::RowHeight))
            .align(BAlign::Center)
            // A row keeps its height: when the host is short the list scrolls
            // (`column`) rather than squashing every row to fit.
            .keeps_size()
            .place(BPlace::Anchor)
            .radius(BRadius::Role(BStyleRole::MenuItem))
            .pad_right(BSpace::PadMd)
            .overflow(BOverflow::Clip)
            .fill(BFill::Row(self.0))
            // Every row answers the pointer, selected or not: a selected row
            // lightens off its own fill rather than going inert under it.
            .hovered(BFill::RowHover(self.0))
            .ink()
            .type_size(BType::Body)
    }
}

/// The icon slot, one indent unit wide so an icon sits in the same column as
/// the arrow above it.
struct BTreeIconSlot;

impl BFlexed for BTreeIconSlot {
    fn flex(&self, ctx: &BRenderCtx) -> BFlex {
        BFlex::row()
            .width(BLen::Measured(ctx.style.dimensions.indent_unit))
            .height(BLen::Full)
            .align(BAlign::Center)
            .justify(BJustify::Center)
            .keeps_size()
    }
}

/// The name and any cells after it — the part of the row that gives way when
/// the column narrows.
struct BTreeNameCells;

impl BFlexed for BTreeNameCells {
    fn flex(&self, _ctx: &BRenderCtx) -> BFlex {
        BFlex::row()
            .align(BAlign::Center)
            .fills()
            .min_width(BLen::Zero)
            .gap(BSpace::GapXs)
            .overflow(BOverflow::Clip)
    }
}

/// The restriction toggles at the row's end, which keep their size.
struct BTreeTrail;

impl BFlexed for BTreeTrail {
    fn flex(&self, _ctx: &BRenderCtx) -> BFlex {
        BFlex::row().align(BAlign::Center).keeps_size().gap(BSpace::GapXs)
    }
}
