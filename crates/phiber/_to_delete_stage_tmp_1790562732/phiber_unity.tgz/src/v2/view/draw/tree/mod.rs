//! Focused tree family: indent, guide, disclosure, and row renderers.
//!
//! A tree is a table with indentation: a row's depth is a run of indent
//! units before its arrow slot, which every row keeps (a leaf's is blank,
//! as Blender reserves it), and the hierarchy lines that run down those
//! units are drawn once behind the whole column (`guide::guides_backdrop`),
//! so they reach the column's foot and no row draws a line of its own.

use super::atom;
use super::color::to_hsla;
use super::ctx::BRenderCtx;
use super::walk;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::{BAction, BRowShade};
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

mod disclosure;
use self::disclosure::BTreeDisclosure;

mod guide;
pub use self::guide::guides_backdrop;

pub struct BTreeIndent(pub u16);

pub struct BTreeRow<'a> {
    pub depth: u16,
    pub expanded: Option<bool>,
    pub toggle: Option<&'a BAction>,
    /// Between the disclosure and the icon (a collection's checkbox).
    pub lead: &'a [BView],
    pub icon: &'a str,
    pub list: &'a [BView],
    pub trail: &'a [BView],
    pub shade: BRowShade,
}

impl BTreeIndent {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        self.render_with_unit(ctx.style.dimensions.indent_unit)
    }

    /// Render with the design-system default indent unit for callers that do
    /// not have a `BRenderCtx` (e.g. snapshot helpers). Uses the same value
    /// as `DEFAULT_DIMENSIONS.indent_unit` without importing legacy defaults.
    pub fn render_default(&self) -> AnyElement {
        // 20.0 matches DEFAULT_DIMENSIONS.indent_unit; kept as a named
        // constant here so grep finds it if the default ever changes.
        const DEFAULT_INDENT_UNIT: f32 = 20.0;
        self.render_with_unit(DEFAULT_INDENT_UNIT)
    }

    fn render_with_unit(&self, unit: f32) -> AnyElement {
        div()
            .flex_shrink_0()
            .w(px(unit * self.0 as f32))
            .into_any_element()
    }
}

impl BTreeRow<'_> {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        // A tree row takes the same fills as the file list's rows and the
        // table's, resolved in one place (`tone::row_fill`/`row_hover`) —
        // mapping the shades here let the outliner drift to shades no other
        // region used.
        let unit = ctx.style.dimensions.indent_unit;
        let mut element = div()
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .relative()
            .h(px(ctx.style.dimensions.row_height))
            // A row keeps its height: when the host is short the list scrolls
            // (`column`) rather than squashing every row to fit.
            .flex_shrink_0()
            .rounded(px(ctx.style.radius_for(BStyleRole::MenuItem)))
            .pr(px(ctx.style.spacing.pad_md))
            .overflow_hidden()
            .text_color(to_hsla(ctx.style.colors.text))
            .text_size(px(ctx.style.typography.body));
        // A list row is flat. A cap or a tab carries a sweep because it is
        // a raised surface handing its shade to the pane beside it; a row in
        // a tree is neither, so it takes the same flat selection tone the
        // file list uses and the outliner reads as one surface — the active
        // object's row a step lighter than the rest of the selection.
        if let Some(fill) = super::tone::row_fill(self.shade, ctx) {
            element = element.bg(to_hsla(fill));
        }
        // Every row answers the pointer, selected or not: a selected row
        // lightens off its own fill rather than going inert under it.
        let hover = to_hsla(super::tone::row_hover(self.shade, ctx));
        element = element.hover(move |style| style.bg(hover));

        element = element.child(BTreeIndent(self.depth).render(ctx));
        element = element.child(
            BTreeDisclosure {
                expanded: self.expanded,
                toggle: self.toggle,
            }
            .render(ctx),
        );
        for child in self.lead {
            element = element.child(walk(child, ctx));
        }
        element = element.child(
            div()
                .flex_shrink_0()
                .w(px(unit))
                .h_full()
                .flex()
                .items_center()
                .justify_center()
                .child(atom::icon(self.icon, ctx)),
        );

        // The row is the control. Blender selects an outliner item by clicking
        // anywhere on its row and lights the whole row on hover; a labelled
        // button as the name cell gave the name its own hover fill inside the
        // row's, so only the text looked hovered. The name's action lifts to
        // the row and the name draws as plain text.
        let (select, cell_list) = match self.list.split_first() {
            Some((BView::Button(ctl), rest)) if ctl.icon.is_none() && ctl.action.is_some() => {
                (ctl.action.clone(), std::iter::once(BView::label(ctl.label.clone().unwrap_or_default())).chain(rest.iter().cloned()).collect::<Vec<_>>())
            }
            _ => (None, self.list.to_vec()),
        };
        let mut main = div()
            .flex()
            .flex_row()
            .items_center()
            .flex_1()
            .min_w_0()
            .gap(px(ctx.style.spacing.gap_xs))
            .overflow_hidden();
        for child in &cell_list {
            main = main.child(walk(child, ctx));
        }
        element = element.child(main);

        if !self.trail.is_empty() {
            let mut trail = div()
                .flex()
                .flex_row()
                .items_center()
                .flex_shrink_0()
                .gap(px(ctx.style.spacing.gap_xs));
            for child in self.trail {
                trail = trail.child(walk(child, ctx));
            }
            element = element.child(trail);
        }
        let Some(action) = select else {
            return element.into_any_element();
        };
        let id = gpui::SharedString::from(super::button::element_id("tree-row", None, &action));
        let handler = ctx.handler.clone();
        let dbg = id.clone();
        element
            .id(id)
            .debug_selector(move || dbg.to_string())
            .cursor_pointer()
            .on_click(move |_event, window, app| {
                (std::rc::Rc::clone(&handler))(&action, window, app);
            })
            .into_any_element()
    }
}
