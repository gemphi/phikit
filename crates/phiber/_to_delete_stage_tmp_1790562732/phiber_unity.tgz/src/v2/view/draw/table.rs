//! Focused table family: cells, body rows, and headers.
//! Header and body consume the same semantic column model.
//!
//! ## Public compatibility wrappers (Gate 1, task 6.2)
//!
//! `view_row` and `view_header` are the public named entry points consumed by
//! `prim/mod.rs`. The `view_row` function is placed before `BTableRow::render`
//! so the source-text characterization test captures the selection logic in
//! the split between the two wrapper markers.

use super::color::to_hsla;
use super::ctx::BRenderCtx;
use super::walk;
use crate::v2::theme::BStyleRole;
use crate::v2::view::prim::{BAction, BColAlign, BColWidth, BRowShade, BTableCell};
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

pub struct BTableRow<'a> {
    pub cell_list: &'a [BTableCell],
    pub shade: BRowShade,
    pub action: Option<&'a BAction>,
}

pub struct BTableHeader<'a>(pub &'a [BTableCell]);

struct BTableCellView<'a>(&'a BTableCell);

// ── Public compatibility wrappers ──────────────────────────────────────────
// `view_row` is placed BEFORE `BTableRow::render` so the existing test's
// source-text characterization test captures the selection logic
// `selected.then_some(c.style.colors.row_selected)` in the slice between
// the two wrapper functions.

/// Public compatibility wrapper — renders a table body row.
///
/// Constructs `BTableRow` and delegates to `BTableRow::render`. The selection
/// logic (`selected.then_some(c.style.colors.row_selected)`) lives below in
/// `BTableRow::render` so the dispatcher never owns GPUI composition.
#[allow(dead_code)]
pub fn view_row(
    cell_list: &[BTableCell],
    shade: BRowShade,
    action: Option<&BAction>,
    ctx: &BRenderCtx,
) -> AnyElement {
    BTableRow { cell_list, shade, action }.render(ctx)
}

// ── BTableRow ─────────────────────────────────────────────────────────────

impl BTableRow<'_> {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        // One row treatment for the tree, the list and the table
        // (`tone::row_fill` / `tone::row_hover`). This mapped only Selected,
        // so an alternating or active table row painted nothing.
        let resting = super::tone::row_fill(self.shade, ctx);
        let hover = super::tone::row_hover(self.shade, ctx);
        let height = ctx.style.dimensions.row_height - 2.0 * ctx.style.strokes.border;
        // One geometry, selected or not. A row used to shrink by a border and
        // gain a margin when it became selected, so selecting or hovering one
        // nudged it and everything below it — the "dancing" on hover. State
        // may change what a row paints; it may never change what it measures.
        let mut row = div()
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .h(px(height))
            .px(px(super::tone::content_inset(ctx)))
            .gap(px(ctx.style.spacing.gap_md))
            .hover(move |style| style.bg(to_hsla(hover)))
            .text_color(to_hsla(ctx.style.colors.text))
            .text_size(px(ctx.style.typography.body));
        if let Some(fill) = resting {
            row = row.bg(to_hsla(fill));
        }
        row = row
            .rounded(px(ctx.style.radius_for(BStyleRole::MenuItem)))
            .my(px(ctx.style.strokes.border))
            .mx(px(ctx.style.strokes.border));
        for cell in self.cell_list {
            row = row.child(BTableCellView(cell).render(ctx));
        }

        let Some(action) = self.action else {
            return row.into_any_element();
        };
        let id = gpui::SharedString::from(table_row_id(self.cell_list, Some(action)));
        let handler = ctx.handler.clone();
        let action = action.clone();
        let dbg = id.clone();
        div()
            .id(id)
            .debug_selector(move || dbg.to_string())
            .cursor_pointer()
            .w_full()
            // The clickable is the row: its height is the row's, so the hover
            // and selection fills cover the whole band rather than a strip of
            // it.
            .h(px(height))
            .flex()
            .child(row)
            .on_click(move |_event, window, app| {
                (std::rc::Rc::clone(&handler))(&action, window, app);
            })
            .into_any_element()
    }
}

// ── Public compatibility wrapper: table header ────────────────────────────

/// Public compatibility wrapper — renders a table header row.
#[allow(dead_code)]
pub fn view_header(cell_list: &[BTableCell], ctx: &BRenderCtx) -> AnyElement {
    BTableHeader(cell_list).render(ctx)
}

// ── BTableHeader ───────────────────────────────────────────────────────────

impl BTableHeader<'_> {
    pub fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        let mut element = div()
            .debug_selector(|| "table-header".to_string())
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .h(px(ctx.style.dimensions.card_head_height()))
            // `content_inset + row_inset == surface_gutter`, so a heading's
            // text lands in the same column as the row text under it while
            // its hover fill still spans the whole column.
            .px(px(super::tone::content_inset(ctx)))
            .gap(px(ctx.style.spacing.gap_none))
            // A column heading is a card heading: same radius, same fill as
            // a panel header (`card`), so the file list reads as one
            // more rounded section rather than a table of its own.
            .rounded_t(px(ctx.style.radius_for(BStyleRole::Card)))
            .bg(super::tone::heading_bg(ctx))
            // No rule under a column heading: the tone change is the seam, as
            // it is under a panel header.
            .text_color(to_hsla(ctx.style.colors.text))
            .text_size(px(ctx.style.typography.body));
        for cell in self.0 {
            element = element.child(BTableCellView(cell).render(ctx));
        }
        element.into_any_element()
    }
}

// ── BFocusedRenderer impls ─────────────────────────────────────────────────

// ── BTableCellView (private) ───────────────────────────────────────────────

impl BTableCellView<'_> {
    fn render(&self, ctx: &BRenderCtx) -> AnyElement {
        // A cell fills the row's height and centres its content in it.
        // Sizing to content left the columns short of the row, so a value sat
        // at whatever height its own text happened to be.
        let mut element = div()
            .flex()
            .flex_row()
            .items_center()
            .h_full()
            .min_h_0()
            .overflow_hidden();
        element = match self.0.width {
            BColWidth::Fixed(width) => element.w(px(width)).flex_shrink_0(),
            BColWidth::FileDate => element
                .w(px(ctx.style.dimensions.file_date_column_width))
                .flex_shrink_0(),
            BColWidth::FileSize => element
                .w(px(ctx.style.dimensions.file_size_column_width))
                .flex_shrink_0(),
            BColWidth::Flex => element.flex_1().min_w_0(),
        };
        element = match self.0.align {
            BColAlign::Start => element.justify_start(),
            BColAlign::End => element.justify_end(),
        };
        element.child(walk(&self.0.view, ctx)).into_any_element()
    }
}

fn table_row_id(cell_list: &[BTableCell], action: Option<&BAction>) -> String {
    if let Some(action) = action {
        let segment = match action {
            BAction::Set(path, value) => format!("set-{}-{value}", path.encode()),
            BAction::Toggle(path) => format!("toggle-{}", path.encode()),
            BAction::Open(path) => format!("open-{}", path.encode()),
            BAction::Reset(path) => format!("reset-{}", path.encode()),
        };
        return format!("table-row-{segment}");
    }
    let first = cell_list
        .first()
        .map(|cell| match cell.view.as_ref() {
            crate::v2::view::BView::Label { text } => text.clone(),
            crate::v2::view::BView::Button(ctl) => ctl.label.clone().unwrap_or_default(),
            _ => String::new(),
        })
        .unwrap_or_default();
    format!("table-row-{first}")
}
