//! Focused renderer for `BView::ListRow`.

use super::color::to_hsla;
use super::ctx::BRenderCtx;
use super::walk;
use crate::v2::theme::BStyleRole;
use crate::v2::view::BView;
use crate::v2::view::prim::BRowShade;
use gpui::prelude::*;
use gpui::{AnyElement, div, px};

pub struct BList<'a> {
    pub list: &'a [BView],
    pub shade: BRowShade,
}

impl BList<'_> {
    pub fn render(&self, ctx: &BRenderCtx<'_>) -> AnyElement {
        // One row treatment for the tree, the list and the table
        // (`tone::row_fill` / `tone::row_hover`) — this used to map the four
        // shades here, and disagreed with the other two.
        let background = super::tone::row_fill(self.shade, ctx);
        let hover = super::tone::row_hover(self.shade, ctx);
        let height = ctx.style.dimensions.row_height - 2.0 * ctx.style.strokes.border;
        // One geometry, selected or not. A row used to shrink by a border and
        // gain a margin when it became selected, so selecting or hovering one
        // nudged it and everything below it — the "dancing" on hover. State
        // may change what a row paints; it may never change what it measures.
        let mut element = div()
            .flex()
            .flex_row()
            .items_center()
            .w_full()
            .h(px(height))
            .px(px(ctx.style.spacing.pad_md))
            .gap(px(ctx.style.spacing.gap_xs))
            .hover(move |style| style.bg(to_hsla(hover)))
            .text_color(to_hsla(ctx.style.colors.text))
            .text_size(px(ctx.style.typography.body));
        if let Some(fill) = background {
            element = element.bg(to_hsla(fill));
        }
        element = element
            .rounded(px(ctx.style.radius_for(BStyleRole::MenuItem)))
            .my(px(ctx.style.strokes.border))
            .mx(px(ctx.style.strokes.border));
        for child in self.list {
            element = element.child(walk(child, ctx));
        }
        element.into_any_element()
    }
}
